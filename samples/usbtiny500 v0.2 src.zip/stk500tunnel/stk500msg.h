
class STK500Message {
 public:
  STK500Message(void);
  STK500Message(char *msg, int len, int seq);
  bool IsOK(void); 
  bool IsTooBig(void);
  void AddByte(char c);
  byte GetCommandID(void);
  byte GetSequenceNum(void);
  byte *GetBytes(void);
  byte *GetMsg(void);
  int GetLen(void);
 private: 
  byte buff[512];
  int len;
  int message_size;
};
  

// *****************[ STK message constants ]***************************

#define MESSAGE_START                       0x1B        //= ESC = 27 decimal
#define TOKEN                               0x0E
