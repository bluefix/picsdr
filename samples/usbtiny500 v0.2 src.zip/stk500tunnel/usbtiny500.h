class STK500Message;

class USBtinyISP500_App: public wxApp
{
 public:
  virtual bool OnInit();
  // virtual void ExitMainLoop();
  virtual int OnExit();
  //virtual int OnRun();
  void StartThread(wxString port);

 private:
  bool _exit;
  wxFrame *frame;
};


class USBtinyISP500Frame : wxFrame {
 public:
  USBtinyISP500Frame(const wxString &title);

  bool LoadConfiguration(void);
  bool SaveConfiguration(void);
  bool SetConfigValue(const wxString key, const wxString value);
  wxString* GetConfigValue(const wxString key);

  void OnCloseWindow(wxCloseEvent& event);
  void OnExit(wxCommandEvent& evt);
  void OnPortchange(wxCommandEvent& evt);
  void OnAbout(wxCommandEvent& evt);

  void OpenSerialPort(void);

  void OnTimer(wxTimerEvent& event);

  int ProcessMessage(void);
  int SendSTKMessage(STK500Message msg);
  int GetSTKMessage(void);
  void setChunkSize(int period);

 DECLARE_EVENT_TABLE()
 private:
  wxConfig *cfgFile;

  wxMenuBar *menubar; 
  wxMenu *fileMenu, *portMenu;
  wxString comport;
  wxPanel *toppanel;
  wxStaticText *label;

  wxTimer *m_timer;
  wxSerialPort *serialdev; // the serial port
  wxBaud baudrate;
  USBComm *usbtiny;

  char buff[1024]; // a buffer for reading/writing serial data
  STK500Message *message; // the current message
  int seq; // the current message sequence number
  char parameters[256]; // simulate params
  unsigned int address;

  int firstbyteofpage;

  byte sck_delay;
  int chunk_size;
};

int ConvertPARAMtoDelay(int param);


#define ID_SERIALTHREADQUIT 100


// *****************[ STK general command constants ]**************************

#define CMD_SIGN_ON                         0x01
#define CMD_SET_PARAMETER                   0x02
#define CMD_GET_PARAMETER                   0x03
#define CMD_SET_DEVICE_PARAMETERS           0x04
#define CMD_OSCCAL                          0x05
#define CMD_LOAD_ADDRESS                    0x06
#define CMD_FIRMWARE_UPGRADE                0x07


// *****************[ STK ISP command constants ]******************************

#define CMD_ENTER_PROGMODE_ISP              0x10
#define CMD_LEAVE_PROGMODE_ISP              0x11
#define CMD_CHIP_ERASE_ISP                  0x12
#define CMD_PROGRAM_FLASH_ISP               0x13
#define CMD_READ_FLASH_ISP                  0x14
#define CMD_PROGRAM_EEPROM_ISP              0x15
#define CMD_READ_EEPROM_ISP                 0x16
#define CMD_PROGRAM_FUSE_ISP                0x17
#define CMD_READ_FUSE_ISP                   0x18
#define CMD_PROGRAM_LOCK_ISP                0x19
#define CMD_READ_LOCK_ISP                   0x1A
#define CMD_READ_SIGNATURE_ISP              0x1B
#define CMD_READ_OSCCAL_ISP                 0x1C
#define CMD_SPI_MULTI                       0x1D

// *****************[ STK status constants ]***************************

// Success
#define STATUS_CMD_OK                       0x00

// Warnings
#define STATUS_CMD_TOUT                     0x80
#define STATUS_RDY_BSY_TOUT                 0x81
#define STATUS_SET_PARAM_MISSING            0x82

// Errors
#define STATUS_CMD_FAILED                   0xC0
#define STATUS_CKSUM_ERROR                  0xC1
#define STATUS_CMD_UNKNOWN                  0xC9

// *****************[ STK parameter constants ]***************************
#define PARAM_BUILD_NUMBER_LOW              0x80
#define PARAM_BUILD_NUMBER_HIGH             0x81
#define PARAM_HW_VER                        0x90
#define PARAM_SW_MAJOR                      0x91
#define PARAM_SW_MINOR                      0x92
#define PARAM_VTARGET                       0x94
#define PARAM_VADJUST                       0x95
#define PARAM_OSC_PSCALE                    0x96
#define PARAM_OSC_CMATCH                    0x97
#define PARAM_SCK_DURATION                  0x98
#define PARAM_TOPCARD_DETECT                0x9A
#define PARAM_STATUS                        0x9C
#define PARAM_DATA                          0x9D
#define PARAM_RESET_POLARITY                0x9E
#define PARAM_CONTROLLER_INIT               0x9F

/* ****************[ STK answer constants ]************************** */

#define ANSWER_CKSUM_ERROR                  0xB0

#define PGM_PAGE_MODE 0x1
#define PGM_WORD_DELAY_POLLING 0x2
#define PGM_WORD_VALUE_POLLING 0x4
#define PGM_WORD_RDYBSY_POLLING 0x8
#define PGM_PAGE_DELAY_POLLING 0x10
#define PGM_PAGE_VALUE_POLLING 0x20
#define PGM_PAGE_RDYBSY_POLLING 0x40
#define PGM_WRITE_PAGE 0x80

#define WORD_ADDRESSING 1
#define BYTE_ADDRESSING 2
