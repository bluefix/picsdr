#include <wx/debug.h>
#include <wx/utils.h>
#include "stk500msg.h"

STK500Message::STK500Message(void) {
  buff[0] = MESSAGE_START;
  len = 1;
}

STK500Message::STK500Message(char *b, int blen, int seq) {
  message_size = blen;
  len = message_size + 6;

  buff[0] = MESSAGE_START;
  buff[1] = seq;
  buff[2] = message_size >> 8;
  buff[3] = message_size & 0xFF;
  buff[4] = TOKEN;
  for (int i=0; i<message_size; i++) {
    buff[5+i] = b[i];
  }

  int sum = 0;
  for (int i=0; i<len-1; i++) {
    sum ^= buff[i];
  }
  buff[message_size+5] = sum & 0xFF;
}

int STK500Message::GetLen(void) {
  return len;
}

byte * STK500Message::GetBytes(void) {
  return buff;
}

byte * STK500Message::GetMsg(void) {
  return buff+5;
}

bool STK500Message::IsOK(void) {
  if (len < 6)
    return false;
  if (buff[0] != MESSAGE_START)
    return false;
  if (buff[4] != TOKEN)
    return false;
  message_size = (buff[2] << 8) | buff[3];
  if (len != 6 + message_size)
    return false;

  // do checksum
  int sum = 0;
  for (int i=0; i<message_size+5; i++) {
    sum ^= buff[i];
  }
  if (sum != buff[5+message_size])
    return false;

  return true;
}

byte STK500Message::GetCommandID(void) {
  if (! IsOK())
    return 0;
  if (message_size == 0)
    return 0;

  return buff[5];
}


byte STK500Message::GetSequenceNum(void) {
  if (! IsOK())
    return 0;

  return buff[1];
}

bool STK500Message::IsTooBig(void) {
  // wxLogDebug("Len = %d, Size = %d", len, message_size);
  if (len > 275)
    return true; // according to AVR068
  if (len >= message_size+6)
    return true;
  return false;
}

 void STK500Message::AddByte(char c) {
   buff[len] = c;
   len++;
 }
