#include <wx/log.h>
#include <wx/debug.h>
#include <wx/utils.h>
#include "usb.h"
#include "usbtinyio.h"

USBComm::USBComm(void) {
  usb_handle = 0;

  Initialize();
}

USBComm::~USBComm(void) {
  if ( ! usb_handle )
    return;

  usb_close( usb_handle );
  usb_handle = NULL;
  wxLogDebug("closed");
}

bool USBComm::Initialize(void) {
  struct usb_bus*	bus;
  struct usb_device*	dev = 0;

  usb_handle = 0;

  usb_init();
  usb_find_busses();
  usb_find_devices();
  for	( bus = usb_busses; bus; bus = bus->next ) {
    for	( dev = bus->devices; dev; dev = dev->next ) {
      if (dev->descriptor.idVendor == USBDEV_VENDOR
	  && dev->descriptor.idProduct == USBDEV_PRODUCT) {
	wxLogDebug("Found 0x%x/0x%x", dev->descriptor.idVendor, dev->descriptor.idProduct );
	usb_handle = usb_open( dev );
	if ( ! usb_handle ) {
	    wxLogDebug("Cannot open USB device: %s\n", usb_strerror() );
	    return false;
	}
	//wxLogDebug("Found device!");
	return true;
      }
    }
  }
  //  wxLogDebug("Could not find USB device 0x%x/0x%x\n", 	     USBDEV_VENDOR, USBDEV_PRODUCT );
  return false;
}

bool USBComm::Initialized(void) {
  return (usb_handle != 0);
}

void USBComm::Close(void) {
  if (usb_handle) {
    usb_handle = 0;
  }
}

bool USBComm::IsOK(void) {
  byte cmd[4], res[8];
  int ret;

  if (! usb_handle)
    return false;

  cmd[0] = 0xDE;
  cmd[1] = 0xAD;
  cmd[2] = 0xBE;
  cmd[3] = 0xEF;
  memset(res, 0, 8);

  ret = usb_in(USBTINY_ECHO, (cmd[1]<<8)|cmd[0], (cmd[3]<<8)|cmd[2], res, 8, 200);
  if (ret < 0) {
    wxLogDebug("Unable to send vendor request, ret = %d...\n", ret);
    return false;
  } 
  for (int i=0;i<4; i++) {
    if (res[i+2] != cmd[i])
      return false;
  }
  //wxLogDebug("Returned %d: %02x %02x %02x %02x", ret, res[2], res[3], res[4], res[5]);
  return true;
}
  

void USBComm::usb_control ( int req, int val, int index )
{
  usb_control_msg( usb_handle,
		   USB_ENDPOINT_IN | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
		   req, val, index, NULL, 0, USB_TIMEOUT );
 }
 
bool USBComm::usbspi(unsigned char c, unsigned char *r) {
  unsigned char buffer[4];
  int ret;

  ret = usb_in(USBTINY_SPI1, c, 0, buffer, 1, 200);
  if (ret < 0) {
    wxLogDebug("Unable to send vendor request, ret = %d...\n", ret);
    return false;
  } 
  r[0] = buffer[0];
  return true;
}

bool USBComm::usbspi4(unsigned char *cmd, unsigned char *res, bool debug) {
  int ret;

  if (debug)
    wxLogDebug("sent: %02x %02x %02x %02x", cmd[0], cmd[1], cmd[2], cmd[3]);

  ret = usb_in(USBTINY_SPI, (cmd[1]<<8)|cmd[0], (cmd[3]<<8)|cmd[2], res, 4, 200);
  if (ret < 0) {
    wxLogDebug("Unable to send vendor request, ret = %d...\n", ret);
    return false;
  } 
  if (debug)
    wxLogDebug("Returned %d: %02x %02x %02x %02x", ret, res[0], res[1], res[2], res[3]);
  return true;
}

int USBComm::usb_in ( int req, int val, int index, unsigned char *buf, int buflen, int umax )
 {
  int	n;
  int	timeout;
  
  timeout = USB_TIMEOUT + (buflen * umax) / 1000;
  n = usb_control_msg( usb_handle,
		       USB_ENDPOINT_IN | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
		       req, val, index, (char*) buf, buflen, timeout );
  if	( n != buflen )
    {
      fprintf( stderr, "USB read error: expected %d, got %d\n", buflen, n );
      return -1;
    }
  return n;
}

int USBComm::usb_out ( int req, int val, int index, unsigned char* buf, int buflen, int umax )
{
  int	n;
  int	timeout;
  
  timeout = USB_TIMEOUT + (buflen * umax) / 1000;
  n = usb_control_msg( usb_handle,
		       USB_ENDPOINT_OUT | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
		       req, val, index, (char*) buf, buflen, timeout );
  if	( n != buflen )
    {
      fprintf( stderr, "USB write error: expected %d, got %d\n", buflen, n );
      return -1;
    }
  return 0;
}

int USBComm::usb_pollrdy(void) {
  int ret;
  byte res[4];

  ret = usb_in(USBTINY_SPI, 0xF000, 0x0000, res, 4, 200);
  if (ret < 0) {
    wxLogDebug("Unable to send vendor request, ret = %d...\n", ret);
    return -1;
  }
  //wxLogDebug("Returned %d: %02x %02x %02x %02x", ret, res[0], res[1], res[2], res[3]);
  if (res[3] & 1) 
    return 0;  // busy
  
  return 1;
	       
}
