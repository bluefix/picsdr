#include <sys/types.h>
#include <dirent.h>
#include <wx/app.h>
#include <wx/frame.h>
#include <wx/log.h>
#include <wx/debug.h>
#include <wx/menu.h>
#include <wx/msgdlg.h>
#include <wx/stattext.h>
#include <wx/config.h>
#include <wx/event.h>
#include <wx/timer.h>
#include <wx/ctb/iobase.h>
#include <wx/ctb/serport.h>
#include <math.h>
#include "usb.h"
#include "usbtinyio.h"
#include "usbtiny500.h"
#include "stk500msg.h"

#define TIMER_ID 2000

#define MAX_CHUNKSIZE 128
// fixme:  EEPROM page programming, usb delay, test for serial errors, AT89?

IMPLEMENT_APP(USBtinyISP500_App)

bool USBtinyISP500_App::OnInit()
{
  wxLogDebug("usbtinyisp500");

  this->_exit = false;

  new USBtinyISP500Frame("usbtinyisp <-> stk500");

  return true;
} 

int USBtinyISP500_App::OnExit() {
  
  return 0;
}


bool USBtinyISP500Frame::LoadConfiguration(void) {
  cfgFile = new wxConfig("USBtiny500");
  wxConfig::Set(cfgFile);
  return true;
}

bool USBtinyISP500Frame::SaveConfiguration(void) {
  cfgFile->Flush();
  return true;
}


wxString* USBtinyISP500Frame::GetConfigValue(const wxString key) {
  wxString *ret = new wxString();
  if (cfgFile->Read(key, ret))
    return ret;
  else
    return NULL;
}

bool USBtinyISP500Frame::SetConfigValue(const wxString key, const wxString value) {
  return cfgFile->Write(key, value);
}

USBtinyISP500Frame::USBtinyISP500Frame(const wxString &title)
  :  wxFrame((wxFrame *)NULL, wxID_ANY, title,
	     wxPoint(150, 150),
	     wxSize(200, 200),
	     (wxDEFAULT_FRAME_STYLE | wxFULL_REPAINT_ON_RESIZE))
{

  wxString *key;
  LoadConfiguration();

  key = GetConfigValue("comport");
  if (key == NULL) {
    comport = "COM1";
    wxLogDebug("Config: undef. port, will choose first available");
  } else {
    comport = wxString(*key);
    wxLogDebug("Config serial port: "+comport);
  }
  SetConfigValue("comport", comport);

  menubar = new wxMenuBar();
  SetMenuBar(menubar);

  fileMenu = new wxMenu();
  fileMenu->Append(wxID_ABOUT, "About USBtiny500",
		   "About USBtiny500");
  fileMenu->AppendSeparator();
   fileMenu->Append(wxID_EXIT, "Quit\tCTRL-Q", 
		   "Exit the Program");
  menubar->Append(fileMenu, "File");

  portMenu = new wxMenu();
  for (int i=1; i<=10; i++) {
    wxString com =  wxString::Format("COM%d", i);
    portMenu->Append(1000+i, com, com, wxITEM_RADIO );
    if (com == comport) {
      portMenu->Check(1000+i, true);
    }
  }
  menubar->Append(portMenu, "COM Port");
  
  SetSize(400,100);

  toppanel = new wxPanel(this, wxID_ANY, wxPoint(0, 0), wxSize(400, 100));
  label = new wxStaticText(toppanel, wxID_ANY, "Status:",
			   wxPoint(10, 10));
  wxFont f = label->GetFont();
  f.SetPointSize(12);
  label->SetFont(f);
  
  Show(true);

  m_timer = new wxTimer(this, TIMER_ID);

  serialdev = new wxSerialPort();
  baudrate = wxBaud(115200);
  usbtiny = new USBComm();
  usbtiny->Close();
  //AddPendingEvent(wxCommandEvent(wxEVENT_TYPE_MENU_COMMAND, 1000));
  OpenSerialPort();
}


void USBtinyISP500Frame::OnCloseWindow(wxCloseEvent& event) {
  wxLogDebug("Window Closed");
  Destroy();
}


void USBtinyISP500Frame::OnExit(wxCommandEvent& evt) {
  wxLogDebug("Exit!");
  Close(true);
}

void USBtinyISP500Frame::OnAbout(wxCommandEvent& evt) {
  wxMessageBox("USBtinyISP<=>STK500 Bridge\nAn STK500 protocol emulator that allows\nthe use of other programmers with AVR Studio", "About", wxOK|wxICON_INFORMATION, this);
}

void USBtinyISP500Frame::OnPortchange(wxCommandEvent& evt) {
  for (unsigned int i=0; i<portMenu->GetMenuItemCount(); i++)
    if (portMenu->FindItemByPosition(i)->IsChecked())
      comport = portMenu->FindItemByPosition(i)->GetText();
  SetConfigValue("comport", comport);
  SaveConfiguration();

  OpenSerialPort();
}

void USBtinyISP500Frame::OpenSerialPort() {

  label->SetLabel("Status: Opening port "+comport);

   //try to open com port
  if (serialdev->Open(comport) < 0) {
    wxLogError(wxT("Can't create Connection to port "+comport+"\nPlease select a different port"));
    label->SetLabel("Status: Failed on "+comport);   
    m_timer->Stop();

    return;
  }

  serialdev->SetBaudRate(baudrate);
  m_timer->Start(100); // start the timer  
}

void USBtinyISP500Frame::OnTimer(wxTimerEvent& event)
{
  int ret; 

  if (!usbtiny->Initialized()) {
    usbtiny->Initialize();
    if (!usbtiny->IsOK()) {
      wxString f = "Status: Failed to find USBtinyISP";
      if (label->GetLabel() != f) {
	label->SetLabel(f);
	wxLogError(wxT("Can't find USBtinyISP\nCheck that its plugged in to a working USB port"));
	usbtiny->Close();
	return;
      }
    } else {
      label->SetLabel("Status: Found USBtinyISP!");

      // initialize
      message = NULL;
      seq = 0;
      
      parameters[PARAM_BUILD_NUMBER_LOW] = 0;
      parameters[PARAM_BUILD_NUMBER_HIGH] = 0;
      parameters[PARAM_HW_VER] = 1;
      parameters[PARAM_SW_MAJOR] = 2;
      parameters[PARAM_SW_MINOR] = 0;
      

      wxString *key = GetConfigValue("sckparam");
      if (key == NULL) {
	 parameters[PARAM_SCK_DURATION] = 2;
	 wxLogDebug("Config: undef. delay, using maxspeed");
      } else {
	long temp;
	if (! key->ToLong(&temp))
	  parameters[PARAM_SCK_DURATION] = 2;
	else
	  parameters[PARAM_SCK_DURATION] = temp;
	wxLogDebug("Config sck speed: %d", parameters[PARAM_SCK_DURATION]);
      }
      SetConfigValue("sckparam", parameters[PARAM_SCK_DURATION]);
      sck_delay = ConvertPARAMtoDelay(parameters[PARAM_SCK_DURATION]);
      setChunkSize(sck_delay);

      parameters[PARAM_STATUS] = 0;   // ???
      parameters[PARAM_RESET_POLARITY] = 1;  // default to avr family polarity
      parameters[PARAM_CONTROLLER_INIT] = 0; 
      
      parameters[PARAM_CONTROLLER_INIT] = 0;

      label->SetLabel("Status: Ready");
    }
  }
 
  ret = GetSTKMessage();
  if (ret == 0) {
    return;
  }
  if (ret == 1) {
    //wxLogDebug("Got message!");
    
    if (ProcessMessage() < 0) {
      wxLogDebug("Uh oh...problemz");
      if (!usbtiny->IsOK()) {
	wxLogDebug("USB problems");
	usbtiny->Close();
      }
      return;
    }     
    delete message;
    message = 0;
  }
}

int USBtinyISP500Frame::ProcessMessage(void) {
  seq = message->GetSequenceNum();
  byte command = message->GetCommandID();
  int ret;
  byte param;

  STK500Message resp;
  
  // do stuff
  //label->SetLabel("Status: Processing Message");

  if (command == CMD_SIGN_ON) {
    label->SetLabel("Status: Processing CMD_SIGN_ON");
    // send response
    buff[0] = CMD_SIGN_ON;
    buff[1] = STATUS_CMD_OK;
    buff[2] = 8;
    strncpy(buff+3, "AVRISP_2", 8);
    resp = STK500Message(buff, 11, seq); 
    ret = SendSTKMessage(resp);
  }
  else if (command == CMD_SET_PARAMETER) {
    label->SetLabel("Status: Processing CMD_SET_PARAMETER");
    param = (message->GetMsg())[1];
    wxLogDebug("Setting paramter %02x to %02x", param, (message->GetMsg())[2]);
    buff[0] = CMD_SET_PARAMETER;
    if ((param < PARAM_BUILD_NUMBER_LOW) || (param > PARAM_CONTROLLER_INIT)) {
      buff[1] = STATUS_CMD_FAILED;
    } else {
      // seems valid!
      buff[1] = STATUS_CMD_OK;
      parameters[param] = (message->GetMsg())[2];

      if (param == PARAM_SCK_DURATION) {
	// this method aint perfect but it works pretty good. wooo.

	sck_delay = ConvertPARAMtoDelay(parameters[param]);
        setChunkSize(sck_delay);

	SetConfigValue("sckparam", wxString::Format("%d",parameters[param]));
      }
    }
    ret = SendSTKMessage(STK500Message(buff, 2, seq));
  }
  else if (command == CMD_GET_PARAMETER) {
    label->SetLabel("Status: Processing CMD_GET_PARAMETER");
    param = (message->GetMsg())[1];
    wxLogDebug("Returning paramter %02x", param);
    if ((param < PARAM_BUILD_NUMBER_LOW) || (param > PARAM_CONTROLLER_INIT)) {
      buff[0] = command;
      buff[1] = STATUS_CMD_FAILED;
      ret = SendSTKMessage(STK500Message(buff, 2, seq));
    } else {
      // seems valid!
      buff[0] = command;
      buff[1] = STATUS_CMD_OK;
      buff[2] = parameters[param];
      ret = SendSTKMessage(STK500Message(buff, 3, seq));
      wxLogDebug("Wrote %d bytes", ret);
    }
  }  
  else if (command == CMD_LOAD_ADDRESS) {
    label->SetLabel("Status: Processing CMD_LOAD_ADDRESS");
    address = (message->GetMsg())[1];
    address <<= 8;
    address |= (message->GetMsg())[2];
    address <<= 8;
    address |= (message->GetMsg())[3];
    address <<= 8;
    address |= (message->GetMsg())[4];
    address <<= 8;
    wxLogDebug("Loaded address 0x%x", address);
    buff[0] = command;
    buff[1] = STATUS_CMD_OK;
    ret = SendSTKMessage(STK500Message(buff, 2, seq));

    firstbyteofpage = 0xFFFF;
  } 
  else if (command == CMD_FIRMWARE_UPGRADE) {
    label->SetLabel("Status: Processing CMD_FIRMWARE_UPGRADE");
    // We dont gotz upgrade
    buff[0] = command;
    buff[1] = STATUS_CMD_FAILED;
    ret = SendSTKMessage(STK500Message(buff, 2, seq));
  }
  
  /******************** ISP COMMANDS **********************/

  else if (command == CMD_ENTER_PROGMODE_ISP) {
    label->SetLabel("Status: Processing CMD_ENTER_PROGMODE_ISP");
    byte isp_timeout;  // command timeout
    byte cmdexeDelay = (message->GetMsg())[1];
    byte synchLoops = (message->GetMsg())[4];
    byte byteDelay = (message->GetMsg())[5];
    byte pollValue = (message->GetMsg())[6];
    byte pollIndex = (message->GetMsg())[7];
    byte *cmd = message->GetMsg()+8;
    byte ret;
    boolean OK = false;
    
    wxLogDebug("Entering programming mode: cmdexeDelay=%d loops=%d byteDelay=%d pollValue=%02X, pollIndex=%d", cmdexeDelay, synchLoops, byteDelay, pollValue, pollIndex);
    
    // MEME; fix sck and reset for AT89
    usbtiny->usb_control( USBTINY_POWERUP, sck_delay, RESET_LOW ); 
    
    Sleep(cmdexeDelay);
    if (pollIndex == 0) {
      OK = true;
    }
    
    for (int i=0; i < synchLoops; i++) { // # loops
      //wxLogDebug("Try #%d", i);
      for (int j=0; j<4; j++) { // 4 bytes to send
	
	if (!usbtiny->usbspi(cmd[j], &ret)) {
	  return -1;
	}
	if ((j+1 == pollIndex) && (ret == pollValue)) {
	  wxLogDebug("Got good response from chip");
	  OK = true;
	}
	Sleep(byteDelay); // byteDelay	     
      }
      if (OK)
	break;
      // MEME: do timeout
    }
    
    // ok done with synch loops, lets respond
    buff[0] = command;
    if (OK) {
      // seems valid!
      buff[1] = STATUS_CMD_OK;
    } else {
      buff[1] = STATUS_CMD_FAILED;
    }
    ret = SendSTKMessage(STK500Message(buff, 2, seq));
  }
  else if (command == CMD_LEAVE_PROGMODE_ISP) {
    label->SetLabel("Status: Processing CMD_LEAVE_PROGMODE_ISP");
    // pre-delay
    Sleep((message->GetMsg())[1]);  //preDelayc
    usbtiny->usb_control( USBTINY_POWERDOWN, 0, 0 );
    Sleep((message->GetMsg())[2]);  //postDelay
    buff[0] = CMD_LEAVE_PROGMODE_ISP;
    buff[1] = STATUS_CMD_OK;
    ret = SendSTKMessage(STK500Message(buff, 2, seq));
  }
  else if (command == CMD_CHIP_ERASE_ISP) {
    label->SetLabel("Status: Processing CMD_CHIP_ERASE_ISP");
    byte eraseDelay = (message->GetMsg())[1];
    byte pollMethod = (message->GetMsg())[2];
    byte res[4];
    
    if (!usbtiny->usbspi4(message->GetMsg()+3, res)) {
      return -1;
    }
    buff[0] = command;
    if (pollMethod == 0) { // just delay
      Sleep(eraseDelay);
      buff[1] = STATUS_CMD_OK;
    } else {
      // send RDYBSY
      buff[1] = STATUS_CMD_TOUT;
      for (int i=0; i<256; i++) {
	ret = usbtiny->usb_pollrdy();
	if (ret < 0)
	  return -1;
	if (ret == 1) {
	  buff[1] = STATUS_CMD_OK;
	  break;
	}
      }
    }
    SendSTKMessage(STK500Message(buff, 2, seq));
  }
  else if ((command == CMD_PROGRAM_FLASH_ISP) || 
	   (command == CMD_PROGRAM_EEPROM_ISP)){
    // ugh this it the tough one
    int NumBytes = (message->GetMsg())[1]<<8 | (message->GetMsg())[2];
    byte mode = (message->GetMsg())[3];
    byte delay = (message->GetMsg())[4];
    byte cmd1 = (message->GetMsg())[5];
    byte cmd2 = (message->GetMsg())[6];
    byte cmd3 = (message->GetMsg())[7];
    byte poll1 = (message->GetMsg())[8];
    byte poll2 = (message->GetMsg())[9];
    byte *data = message->GetMsg()+10;
    int addressing = 0;
    byte c;

    if (command == CMD_PROGRAM_FLASH_ISP) {
      label->SetLabel("Status: Processing CMD_PROGRAM_FLASH_ISP");
      addressing = WORD_ADDRESSING;
      c = USBTINY_FLASH_WRITE;
    } else {
      label->SetLabel("Status: Processing CMD_PROGRAM_EEPROM_ISP");
      addressing = BYTE_ADDRESSING;
      c = USBTINY_EEPROM_WRITE;
    }
    

    byte spicmd[4], ret4[4], ret;
    byte status = STATUS_CMD_OK;
    int chunk;
    int attempts;
    int poll_address, startAddress = address;
    
    wxLogDebug("write %d bytes, mode = 0x%x", NumBytes, mode);

    if (! (mode & PGM_PAGE_MODE)) {
      // word mode
      wxLogDebug("Word mode, cmd1=0x%x",cmd1);
      for(int i=0; i < NumBytes; i++) {
	// The Low/High byte selection bit is
	// bit number 3. Set high byte for uneven bytes
	if((addressing == WORD_ADDRESSING) && (i & 1)) {
	  // high byte
	  spicmd[0] = cmd1 | (1<<3);
	} else {
	  // low byte 
	  spicmd[0] = cmd1;
	}
	spicmd[1] = address >> 8;
	spicmd[2] = address & 0xFF;
	spicmd[3] = data[i];
	
	if (!usbtiny->usbspi4(spicmd, ret4))
	  return -1;
	
	poll_address = address;
	if ((data[i] != poll1) && // cant poll if the first byte == polling val
	    (((mode & PGM_WORD_VALUE_POLLING) && 
	      (command == CMD_PROGRAM_FLASH_ISP)) ||
	     ((mode & PGM_WORD_VALUE_POLLING) && 
	      (command == CMD_PROGRAM_EEPROM_ISP))) &&
	    poll_address) {
	  //Data value polling
	  attempts = 10;
	  
	  //wxLogDebug("polling on 0x%x for value %x - %x", address, poll1, data[i]);	  
	  do {
	    // The Low/High byte selection bit is
	    // bit number 3. Set high byte for uneven bytes
	    // Read data:

	    spicmd[0] = cmd3;
	    if ((addressing == WORD_ADDRESSING) && (poll_address & 1)) {
	      spicmd[0] = cmd3|0x08;
	    }
	    spicmd[1] = address >> 8;
	    spicmd[2] = address & 0xFF;
	    spicmd[3] = 0;
	    if (!usbtiny->usbspi4(spicmd, ret4))
	      return -1;
	    //wxLogDebug("polled %x", ret4[3]);
	    attempts--;
	  } while ((ret4[3] == poll1) && attempts);

	  if (attempts == 0){
	    status=STATUS_CMD_TOUT;
	  }
	} else if (((mode & PGM_WORD_RDYBSY_POLLING) && 
		    (command == CMD_PROGRAM_FLASH_ISP)) ||
		   ((mode & PGM_WORD_RDYBSY_POLLING) && 
		    (command == CMD_PROGRAM_EEPROM_ISP))) {
	  //RDY/BSY polling
	  
	  attempts = 250;
	  while( !usbtiny->usb_pollrdy() && attempts)
	    attempts--;
	  
	  if (attempts==0) {
	    status=STATUS_RDY_BSY_TOUT;
	  }
	} else {
	  // simple waiting
	  Sleep(delay+2);
	}

	if (addressing == WORD_ADDRESSING) {
	  if (i & 1)
	    address++;
	} else {
	  address++;
	}
      }
    } else {
      // Page mode (nearly all modern chips)
      int next;

      wxLogDebug("Page mode, cmd1=0x%x",cmd1);
      if (firstbyteofpage == 0xFFFF) 
	firstbyteofpage = data[0];

      // eeprom page mode we have to do by hand :(
      if ((cmd1 != 0xC0 ) && (c == USBTINY_EEPROM_WRITE)) {
	wxLogDebug("Page mode done by hand! ");
	firstbyteofpage = 0xff; // MEME hack
	spicmd[0] = cmd1; // byte addressed
	for (int i = 0; i < NumBytes; i++) {
	  spicmd[1] = (address+i) >> 8;
	  spicmd[2] = (address+i) & 0xFF;
	  spicmd[3] = data[i];

	  if (!usbtiny->usbspi4(spicmd, ret4))
	    return -1;	
	}
      } else {
	for (int i = 0; i < NumBytes; i = next) {
	  chunk = chunk_size;
	  if (chunk > NumBytes - i) {
	    chunk = NumBytes - i;
	  }
	  usbtiny->usb_out(c, 
			   delay, i, data + i, chunk, 200 + delay );
	  
	  /*
	  wxString foo = wxString::Format("wrote %d bytes: ", chunk);
	  for (int q=0;q<chunk;q++) 
	    foo += wxString::Format("%02x ", data[i+q]); 
	  wxLogDebug(foo);
	  */
	  
	  next = i + chunk;
	}
      }
      
      if (mode & PGM_WRITE_PAGE) {
	//wxLogDebug("writing page %x", startAddress);
	// time to write the page
	
	spicmd[0] = cmd2;
	spicmd[1] = startAddress >> 8;
	spicmd[2] = startAddress & 0xFF;
	spicmd[3] = 0;

	if (!usbtiny->usbspi4(spicmd, ret4)) {
	  wxLogDebug("USB error");
	  return -1;
	}
	poll_address = address;
	
	if( ((firstbyteofpage & 0xFF) != poll1) &&
	    (mode & PGM_PAGE_VALUE_POLLING) &&
	    poll_address )  {
	  //Data value polling
	  attempts = 250;
	  //wxLogDebug("Polling  for %x", poll1);
	  do {
	    // The Low/High byte selection bit is
	    // bit number 3. Set high byte for uneven bytes
	    // Read data:
	    if (poll_address & 1) {
	      spicmd[0] = cmd3|(1<<3);
	    } else {
	      spicmd[0] = cmd3;
	    }
	    
	    spicmd[1] = startAddress >> 8;
	    spicmd[2] = startAddress & 0xFF;
	    spicmd[3] = 0;
	    if (!usbtiny->usbspi4(spicmd, ret4))
	      return -1;
	    attempts--;
	  } while ((ret4[3] == poll1) && attempts);

	  if (attempts == 0){
	    //wxLogDebug("timed out");
	    status=STATUS_CMD_TOUT;
	  }
	} else if (((mode & PGM_PAGE_RDYBSY_POLLING) && 
		    (command == CMD_PROGRAM_FLASH_ISP)) ||
		     ((mode & PGM_PAGE_RDYBSY_POLLING) && 
		      (command == CMD_PROGRAM_EEPROM_ISP))) {
	  //RDY/BSY polling, tested works
	  //wxLogDebug("rdy/bsy polling");
	  
	  attempts = 250;
	  while( !usbtiny->usb_pollrdy() && attempts)
	    attempts--;
	  
	  if (attempts==0){
	    status=STATUS_RDY_BSY_TOUT;
	  }
	}else{
	  // simple waiting
	  wxLogDebug("zzz");
	  Sleep(delay);
	}
	firstbyteofpage = 0xFFFF; //next page
      }
      if (addressing == WORD_ADDRESSING)
	address += NumBytes/2;
      else
	address += NumBytes;
    }

    buff[0] = command;
    buff[1] = status;    
    ret = SendSTKMessage(STK500Message(buff, 2, seq));
  }
  else if ((command == CMD_READ_FLASH_ISP) || 
	   (command == CMD_READ_EEPROM_ISP)){

    byte cmd[4], res[4], readbuffer[512];
    int NumBytes = (message->GetMsg())[1]<<8 | (message->GetMsg())[2];
    byte cmd1 = (message->GetMsg())[3];
    int chunk;
    int addressing;
    byte c;

    if (command == CMD_READ_FLASH_ISP) {
      label->SetLabel("Status: Processing CMD_READ_FLASH_ISP");
      addressing = WORD_ADDRESSING;
      c = USBTINY_FLASH_READ;
    } else {
      label->SetLabel("Status: Processing CMD_READ_EEPROM_ISP");
      addressing = BYTE_ADDRESSING;
      c = USBTINY_EEPROM_READ;
    }
    
    wxLogDebug("Reading %d bytes of memory, Cmd1 = %x", NumBytes, cmd1);
    
    if (cmd1 == 0x20) {
      for (int i=0; i< NumBytes; i+= chunk) {
	chunk = chunk_size;
	if (chunk > NumBytes - i) 
	  chunk = NumBytes - i;
	if (usbtiny->usb_in(c, 0, address, readbuffer+i, chunk, 200) < 0)
	  return -1;
	address += chunk;
      }
    } else {
      // not paged! :(
      wxLogDebug("Not Paged");
      for (int i=0; i<NumBytes; i++) {
	cmd[0] = cmd1; // first byte is read command
	if ((addressing == WORD_ADDRESSING) && (i & 0x1)) // high byte
	  cmd[0] |= 0x08;
	cmd[1] = address >> 8;
	cmd[2] = address & 0xFF;
	cmd[3] = 0x0;
	if (!usbtiny->usbspi4(cmd, res)) {
	  return -1;
	}
	readbuffer[i] = res[3];
	if (addressing == WORD_ADDRESSING) {
	  if (i & 0x1)
	    address++;
	} else {
	  address++;
	}
      }
    }
    buff[0] = command;
    buff[1] = STATUS_CMD_OK;
    memcpy(buff+2, readbuffer, NumBytes);
    buff[2+NumBytes] = STATUS_CMD_OK;
    ret = SendSTKMessage(STK500Message(buff, NumBytes+3, seq));
  }
  else if ((command == CMD_PROGRAM_FUSE_ISP) || (command == CMD_PROGRAM_LOCK_ISP)) {
    byte res[4];
    if (!usbtiny->usbspi4(message->GetMsg()+1, res)) {
      return -1;
    }
    buff[0] = command;
    buff[1] = STATUS_CMD_OK;
    buff[2] = STATUS_CMD_OK;
    ret = SendSTKMessage(STK500Message(buff, 3, seq));
  }
  else if ((command == CMD_READ_FUSE_ISP) ||
	   (command == CMD_READ_LOCK_ISP) ||
	   (command == CMD_READ_SIGNATURE_ISP) ||
	   (command == CMD_READ_OSCCAL_ISP)) {
    byte res[4];
    byte RetAddr = (message->GetMsg())[1];
    if (!usbtiny->usbspi4(message->GetMsg()+2, res)) {
      return -1;
    }
    wxLogDebug("Returning byte #%d", RetAddr);
    buff[0] = command;
    buff[1] = STATUS_CMD_OK;
    buff[2] = res[RetAddr-1];
    buff[3] = STATUS_CMD_OK;
    ret = SendSTKMessage(STK500Message(buff, 4, seq));
  } else {
    wxLogDebug("Bad message?");
    wxString f = "";
    byte *b = message->GetBytes();
    for (int i=0; i<message->GetLen(); i++) {
      f += wxString::Format("%x ", b[i]);
    }
    wxLogDebug(f);
  }

  return 0;
}
int USBtinyISP500Frame::SendSTKMessage(STK500Message msg) {
  return serialdev->Write((char *)(msg.GetBytes()), msg.GetLen());
}

int USBtinyISP500Frame::GetSTKMessage(void) {
  int ret;

  while (1) {
    ret = serialdev->Read(buff, 1);
    if (ret < 0) {
      return -1;
    }
    if (ret == 0)
      return 0;

    //wxLogDebug("Got 0x%2x", buff[0]);
    if (! message) {
      if (buff[0] != MESSAGE_START)
	continue;  // wait for token
      
      //wxLogDebug("Message Start");
      message = new STK500Message();
    } else {
      // stuff another byte in and see if its OK
      message->AddByte(buff[0]);
      if (message->IsOK())
	return 1;
      //wxLogDebug("Not OK");
      if (message->IsTooBig()) {
	wxLogDebug("Too big");
	delete message;
	message = 0;
      }
    }      
  }
}

int ConvertPARAMtoDelay(int param) {
  int div = (int) pow(4, param);
  float freq = 921.6/div;
  wxLogDebug("wants %d (div = %d) => %3.1f KHz",  param, div, 921.6/div);
  
  float inv = 1000.0/freq;
  int delayval = (int)(inv+.5)-1;
  if (delayval < 1)
    delayval = 1;
  else if (delayval > 250)
    delayval = 250;
  
  wxLogDebug("inv = %f, sckdelay = %d", inv, delayval);
  return delayval;
}

void USBtinyISP500Frame::setChunkSize(int period) {
  chunk_size = MAX_CHUNKSIZE;

  while	(( chunk_size > 8) && (period >= 16) )
    {	// Reduce the chunk size for a slow SCK to reduce
      // the maximum time of a single USB transfer.
      chunk_size /= 2;
      period /= 2;
    }
  //wxLogDebug("new chunksize = %d", chunk_size);
}

BEGIN_EVENT_TABLE (USBtinyISP500Frame, wxFrame) 
  EVT_CLOSE(USBtinyISP500Frame::OnCloseWindow)
  EVT_MENU(wxID_ABOUT, USBtinyISP500Frame::OnAbout)
  EVT_MENU(wxID_EXIT, USBtinyISP500Frame::OnExit)
  EVT_MENU(1000, USBtinyISP500Frame::OnPortchange)
  EVT_MENU(1001, USBtinyISP500Frame::OnPortchange)
  EVT_MENU(1002, USBtinyISP500Frame::OnPortchange)
  EVT_MENU(1003, USBtinyISP500Frame::OnPortchange)
  EVT_MENU(1004, USBtinyISP500Frame::OnPortchange)
  EVT_MENU(1005, USBtinyISP500Frame::OnPortchange)
  EVT_MENU(1006, USBtinyISP500Frame::OnPortchange)
  EVT_MENU(1007, USBtinyISP500Frame::OnPortchange)
  EVT_MENU(1008, USBtinyISP500Frame::OnPortchange)
  EVT_MENU(1009, USBtinyISP500Frame::OnPortchange)
  EVT_TIMER(TIMER_ID, USBtinyISP500Frame::OnTimer)
END_EVENT_TABLE()
