

                                    CDC-IO


    This is the Readme file to firmware-only CDC driver for Atmel AVR
    microcontrollers. For more information please visit
    http://www.recursion.jp/avrcdc/


SUMMARY
=======
    The CDC-IO performs the CDC (Communication Device Class) connection over
    low-speed USB. It provides the parallel port interface without installing
    dedicated driver.
    The CDC-IO is developed by Osamu Tamura @ Recursion Co., Ltd.


SPECIFICATION
=============
    Send text command to read/modify port bits. Use any terminal software
    or your own program.

    CDC-IO parallel port: 3/13/18 bits
    (ATtiny45rc/85rc)
        PORTB: bit 0,1,4
    (ATtiny461rc/861rc)
        PORTA: bit 0-7
        PORTB: bit 0-2,4,5
    (ATmega8/48/88/168)
        PORTB: bit 0-5
        PORTC: bit 0-5
        PORTD: bit 0,1,4-7

    CDC-IO terminal settings
        speed:    any
        datasize: 7/8 bit
        parity:   any
        stopbit:  any

      Although RS-232C setting is not matter, set data size to 8bit to avoid
      unexpected troubles. To see the requested command, turn on "local echo".

    CDC-IO command
        function       command       format                response
        ------------------------------------------------------------------
        Who            @             @                     "cdc-io", CR-LF
        Get            ?             addr ?                data, CR-LF
        Set            =             data addr =           CR-LF
        AND & Set      &             data addr &           CR-LF
        OR & Set       |             data addr |           CR-LF
        EX-OR & Set    ^             data addr ^           CR-LF
        Set Double     $             data2 data1 addr $    CR-LF

        addr:      memory mapped I/O address in hex
        data:      8 bit data in hex
        delimiter: Tab, Space, CR, LF

        predefined addr: (case-insensitive)
            PINA, DDRA, PORTA
            PINB, DDRB, PORTB
            PINC, DDRC, PORTC
            PIND, DDRD, PORTD

        example:
          DDRB ? (+delimiter)      Replies DDRB value with CR-LF.
          12 34 = (+delimiter)     Write 0x12 to address:0x34, replies CR-LF.
          FB PORTC & (+delimiter)  Write (PORTC & 0xFB) to PORTC, replies CR-LF.

    Previous data and addr can be reused. Just enter command char to repeat.

    USB line is connected to PORTB2,3/PORTB3,6/PORTD2,3. Avoid changing these
    bits. Use '&', '|' or '^' to modify the port direction. Use PIN* to toggle
    bits if the port is assigned to output.

    USB bus-powered Vcc is about 3.6V. Be careful of interfacing to the higher
    voltage circuit. Usable bus-powered current is about 80mA.

    Any SFRs(special function registers) are accessible. See AVR datasheet to
    use Timers, ADC, EEPROM, etc. 

    Internal RC Oscillator is calibrated at startup time. It may be unstable 
    after a long time operation (ATtiny45rc/461rc).

    Although the CDC is supported by Windows 2000/XP/Vista, Mac OS 9.1/X,
    and Linux 2.4, CDC on low-speed USB is not allowed by the USB standard.
    Use AVR-CDC at your own risk.


USAGE
=====
    [Windows XP/2000]
    When you connect with a USB port first, a "Driver Setup Dialog" appears.
    Specify the folder in which "avrcdc.inf" exists, without searching
    automatically. Although it is warned that the driver is not certified,
    confirm it. It only loads Windows' built-in "usbser.sys". Then, the
    virtual COM port appears.
 
    [Windows Vista]
    Specify the folder in which "lowbulk.inf" exists. It loads both
    "usbser.sys" and "lowbulk.sys".

    [Mac OS X]
    You'll see the device /dev/cu.usbmodem***.

    [Linux]
    The device will be /dev/ttyACM*.
    Linux 2.6 does not accept low-speed CDC without patching the kernel.


DEVELOPMENT
===========
    Build your circuit and write firmware (cdcio*.hex) into it.
    C1:104 means 0.1uF, R3:1K5 means 1.5K ohms.

    If the connection is unstable, add another diode after D2, or try other
    USB-Hub or PC.

    Modify CLK in Makefile to use other clocks. Consider using Zener diodes
    since 3.6V may not be enough for the higher clock operation.
    See http://avrusb.wikidot.com/hardware for details.

    This driver has been developed on AVR Studio 4.14 and WinAVR 20080610.
    If you couldn't invoke the project from cdcio.aps, create new GCC project
    named "cdcio" under "cdcio****-**-**/" without creating initial file. 
    Select each Makefile at "Configuration Options".

    Fuse bits
                          ext  H-L
        ATtiny45rc/85rc    FF CE-F1
        ATtiny461rc/861rc  FF CF-F1
        ATmega8               9F-FF
        ATmega48/88/168    FF CE-FF

    The code size of CDC-IO is 2.8KB, and 128B RAM is required at least.


USING CDC-IO FOR FREE
======================
    The CDC-IO is published under an Open Source compliant license.
    See the file "License.txt" for details.

    You may use this driver in a form as it is. However, if you want to
    distribute a system with your vendor name, modify these files and recompile
    them;
        1. Vendor String in usbconfig.h
        2. COMPANY and MFGNAME strings in avrcdc.inf/lowbulk.inf 



    Osamu Tamura @ Recursion Co., Ltd.
    http://www.recursion.jp/avrcdc/
    12 January 2007
    7 April 2007
    7 July 2007
    25 August 2008

