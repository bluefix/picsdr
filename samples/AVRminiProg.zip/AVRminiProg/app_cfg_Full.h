/* Name: app_cfg_Full.h
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2008-02-04
 */

/******************************** AVRminiProgFull ********************************/
//  AVRminiProgFull supports ALL programming interfaces of AVR. Controller is Mega16
//or Mega32. High Voltage Programming Interface is the same as AVRDragon, so just 
//use the "Device Connection Sheet" in the help file of AVRDragon in AVRStudio.

#ifndef APP_CFG_INCLUDED

#define APP_CFG_INCLUDED

#define AVR_DEVICE					(AVR_DEVICE_AVRDRAGON)

// if AVR_DEVICE_AVRISP_MKII is sellected, only ISP could be enabled, others will be ignored
// if AVR_DEVICE_JTAGICE_MKII is sellected, HV Programming will be ignored
#define AVR_PROG_ISP_EN				1
#define AVR_PROG_JTAG_EN			1
#define AVR_PROG_HVPP_EN			1
#define AVR_PROG_HVSP_EN			1

#define AVR_DBG_JTAG_EN				0			// NOT implemented, don't use
#define AVR_DBG_DW_EN				0			// NOT implemented, don't use

/*************************** ADC *****************************/
// devices like USBasp has no AD connected to target VCC,just define AD_En to 0
#define AD_En						1

// VREF can be ADC_VREF_AVCC or ADC_VREF_BANDGAP
#define AD_VCC_MUX					(ADC_VREF_BANDGAP | ADC_CHANNEL_ADC6)
#define ADVref						25			// in 100mA,so 11 means 1.1V
#define AD_VCC_RATE					4			// see below, equals to (R1 + R2) / R2
// target VCC ------ R1 ------ ADC
//                           |
//        GND ------ R2 ------
// 
// for Reference Voltage (AVCC will change according to different current load, BANDGAP will not):
// if AVCC is used, resistor1 = resistor2 = 10K					AD_VCC_RATE should be 2
// if BANDGAP is used, resistor1 = 10K, resistor2 = 2K			AD_VCC_RATE should be 6
// I use AVCC as reference, and resistor1 = 10K, resistor2 = 2K	AD_VCC_RATE is 6
// Of cource other values are also acceptable, just use different R1 and R2

/*************************** LED *****************************/
#define LED_Green					P(1)		// indicates connected to PC
#define LED_Red						P(0)		// indicates target VCC

#define LED_Init()					do{PortA_SetPin(LED_Green | LED_Red);PortA_SetOutput(LED_Green | LED_Red);}while(0)
#define LED_On(led)					PortA_ClrPin(led)
#define LED_Off(led)				PortA_SetPin(led)
#define LED_IsOn(led)				!PortA_GetPin(led)


/*********************** ISP JTAG *****************************/
// AVRminiProg will check the Target VCC, and determine whether to supply power to JTAG/ISP, AD_En MUST be set to 1
#define ISP_JTAG_AutoPower_En		1
// AVRminiProg can force supply power to JTAG/ISP without check if power supply is needed, to use this ISP_JTAG_AutoPower_En MUST be set to 1
#define ISP_JTAG_FourcePower_En		1

// recommended to be the same pin as PP_PWR_CTL
#define ISP_JTAG_PowerCtrl			P(3)
#define ISP_JTAG_PowerInit()		//(PortA_SetPin(ISP_JTAG_PowerCtrl),PortA_SetOutput(ISP_JTAG_PowerCtrl))
#define ISP_JTAG_PowerFini()		//
#define ISP_JTAG_PowerOn()			HV_TargetVCC_On()//PortA_ClrPin(ISP_JTAG_PowerCtrl)
#define ISP_JTAG_PowerOff()			HV_TargetVCC_Off()//PortA_SetPin(ISP_JTAG_PowerCtrl)


/*************************** JTAG *****************************/
#define JTAG_TAP_TMS				P(4)		// STRONGLY recommended to be the same pin as SPI_SS
// MUST be SPI0 as ISP interface,so that one adaptor is enough for both ISP and JTAG.
#define JTAG_TAP_TCK				P(7)		// MUST be the same PIN as SPI_SCK
#define JTAG_TAP_TDI				P(5)		// MUST be the same PIN as SPI_MOSI
#define JTAG_TAP_TDO				P(6)		// MUST be the same PIN as SPI_MISO

#define JTAG_TAP_TMS_SETOUTPUT()	PortB_SetOutput(JTAG_TAP_TMS)
#define JTAG_TAP_TMS_SETINPUT()		PortB_SetInput(JTAG_TAP_TMS)
#define JTAG_TAP_TMS_SET()			PortB_SetPin(JTAG_TAP_TMS)
#define JTAG_TAP_TMS_CLR()			PortB_ClrPin(JTAG_TAP_TMS)

#define JTAG_TAP_TCK_SETOUTPUT()	PortB_SetOutput(JTAG_TAP_TCK)
#define JTAG_TAP_TCK_SETINPUT()		PortB_SetInput(JTAG_TAP_TCK)
#define JTAG_TAP_TCK_SET()			PortB_SetPin(JTAG_TAP_TCK)
#define JTAG_TAP_TCK_CLR()			PortB_ClrPin(JTAG_TAP_TCK)

#define JTAG_TAP_TDI_SETOUTPUT()	PortB_SetOutput(JTAG_TAP_TDI)
#define JTAG_TAP_TDI_SETINPUT()		PortB_SetInput(JTAG_TAP_TDI)
#define JTAG_TAP_TDI_SET()			PortB_SetPin(JTAG_TAP_TDI)
#define JTAG_TAP_TDI_CLR()			PortB_ClrPin(JTAG_TAP_TDI)

#define JTAG_TAP_TDO_SETINPUT()		PortB_SetInput(JTAG_TAP_TDO)
#define JTAG_TAP_TDO_GET()			PortB_GetPin(JTAG_TAP_TDO)
#define JTAG_TAP_TDO_SET()			PortB_SetPin(JTAG_TAP_TDO)
#define JTAG_TAP_TDO_CLR()			PortB_ClrPin(JTAG_TAP_TDO)

/*************************** ISP *****************************/
// if error occurs during programming with AutoSpeed set,
// just set ISP speed in AVRSutdio and AVRminiProg will disable AutoSpeed
// If U don't like it, change ISP_AutoSpeed_En to 0
// If used, an 12M or 15M osc is recommended
// There is some other configurations in ISP.h file. If problems occur, define this to 0
#define ISP_AutoSpeed_En			1

// SPI Port for ISP(SPI0 Must be used)
#define SPI_MISO					P(6)
#define SPI_MOSI					P(5)
#define SPI_SCK						P(7)
#define SPI_SS						P(4)

// in Master SPI mode,if SS is input, SS MUST be held high to ensure master SPI operation
// so configure SS to output or input with pullup, just sellect one below
// undefine both if SS pin is used as RESET control like USBasp
// SPI_SS is strongly recommended as ISP_RST and JTAG_TAP_TMS, and undefine both
//#define SPI_SS_Init()				do{PortB_SetPin(SPI_SS);PortB_SetInput(SPI_SS);}while(0)
//#define SPI_SS_Init()				PortB_SetOutput(SPI_SS)

#define SPI_SetMOSIOutput()			PortB_SetOutput(SPI_MOSI)
#define SPI_SetMOSIInput()			PortB_SetInput(SPI_MOSI)
#define SPI_SetMOSI()				PortB_SetPin(SPI_MOSI)
#define SPI_ClrMOSI()				PortB_ClrPin(SPI_MOSI)

#define SPI_SetMISOInput()			PortB_SetInput(SPI_MISO)
#define SPI_GetMISO()				PortB_GetPin(SPI_MISO)

#define SPI_SetSCKOutput()			PortB_SetOutput(SPI_SCK)
#define SPI_SetSCKInput()			PortB_SetInput(SPI_SCK)
#define SPI_SetSCK()				PortB_SetPin(SPI_SCK)
#define SPI_ClrSCK()				PortB_ClrPin(SPI_SCK)

#define ISP_RST						P(4)					// STRONGLY recommended to be the same pin as SPI_SS
#define ISP_SetRST()				PortB_SetPin(ISP_RST)
#define ISP_ClrRST()				PortB_ClrPin(ISP_RST)
#define ISP_SetRSTOutput()			PortB_SetOutput(ISP_RST)
#define ISP_SetRSTInput()			PortB_SetInput(ISP_RST)

/**************************** HV ******************************/
// HV_Test_TVCC_12V is used when U test TVCC and V12 control.It will just toggle TVCC and V12 when power on and U just check the signal.
#define HV_Test_TVCC_12V			0
// Set this to 0 if you have another 12V
// Set this to 1 to generate PWM to control Boost circuit
#define HV_12V_EN					1

#define PP_RST_CTL					P(4)
#define PP_RST_HZ_CTL				P(5)
#define PP_PWR_CTL					P(3)

#define HV_TargetReset_InitDev()	(HV_TargetReset_HZ(),PortA_SetOutput(PP_RST_HZ_CTL | PP_RST_CTL))
#define HV_TargetReset_Init()		HV_TargetReset_HZ()
#define HV_TargetReset_Fini()		HV_TargetReset_HZ()
#define HV_TargetReset_HZ()			(PortA_ClrPin(PP_RST_HZ_CTL | PP_RST_CTL))
#define HV_TargetReset_12V()		(PortA_SetPin(PP_RST_HZ_CTL),PortA_ClrPin(PP_RST_CTL))
#define HV_TargetReset_0V()			(PortA_SetPin(PP_RST_HZ_CTL | PP_RST_CTL))

#define HV_TargetVCC_Init()			(PortA_SetPin(PP_PWR_CTL),PortA_SetOutput(PP_PWR_CTL))
#define HV_TargetVCC_Fini()			PortA_SetInput(PP_PWR_CTL)
#define HV_TargetVCC_On()			PortA_ClrPin(PP_PWR_CTL)
#define HV_TargetVCC_Off()			PortA_SetPin(PP_PWR_CTL)

#define HV_12V_Sample_MUX			(ADC_VREF_BANDGAP | ADC_CHANNEL_ADC7)
#define HV_12V_Sample_Thre			822					// ((12V * R4 / (R3 + R4)) / Vbandgap) * 1024
#define HV_12V_Sample_Delta			15					// ((DeltaV * R4 / (R3 + R4)) / Vbandgap) * 1024
// 12V ------ R3 ------ ADC
//                    |
// GND ------ R4 ------
#define HV_Boost_Init()				(Boost_Stable = 0,HV_Boost_SetRate(0),PortD_SetOutput(P(7)),TCCR2 = (1 << WGM20) | (1 << WGM21) | (1 << COM21) | 1,ADMUX = HV_12V_Sample_MUX,ADC_SetINTEnable(),ADC_Start())
#define HV_Boost_Fini()				(Boost_Stable = 0,ADC_SetINTDisable(),HV_Boost_SetRate(0),PortD_SetInput(P(7)),TCCR2 = 0)
#define HV_Boost_GetRate()			OCR2
#define HV_Boost_SetRate(ocr)		(OCR2 = ocr)

/*************************** HVPP *****************************/
// HVPP Interfaces:
// XTAL1
// Ctrl Port:
// 7(O)    6(O)    5(O)    4(O) |  3(O)    2(O)    1(I)    0(O)
// PAGEL   XA1     XA0     BS1  |  nWR     nOE     RDY     BS2

#define HVPP_DATA_PORT_NAME				B
#define HVPP_CTRL_PORT_NAME				C

#define HVPP_XTAL1						P(5)
#define HVPP_XTAL1_SetOutput()			PortD_SetOutput(HVPP_XTAL1)
#define HVPP_XTAL1_SetInput()			PortD_SetInput(HVPP_XTAL1)
#define HVPP_XTAL1_Clr()				PortD_ClrPin(HVPP_XTAL1)
#define HVPP_XTAL1_Set()				PortD_SetPin(HVPP_XTAL1)

#define HVPP_SignalDelay_InUS			0		// undefine this if no delay is needed

/*************************** HVSP *****************************/
// HVSP Interfaces:
// SDO
// SDI
// SII
// SCI
#define HVSP_SDI						P(0)
#define HVSP_SII						P(1)
#define HVSP_SDO						P(2)
#define HVSP_SCI						P(5)

#define HVSP_SDO_SetOutput()			PortB_SetOutput(HVSP_SDO)
#define HVSP_SDO_SetInput()				PortB_SetInput(HVSP_SDO)
#define HVSP_SDO_Set()					PortB_SetPin(HVSP_SDO)
#define HVSP_SDO_Clr()					PortB_ClrPin(HVSP_SDO)
#define HVSP_SDO_Get()					PortB_GetPin(HVSP_SDO)

#define HVSP_SDI_SetOutput()			PortB_SetOutput(HVSP_SDI)
#define HVSP_SDI_SetInput()				PortB_SetInput(HVSP_SDI)
#define HVSP_SDI_Set()					PortB_SetPin(HVSP_SDI)
#define HVSP_SDI_Clr()					PortB_ClrPin(HVSP_SDI)

#define HVSP_SII_SetOutput()			PortB_SetOutput(HVSP_SII)
#define HVSP_SII_SetInput()				PortB_SetInput(HVSP_SII)
#define HVSP_SII_Set()					PortB_SetPin(HVSP_SII)
#define HVSP_SII_Clr()					PortB_ClrPin(HVSP_SII)

#define HVSP_SCI_SetOutput()			PortD_SetOutput(HVSP_SCI)
#define HVSP_SCI_SetInput()				PortD_SetInput(HVSP_SCI)
#define HVSP_SCI_Set()					PortD_SetPin(HVSP_SCI)
#define HVSP_SCI_Clr()					PortD_ClrPin(HVSP_SCI)

#define HVSP_ClrAltProgEnablePin()		(PortC_SetOutput(0x07),PortC_ClrPin(0x07))

/*************************** AVRUSB *****************************/
/* ---------------------------- Hardware Config ---------------------------- */
#define USB_CFG_IOPORTNAME      D
/* This is the port where the USB bus is connected. When you configure it to
 * "B", the registers PORTB, PINB and DDRB will be used.
 */
#define USB_CFG_DMINUS_BIT      4
/* This is the bit number in USB_CFG_IOPORT where the USB D- line is connected.
 * This may be any bit in the port.
 */
#define USB_CFG_DPLUS_BIT       2
/* This is the bit number in USB_CFG_IOPORT where the USB D+ line is connected.
 * This may be any bit in the port. Please note that D+ must also be connected
 * to interrupt pin INT0!
 */
#define USB_CFG_CLOCK_KHZ       (F_CPU/1000)
/* Clock rate of the AVR in MHz. Legal values are 12000, 15000, 16000 or 16500.
 * The 16.5 MHz version of the code requires no crystal, it tolerates +/- 1%
 * deviation from the nominal frequency. All other rates require a precision
 * of 2000 ppm and thus a crystal!
 * Default if not specified: 12 MHz
 */
/* ----------------------- Optional Hardware Config ------------------------ */

/* #define USB_CFG_PULLUP_IOPORTNAME   D */
/* If you connect the 1.5k pullup resistor from D- to a port pin instead of
 * V+, you can connect and disconnect the device from firmware by calling
 * the macros usbDeviceConnect() and usbDeviceDisconnect() (see usbdrv.h).
 * This constant defines the port on which the pullup resistor is connected.
 */
/* #define USB_CFG_PULLUP_BIT          4 */
/* This constant defines the bit number in USB_CFG_PULLUP_IOPORT (defined
 * above) where the 1.5k pullup resistor is connected. See description
 * above for details.
 */

/*************************** KEY *****************************/
#define PROGKEY_Pin					(1 << 0)
#define PROGKEY_Init()				do{PortD_SetPin(PROGKEY_Pin);PortD_SetInput(PROGKEY_Pin);}while(0)
#define PROGKEY_IsDown()			!PortD_GetPin(PROGKEY_Pin)

/*************************** Dataflash *****************************/

#endif		// #ifndef APP_CFG_INCLUDED
