/* Name: main.c
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2007-02-10
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <string.h>

#include "type.h"
#include "app_cfg.h"

#include "usbdrv/usbdrv.h"
#include "usbdrv/oddebug.h"

#include "MCU/gpio.h"
#include "MCU/adc.h"
#include "MCU/eeprom.h"

#include "Delay/delay.h"

#include "AVR_Device/AVR_Device_Common.h"
#include "AVR_Programming/ISP/ISP.h"
#include "AVR_Programming/JTAG/JTAG_TAP.h"
#include "AVR_Programming/HV/HV.h"
#include "AVR_Programming/HV/HVPP/HVPP.h"
#include "AVR_Programming/HV/HVSP/HVSP.h"

#if AVR_DEVICE_OFFLINE_EN
#include "AVR_Device/AVR_Phenix/AVR_Device_Phenix.h"
#include "Dataflash/dataflash.h"
#endif

#define USB_EP_SIZE						8

/******************** USB Configuration Descriptor ***********************/
PROGMEM char usbDescriptorConfiguration[] = {	/* USB configuration descriptor */
	9,		  /* sizeof(usbDescriptorConfiguration): length of descriptor in bytes */
	USBDESCR_CONFIG,	/* descriptor type */
	18 + 7 * 2 * USB_CFG_HAVE_INTRIN_ENDPOINT + (USB_CFG_DESCR_PROPS_HID & 0xff), 0,
				/* total length of data returned (including inlined descriptors) */
	1,		  /* number of interfaces in this configuration */
	1,		  /* index of this configuration */
	0,		  /* configuration name string index */
#if USB_CFG_IS_SELF_POWERED
	USBATTR_SELFPOWER,  /* attributes */
#else
	USBATTR_BUSPOWER,   /* attributes */
#endif
	USB_CFG_MAX_BUS_POWER/2,			/* max USB current in 2mA units */
/* interface descriptor follows inline: */
	9,		  /* sizeof(usbDescrInterface): length of descriptor in bytes */
	USBDESCR_INTERFACE, /* descriptor type */
	0,		  /* index of this interface */
	0,		  /* alternate setting for this interface */
	2 * USB_CFG_HAVE_INTRIN_ENDPOINT,   /* endpoints excl 0: number of endpoint descriptors to follow */
	USB_CFG_INTERFACE_CLASS,
	USB_CFG_INTERFACE_SUBCLASS,
	USB_CFG_INTERFACE_PROTOCOL,
	0,		  /* string index for interface */

	7,		  /* sizeof(usbDescrEndpoint) */
	USBDESCR_ENDPOINT,  /* descriptor type = endpoint */
	0x82,	   /* IN endpoint number 1 */
	0x02,	   /* attrib: Bulk endpoint */
	8, 0,	   /* maximum packet size */
	USB_CFG_INTR_POLL_INTERVAL, /* in ms */

	7,
	USBDESCR_ENDPOINT,
	0x02,
	0x02,
	8, 0,
	USB_CFG_INTR_POLL_INTERVAL,
};

/******************** State Machine Simplified(for USB_EP_LEN = 8) ***********************/
#if (AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII) || (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON)
uint8 StateMachine_State = STATEMACHINE_MESSAGE_START;
uint16 StateMachine_LastSequenceNumber = 0xFFFF;
uint16 StateMachine_SequenceNumber_tmp = 0;

#define StateMachine_GetData(d)			*((uint8*)d + StateMachine_DateLen_tmp++) = dat[i]
#define StateMachine_DataGot()			(StateMachine_DateLen_tmp == StateMachine_DataLen)
#define StateMachine_Reset()			(StateMachine_State = STATEMACHINE_MESSAGE_START)
#endif

void usbFunctionWriteOut(uchar *data, uchar len)
{
#if (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRISP_MKII)
	memcpy(AVR_Device_DataBuff + CMD_Len_tmp,data,len);
	CMD_Len_tmp += len;

	if((len < USB_EP_SIZE) ||
	// WriteFlash or WriteEEPROM
	(((AVR_Device_DataBuff[0] == 0x13) || (AVR_Device_DataBuff[0] == 0x15)) && ((((uint16)(AVR_Device_DataBuff[1] & 1) << 8) | AVR_Device_DataBuff[2]) == (CMD_Len_tmp - 10))) ||
	// SPI_MULTI
	((AVR_Device_DataBuff[0] == 0x1D) && (AVR_Device_DataBuff[1] == (CMD_Len_tmp - 4))) )
	{
		CMD_Len = CMD_Len_tmp;
		CMD_Len_tmp = 0;
	}
#elif (AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII) || (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON)
	static uint16 tmp_len;

	switch(StateMachine_State)
	{
	case STATEMACHINE_MESSAGE_START:
		memcpy(&StateMachine_SequenceNumber_tmp,&data[1],2);
		memcpy(&tmp_len,&data[3],2);
		if(StateMachine_SequenceNumber_tmp == 0)
			StateMachine_LastSequenceNumber = 0xFFFF;
		// first Packet MUST be 8-byte in length	first byte MUST be '0x1B'			7th byte MUST be '0E'		high 16-bit of message len MUST be 0	Sequence Number MUST be valid
		if((len != USB_EP_SIZE) ||					(data[0] != MESSAGE_START_CHAR) ||	(data[7] != TOKEN_CHAR) ||	(data[5] != 0) || (data[6] != 0) /*||		(StateMachine_SequenceNumber_tmp != (StateMachine_LastSequenceNumber + (StateMachine_LastSequenceNumber == 0xFFFE ? 2 : 1)))*/)
		{
			// State Machine Error,Reset
			StateMachine_Reset();
		}
		else
		{
			// State Machine OK,Receiving Data
			StateMachine_LastSequenceNumber++;
			StateMachine_State = STATEMACHINE_MESSAGE_BODY;
			memcpy(AVR_Device_DataBuff,data,USB_EP_SIZE);
			CMD_Len_tmp = USB_EP_SIZE;
		}
		break;
	case STATEMACHINE_MESSAGE_BODY:
		memcpy(AVR_Device_DataBuff + CMD_Len_tmp,data,len);
		CMD_Len_tmp += len;

		if(CMD_Len_tmp >= tmp_len + 10)
			CMD_Len = tmp_len + 10;
		break;
	default:
		StateMachine_Reset();
		break;
	}
#endif
}

uchar usbFunctionSetup(uchar data[8])
{
	return 0;
}

uchar usbFunctionDescriptor(usbRequest_t *rq) {
	/* if(rq->wValue.bytes[1] == USBDESCR_CONFIG){ */
	/* no check required, we only use this for config descriptor */
	usbMsgPtr = (uchar *)usbDescriptorConfiguration;
	return sizeof(usbDescriptorConfiguration);
}

void Sys_Init(void)
{
#if AVR_DEVICE_OFFLINE_EN
	PROGKEY_Init();
#endif
	LED_Init();

#if AVRP_ISP_SHOULD_ENABLE || AVRP_JTAG_SHOULD_ENABLE
#if ISP_JTAG_AutoPower_En
	ISP_JTAG_PowerInit();
#endif
#endif

#if AVRP_ISP_SHOULD_ENABLE
	Program_Speed = EEPROM_Read(0);
	if(Program_Speed > 163)
	{
		Program_Speed = 0;
		EEPROM_Write(0,Program_Speed);
	}
	ISP_Fini();
#endif

#if AVRP_JTAG_SHOULD_ENABLE
	JTAG_TAP_Fini();
#endif

#if AVRP_HVPP_SHOULD_ENABLE || AVRP_HVSP_SHOULD_ENABLE
	HV_TargetReset_InitDev();
	HV_TargetVCC_Init();
#if AVRP_HVPP_SHOULD_ENABLE
	HVPP_Fini();
#endif
#if AVRP_HVSP_SHOULD_ENABLE
	HVSP_Fini();
#endif
#endif

#if AD_En || AVRP_HVPP_SHOULD_ENABLE || AVRP_HVSP_SHOULD_ENABLE
	ADC_Init();
#endif

	// USB Init.
	//++++++++++++++++++++++++++++++++++++ USB Reset
	{
	uchar i, j;
	/* pull-ups USB */
	USBOUT &= ~((1<<USB_CFG_DMINUS_BIT)|(1<<USB_CFG_DPLUS_BIT));
#ifdef USB_CFG_PULLUP_IOPORT
	USBDDR &= ~((1<<USB_CFG_DMINUS_BIT)|(1<<USB_CFG_DPLUS_BIT));
	usbDeviceDisconnect();
#else
	USBDDR |= (1<<USB_CFG_DMINUS_BIT)|(1<<USB_CFG_DPLUS_BIT); 
#endif
	j = 0;
	while(--j){ /* USB Reset by device only required on Watchdog Reset */
	i = 0;
	while(--i); /* delay >10ms for USB reset */
	}

	// remove USB reset condition
#ifdef USB_CFG_PULLUP_IOPORT
	usbDeviceConnect();
#else
	USBDDR &= ~((1<<USB_CFG_DMINUS_BIT)|(1<<USB_CFG_DPLUS_BIT));
#endif
	}

	usbInit();
}

int main(void)
{
extern uchar usbNewDeviceAddr;
	uint16 RSP_Pkg_Len;
	uint8 AD_Dly = 0;

	Sys_Init();
	sei();

#if HV_Test_TVCC_12V
// Test TVCC and V12
HV_Init();
do{
HV_TargetVCC_On();
HV_TargetReset_12V();
DelayMS(10);
HV_TargetVCC_Off();
HV_TargetReset_0V();
DelayMS(10);
}while(1);
#endif

	usbSetInterrupt(0, 0);		/* the host eats the first packet -- don't know why... */

	for(;;){	/* main event loop */
		if(!--AD_Dly)
		{
			if(usbNewDeviceAddr)
				LED_On(LED_Green);
#if AVR_DEVICE_OFFLINE_EN
			else if(PROGKEY_IsDown())
			{
				while(PROGKEY_IsDown());
				AVRP_Phenix_Main();				// never return
			}
#endif

			if(AVRP_Programming)
			{
				if(LED_IsOn(LED_Red))
					LED_Off(LED_Red);
				else
					LED_On(LED_Red);
			}
			else
			{
#if AD_En
#if AVR_DEVICE_ATMEL == AVR_DEVICE_AVRISP_MKII
				Vtarget = (uint8)((uint16)ADC_Convert(AD_VCC_MUX) * (ADVref * AD_VCC_RATE) / 256);
#elif (AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII) || (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON)
				Vtarget = (uint16)((uint16)ADC_Convert(AD_VCC_MUX) * (ADVref * AD_VCC_RATE) / 256) * 100;
#endif
				if(Vtarget > Vtarget_HasPower)
					LED_On(LED_Red);
				else
					LED_Off(LED_Red);
#else
				LED_On(LED_Red);
#endif
			}
		}

		usbPoll();

		// Check if Data Received
		if(CMD_Len)
		{
			// Process Message
			AVR_Device_ProcessCmd(AVR_Device_DataBuff,CMD_Len);
#if (AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII) || (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON)
			StateMachine_Reset();
#endif
			CMD_Len = 0;
		}

#if AVRD_JTAG_SHOULD_ENABLE || AVRD_DW_SHOULD_ENABLE
		if(!RSP_Len)
		{
			AVR_Device_CheckEvent();
		}
#endif

		// Check if Data need to be send
		if(RSP_Len && usbInterruptIsReady())
		{
#if (AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII) || (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON)
			uint16 i;

			// avrdude will eat first 8-byte package(maybe it is libusb who eats it), so just send a ZLP first
			if(Send_Sign_On)
			{
				Send_Sign_On = 0;
				usbSetInterrupt(0, 0);
				continue;
			}

			if(!RSP_Len_tmp)
			{
				AVR_Device_DataBuff[1] = StateMachine_SequenceNumber_tmp;
				AVR_Device_DataBuff[2] = StateMachine_SequenceNumber_tmp >> 8;

				AVR_Device_DataBuff[3] = RSP_Len;
				AVR_Device_DataBuff[4] = RSP_Len >> 8;

				// Calc. CRC
				CRC_Val = CRC_INIT;
				for(i = 0;i < RSP_Len + 8;i++)
					CRC16(AVR_Device_DataBuff[i]);
				memcpy(&AVR_Device_DataBuff[RSP_Len + 8],&CRC_Val,2);

				RSP_Len += 10;
			}
#endif

			RSP_Pkg_Len = RSP_Len - RSP_Len_tmp;
			if(RSP_Pkg_Len > USB_EP_SIZE)
				RSP_Pkg_Len = USB_EP_SIZE;
			usbSetInterrupt((uchar*)&AVR_Device_DataBuff + RSP_Len_tmp,RSP_Pkg_Len);
			RSP_Len_tmp += RSP_Pkg_Len;

			if(RSP_Pkg_Len < USB_EP_SIZE)
			{
				RSP_Len = 0;
				RSP_Len_tmp = 0;
			}
		}
	}

	return 0;
}
