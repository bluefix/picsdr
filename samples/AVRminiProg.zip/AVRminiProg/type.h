#ifndef __TYPE_H_INCLUDED__

#define __TYPE_H_INCLUDED__
typedef unsigned char uint8;
typedef signed char int8;
typedef unsigned int uint16;
typedef signed int int16;
typedef unsigned long long uint32;
typedef signed long long int32;

typedef union{
	uint16	word;
	uint8	bytes[2];
}t_u16;

typedef union{
	uint32	dword;
	uint16	word[2];
	uint8	bytes[4];
}t_u32;

#endif
