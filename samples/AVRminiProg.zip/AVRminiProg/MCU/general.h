
#ifndef __GENERAL__
#define __GENERAL__

/******************** General definations **********************/
#define RegSetRgn(REG,MSK,VAL)				((REG) = ((REG) & ~(MSK)) | (VAL))

#define RegGetRgn(REG,MSK)					((REG) & (MSK))

#define SetBit(REG,BIT)						((REG) |= _BV((BIT)))
#define ClearBit(REG,BIT)					((REG) &= ~_BV((BIT)))

#define SetMsk(REG,MSK)						((REG) |= (MSK))
#define ClearMsk(REG,MSK)					((REG) &= ~(MSK))

#define dimof(str)							(sizeof((str)) / sizeof((str)[0]))

//#define _BV(BIT)							(1 << (BIT))
//#define loop_until_bit_is_set(REG,BIT)		while(!((REG) & _BV(BIT)))
//#define loop_until_bit_is_clear(REG,BIT)	while((REG) & _BV(BIT))
//#define bit_is_set(REG,BIT)					((REG) & _BV((BIT)))
//#define bit_is_clear(REG,BIT)				(!bit_is_set(REG,BIT))
#define Msk_is_set(REG,MSK)					(((REG) & (MSK)) == (MSK))
#define Msk_is_clear(REG,MSK)				(!((REG) & (MSK)))

//#define sei()								__enable_interrupt()
//#define cli()								__disable_interrupt()

#define nop()								__no_operation()

#endif
