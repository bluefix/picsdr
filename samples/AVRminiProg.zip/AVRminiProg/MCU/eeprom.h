#define EEPROM_SIZE		256		// Bytes

#define EEPROM_PM_MSK						(_BV(EEPM0) | _BV(EEPM1))
#define EEPROM_PM_RW						0
#define EEPROM_PM_RO						_BV(EEPM0)
#define EEPROM_PM_WO						_BV(EEPM1)






#define EEPROM_SetProgramMode(MODE)			(RegSetRgn(EECR,EEPROM_PM_MSK,(MODE)))
#define EEPROM_SetWriteEn()					SetBit(EECR,EEMPE)//(EECR |= _BV(EEMPE))
#define EEPROM_SetWrite()					SetBit(EECR,EEPE)//(EECR |= _BV(EEPE))
#define EEPROM_SetRead()					SetBit(EECR,EEWE)//(EECR |= _BV(EEWE))

#define EEPROM_WaitReadEnable()				(wait_until_bit_is_clear(EECR,EEWE))
#define EEPROM_WaitWriteEnable()			(wait_until_bit_is_clear(EECR,EEPE))

#define EEPROM_SetINTEnable()				SetBit(EECR,EERIE)//(EECR |= _BV(EERIE))

void EEPROM_Write(uint16 Addr,uint8 Data);
uint8 EEPROM_Read(uint16 Addr);
void EEPROM_Init();
