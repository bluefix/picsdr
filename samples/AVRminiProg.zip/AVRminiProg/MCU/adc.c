#include <avr/io.h>
#include "../type.h"
#include "../app_cfg.h"

#include "general.h"
#include "adc.h"

#include "../AVR_Device/AVR_Device_Common.h"

#if AD_En

#if HV_12V_EN && (AVRP_HVPP_SHOULD_ENABLE || AVRP_HVSP_SHOULD_ENABLE)
volatile uint8 Boost_Stable = 0;

void SIG_ADC(void) __attribute__ ((interrupt));
void SIG_ADC(void)
{
	uint8 pwm_rate;
	uint16 value = ADC_GetVal16();
	static uint8 Stable_Cnt = 0;

	pwm_rate = HV_Boost_GetRate();
	if((value > (HV_12V_Sample_Thre + HV_12V_Sample_Delta)) && (pwm_rate > 0))
	{
		pwm_rate--;
		Stable_Cnt = 0;
		Boost_Stable = 0;
	}
	else if((value < (HV_12V_Sample_Thre - HV_12V_Sample_Delta)) && (pwm_rate < 0xFF))
	{
		pwm_rate++;
		Stable_Cnt = 0;
		Boost_Stable = 0;
	}
	else
	{
		if(!++Stable_Cnt)
			Boost_Stable = 1;
	}
	HV_Boost_SetRate(pwm_rate);

	ADC_Start();
}
#endif

ADC_DATATYPE ADC_Convert(uint8_t MUX)
{
	ADMUX = MUX | ADC_ALIGN_LEFT;

	ADC_Start();
	ADC_WaitRdy();
	ADC_ClearINTFlag();

	return ADC_GetValH8();
}

void ADC_Init()
{
	ADMUX = AD_VCC_MUX | ADC_ALIGN_LEFT;
	ADCSRA = ADC_CLK_DIV128 | ADC_INTFlag | _BV(ADEN);

	// do a dummy readout first
	ADC_Start();
}

#endif		// #if AD_En
