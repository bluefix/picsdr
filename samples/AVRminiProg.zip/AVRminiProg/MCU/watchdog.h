#define WDT_CLK_DIV2K				0
#define WDT_CLK_DIV4K				_BV(WDP0)
#define WDT_CLK_DIV8K				_BV(WDP1)
#define WDT_CLK_DIV16K				(_BV(WDP0) | _BV(WDP1))
#define WDT_CLK_DIV32K				_BV(WDP2)
#define WDT_CLK_DIV64K				(_BV(WDP0) | _BV(WDP2))
#define WDT_CLK_DIV128K				(_BV(WDP1) | _BV(WDP2))
#define WDT_CLK_DIV256K				(_BV(WDP0) | _BV(WDP1) | _BV(WDP2))
#define WDT_CLK_DIV512K				_BV(WDP3)
#define WDT_CLK_DIV1024K			(_BV(WDP0) | _BV(WDP3))




#define WDT_Reset()					wdt_reset()

#define WDT_SetINTEnable()			SetBit(WDTCSR,WDIE)
#define WDT_SetINTDisable()			ClearBit(WDTCSR,WDIE)
#define WDT_IsINTEnable()			bit_is_set(WDTCSR,WDIE)
#define WDT_ClearINTFlag()			SetBit(WDTCSR,WDIF)
#define WDT_IsINTSet()				bit_is_set(WDTCSR,WDIF)

#define WDT_SetIntMode(CLK)			(WDTCSR = _BV(WDCE) | _BV(WDIE),WDTCSR = _BV(WDIE) | (CLK))
#define WDT_SetRstMode(CLK)			(WDTCSR = _BV(WDCE) | _BV(WDE),WDTCSR = _BV(WDE) | (CLK))
#define WDT_SetIntRstMode(CLK)		(WDTCSR = _BV(WDCE) | _BV(WDIE) | _BV(WDE),WDTCSR = _BV(WDE) | _BV(WDIE) | (CLK))
