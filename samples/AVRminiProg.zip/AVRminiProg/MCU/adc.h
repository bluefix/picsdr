
#define ADC_INT_EN			_BV(ADIE)
#define ADC_INT_DIS			0

#define ADC_VREF_MSK		(_BV(REFS0) | _BV(REFS1))
#define ADC_VREF_AREF		(0)
#define ADC_VREF_AVCC		(_BV(REFS0))
#define ADC_VREF_BANDGAP	(_BV(REFS0) | _BV(REFS1))		// Internal 1.1V

#define ADC_ALIGN_MSK		_BV(ADLAR)
#define ADC_ALIGN_LEFT		_BV(ADLAR)
#define ADC_ALIGN_RIGHT		0

#define ADC_CHANNEL_MSK		(_BV(MUX0) | _BV(MUX1) | _BV(MUX2) | _BV(MUX3))
#define ADC_CHANNEL_ADC0	0
#define ADC_CHANNEL_ADC1	1
#define ADC_CHANNEL_ADC2	2
#define ADC_CHANNEL_ADC3	3
#define ADC_CHANNEL_ADC4	4
#define ADC_CHANNEL_ADC5	5
#define ADC_CHANNEL_ADC6	6
#define ADC_CHANNEL_ADC7	7
#define ADC_CHANNEL_BANDGAP	14
#define ADC_CHANNEL_GND		15

#define ADC_CLK_MSK			(_BV(ADPS0) | _BV(ADPS1) | _BV(ADPS2))
#define ADC_CLK_DIV2		_BV(ADPS0)
#define ADC_CLK_DIV4		_BV(ADPS1)
#define ADC_CLK_DIV8		(_BV(ADPS0) | _BV(ADPS1))
#define ADC_CLK_DIV16		_BV(ADPS2)
#define ADC_CLK_DIV32		(_BV(ADPS0) | _BV(ADPS2))
#define ADC_CLK_DIV64		(_BV(ADPS1) | _BV(ADPS2))
#define ADC_CLK_DIV128		(_BV(ADPS0) | _BV(ADPS1) | _BV(ADPS2))

#define ADC_ATS_MSK			(_BV(ADTS0) | _BV(ADTS1) | _BV(ADTS2))
#define ADC_ATS_FreeRun		(0)
#define ADC_ATS_AnalogComp	(_BV(ADTS0))
#define ADC_ATS_EINT0		(_BV(ADTS1))
#define ADC_ATS_T0OCA		(_BV(ADTS0) | _BV(ADTS1))
#define ADC_ATS_T0OV		(_BV(ADTS2))
#define ADC_ATS_T1OCB		(_BV(ADTS0) | _BV(ADTS2))
#define ADC_ATS_T1OV		(_BV(ADTS1) | _BV(ADTS2))
#define ADC_ATS_T1IC		(_BV(ADTS0) | _BV(ADTS1) | _BV(ADTS2))

#define ADC_INTFlag			_BV(ADIF)



#define ADC_P(n)				_BV((n))

#define ADC_DisableDigitalInput(n)	SetMsk(DIDR0,(n))
#define ADC_EnableDigitalInput(n)	ClearMsk(DIDR0,(n))

#define ADC_SetVREF(VREF)			RegSetRgn(ADMUX,ADC_VREF_MSK,(VREF))
#define ADC_GetVREF()				RegGetRgn(ADCMUX,ADC_VREF_MSK)

#define ADC_SetAlign(ALIGN)			RegSetRgn(ADMUX,ADC_ALIGN_MSK,(ALIGN))
#define ADC_SetAlignLeft()			SetMsk(ADMUX,ADC_ALIGN_LEFT)
#define ADC_SetAlignRight()			ClearMsk(ADMUX,ADC_ALIGN_LEFT)
#define ADC_GetAlign()				RegGetRgn(ADMUX,ADC_ALIGN_MSK)

#define ADC_SetChannel(CHANNEL)		RegSetRgn(ADMUX,ADC_CHANNEL_MSK,(CHANNEL))
#define ADC_GetChannel()			RegGetRgn(ADMUX,ADC_CHANNEL_MSK)

#define ADC_GetMUX()				ADMUX

#define ADC_Enable()				SetBit(ADCSRA,ADEN)
#define ADC_Disable()				ClearBit(ADCSRA,ADEN)
#define ADC_IsEnable()				bit_is_set(ADCSRA,ADEN)

#define ADC_Start()					SetBit(ADCSRA,ADSC)
#define ADC_IsRdy()					bit_is_set(ADCSRA,ADIF)
#define ADC_WaitRdy()				loop_until_bit_is_clear(ADCSRA,ADSC)

#define ADC_SetINTEnable()			SetBit(ADCSRA,ADIE)
#define ADC_SetINTDisable()			ClearBit(ADCSRA,ADIE)
#define ADC_IsINTEnable()			bit_is_set(ADCSRA,ADIE)
#define ADC_ClearINTFlag()			SetBit(ADCSRA,ADIF)

#define ADC_SetCLK(CLK)				RegSetRgn(ADCSRA,ADC_CLK_MSK,(CLK))
#define ADC_GetCLK()				RegGetRgn(ADCSRA,ADC_CLK_MSK)

#define ADC_GetVal16()				(ADC)
#define ADC_GetValH8()				(ADCH)
#define ADC_GetValL8()				(ADCL)

#define ADC_SetATS(SRC)				RegSetRgn(ADCSRA,ADC_ATS_MSK,SRC)		// Set AutoTriggleSource
#define ADC_GetATS()				RegGetRgn(ADCSRA,ADC_ATS_MSK)
#define ADC_EnableAutoTrigger(SRC)	(ADC_SetATS(SRC),SetBit(ADCSRA,ADATE))
#define ADC_DisableAutoTrigger()	ClearBit(ADCSRA,ADATE)
#define ADC_IsAutoTriggerEnable()	is_bit_set(ADCSRA,ADATE)


void ADC_Init();
#define ADC_DATATYPE	uint8_t
ADC_DATATYPE ADC_Convert(uint8_t MUX);
