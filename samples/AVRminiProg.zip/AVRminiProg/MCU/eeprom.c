#include <avr/io.h>

#include "../type.h"
#include "../app_cfg.h"

#ifndef EEPE
#define EEPE EEWE
#endif

#ifndef EEMPE
#define EEMPE EEMWE
#endif

#if AVRP_ISP_SHOULD_ENABLE
void EEPROM_Write(uint16 Addr,uint8 Data)
{
	// Wait for completion of previous write
	loop_until_bit_is_clear(EECR,EEPE);

	EEAR	= Addr;
	EEDR	= Data;

	EECR	|= _BV(EEMPE);
	EECR	|= _BV(EEPE);
}

uint8 EEPROM_Read(uint16 Addr)
{
	loop_until_bit_is_clear(EECR,EEPE);

	EEAR	= Addr;

	EECR	|= _BV(EERE);

	return EEDR;
}
#endif		// #if AVRP_ISP_SHOULD_ENABLE
