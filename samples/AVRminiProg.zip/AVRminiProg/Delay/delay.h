#define DelayNS(d)

void DelayShort(void);
void DelayUS(uint8);
void DelayMS(uint8);
