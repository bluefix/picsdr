#include "../type.h"
#include "../app_cfg.h"

/******************** Delay ***********************/
void DelayUS(uint8 dly)
{
	while(dly--)
	{
		__asm("nop");
//		__asm("nop");
//		__asm("nop");
//		__asm("nop");
	}
}

void DelayMS(uint8 dly)
{
	while(dly-- > 0)
	{
		DelayUS(250);
		DelayUS(250);
		DelayUS(250);
		DelayUS(250);
	}
}
