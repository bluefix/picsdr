/* Name: AVR_Device_JTAG.c
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2007-02-11
 */
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <string.h>

#include "../../type.h"
#include "../../app_cfg.h"

#include "../../MCU/gpio.h"

#include "../../Delay/delay.h"

#include "../AVR_Device_Common.h"

#include "AVR_Device_JTAG.h"

#include "../../AVR_Programming/JTAG/JTAG_TAP.h"
#include "../../AVR_Programming/JTAG/AVR_JTAG.h"

#if AVRD_JTAG_SHOULD_ENABLE
#include "../../AVR_Debugging/AVR_Instr.h"
#include "../../AVR_Debugging/JTAG/AVR_JTAGOCD.h"
#endif

#if AVRD_DW_SHOULD_ENABLE
#include "../../AVR_Debugging/DW/AVR_DWOCD.h"
#endif

#if (AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII) || (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON)

#if AVRP_JTAG_SHOULD_ENABLE

uint32 JTAGID_String;

#if AVRD_JTAG_SHOULD_ENABLE
// Used in JTAGICE_CMND_SET_DEVICE_DESCRIPTOR
uint8 ucReadIO[8];
uint8 ucReadIOShadow[8];
uint8 ucWriteIO[8];
uint8 ucWriteIOShadow[8];
uint8 ucReadExtIO[52];
uint8 ucReadIOExtShadow[52];
uint8 ucWriteExtIO[52];
uint8 ucWriteIOExtShadow[52];
uint8 ucIDRAddress;
uint8 ucSPMCRAddress;
uint32 ulBootAddress;
uint8 ucRAMPZAddress;
uint16 uiUpperExtIOLoc;
uint32 ulFlashSize;
uint8 ucEepromInst[20];
uint8 ucFlashInst[3];
uint8 ucSPHaddr;
uint8 ucSPLaddr;
uint16 uiFlashpages;
uint8 ucDWDRAddress;
uint8 ucDWBasePC;
uint16 uiStartSmallestBootLoaderSection;
uint8 ucEnablePageProgramming;
uint8 ucCacheType;
uint16 uiSramStartAddr;
uint8 ucResetType;
uint8 ucPCMaskExtended;
uint8 ucPCMaskHigh;
uint8 ucEindAddress;
uint16 uiEECRAddress;
#endif
uint8 uiFlashPageSize;			// Device Flash Page Size in word
uint8 ucEepromPageSize;			// Device Eeprom Page Size in bytes
uint8 ucAllowFullPageBitstream;

#endif

#define AVR_Device_MakeVersion(MMajor,MMinor,SMajor,SMinor)		(((uint32)MMajor << 24) | ((uint32)MMinor << 16) | ((uint32)SMajor << 8) | SMinor)
#define JTAGICE_mkII_FW_Version			AVR_Device_MakeVersion(JTAGICE_mkII_MFW_MAJOR_VER,JTAGICE_mkII_MFW_MINOR_VER,JTAGICE_mkII_SFW_MAJOR_VER,JTAGICE_mkII_SFW_MINOR_VER)
#define AVRDragon_FW_Version			AVR_Device_MakeVersion(AVRDragon_MFW_MAJOR_VER,AVRDragon_MFW_MINOR_VER,AVRDragon_SFW_MAJOR_VER,AVRDragon_SFW_MINOR_VER)

#if AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII
uint8 AVR_Device_comm_id			= JTAGICE_mkII_COMM_ID;
uint8 AVR_Device_m_mcu_bldr			= JTAGICE_mkII_MBootload_VER;
uint8 AVR_Device_s_mcu_bldr			= JTAGICE_mkII_SBootload_VER;
uint8 AVR_Device_serial_number[6]	= JTAGICE_mkII_SerialNumber;
uint16 AVR_Device_HW_Version = JTAGICE_mkII_HW_VER;
uint32 AVR_Device_FW_Version = JTAGICE_mkII_FW_Version;
#elif AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON
uint8 AVR_Device_comm_id			= AVRDragon_COMM_ID;
uint8 AVR_Device_m_mcu_bldr			= AVRDragon_MBootload_VER;
uint8 AVR_Device_s_mcu_bldr			= AVRDragon_SBootload_VER;
uint8 AVR_Device_serial_number[6]	= AVRDragon_SerialNumber;
uint16 AVR_Device_HW_Version = AVRDragon_HW_VER;
uint32 AVR_Device_FW_Version = AVRDragon_FW_Version;
#endif

void _AVRP_JTAG_RSP_GET_SIGN_ON()
{
#if AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII
	PrepareRSP(RSP_SIGN_ON,29);
#else
	PrepareRSP(RSP_SIGN_ON,26);
#endif

	AVR_Device_DataBuff[9]	= AVR_Device_comm_id;
	AVR_Device_DataBuff[10] = AVR_Device_m_mcu_bldr;
	memcpy(&AVR_Device_DataBuff[11],(uint8*)&AVR_Device_FW_Version + 2,2);
	AVR_Device_DataBuff[13]= *((uint8*)&AVR_Device_HW_Version + 1);
	AVR_Device_DataBuff[14]= AVR_Device_s_mcu_bldr;
	memcpy(&AVR_Device_DataBuff[15],&AVR_Device_FW_Version,2);
	AVR_Device_DataBuff[17]= AVR_Device_HW_Version & 0xFF;
	memcpy(&AVR_Device_DataBuff[18],AVR_Device_serial_number,6);
	memcpy(&AVR_Device_DataBuff[18 + sizeof(AVR_Device_serial_number)],AVR_Device_Name,sizeof(AVR_Device_Name));

	Send_Sign_On = 1;
}

uint8 AVRP_JTAG_ProcessProgCmd(uint8* dat,uint16 len)
{
#if AVRD_JTAG_SHOULD_ENABLE || AVRD_DW_SHOULD_ENABLE
	uint16 startaddr,length;
#endif
#if AVRP_JTAG_SHOULD_ENABLE
	uint16 i;
	uint8 highbyte,lowbyte,fuse_tmp[3],tmp8;
#endif

	switch(dat[8])
	{
	case JTAGICE_CMND_SIGN_OFF:
		_RSP_OK();
		break;
	case JTAGICE_CMND_GET_SIGN_ON:
		_AVRP_JTAG_RSP_GET_SIGN_ON();
		break;
	case JTAGICE_CMND_SET_PARAMETER:
#if AVRP_JTAG_SHOULD_ENABLE
		switch(dat[9])
		{
#if AVRD_JTAG_SHOULD_ENABLE
		case 0x03:// EmulateMode
			Emulator_Mode = dat[10];
#endif
		case 0x07:// OCD JTAG Clock
			JTAG_Clock = dat[10];
			break;
#if AVRD_JTAG_SHOULD_ENABLE
		case 0x1F:// ProgramEntryPoint
			memcpy(&Program_Entry_Point,dat + 10,4);
			break;
		case 0x29:
		{
			if(!AVRP_Programming)
			{
				AVRP_Programming = 2;
				JTAG_TAP_Init();
				JTAG_TAP_Reset();
			}

			AVR_JTAGOCD_Init();

			// Enable PSB0 for ProgramEntryPoint Break
			AVR_JTAGOCD_WriteOCD(AVR_JTAG_OCDREG_PSB0,(uint8*)&Program_Entry_Point);
			AVR_JTAGOCD_ReadOCD(AVR_JTAG_OCDREG_BCR,tdo);
			tdi[0] = 0;
			tdi[1] = AVR_JTAG_BCR_EN_PSB0;
			AVR_JTAGOCD_WriteOCD(AVR_JTAG_OCDREG_BCR,tdi);
#if 0
// For Test

// Release Reset
AVR_JTAG_SendIns(JTAG_INS_AVR_RESET);
JTAG_TAP_Data_1Byte(0,1,JTAG_TAP_ENTER_IDLE);

// Wait to break on ProgrmEntryPoint
DelayMS(200);

//AVR_JTAGOCD_ReadOCD(AVR_JTAG_OCDREG_BSR,tdi);

//AVR_JTAGOCD_ReadOCD(AVR_JTAG_OCDREG_COMM_CTL,tdo);
//AVR_JTAGOCD_ReadOCD(AVR_JTAG_OCDREG_BCR,tdo);
//tdi[0] = tdi[1] = 0;
//AVR_JTAGOCD_WriteOCD(AVR_JTAG_OCDREG_BCR,tdi);

//AVR_JTAGOCD_CheckPC(tdo);
//AVRI_RJMP_k(-6);
AVRI_RunInstr(0x02,0xC0);	// 0xC002		RJMP 6
AVR_JTAGOCD_CheckPC(tdo);
//AVR_JTAGOCD_CheckPC(tdo);
//AVR_JTAGOCD_CheckPC(tdo);

// Enable OCDR,change OCDR,read OCDR    OK
//AVR_JTAGOCD_ReadOCD(AVR_JTAG_OCDREG_COMM_CTL,tdo);
//tdo[1] |= AVR_JTAG_CTL_EN_OCDR;
//AVR_JTAGOCD_WriteOCD(AVR_JTAG_OCDREG_COMM_CTL,tdo);
//AVRI_LDI_Rd_K(16,0xA5);			// LDI R16,0xA5
//AVRI_OUT_A_Rr(ucIDRAddress,16);	// OUT ucIDRAddress,R16
//AVR_JTAGOCD_ReadOCDR(tdo);

dat[9] = tdo[0];
dat[10] = tdo[1];
dat[11] = tdo[2];
dat[12] = tdo[3];
dat[13] = tdi[0];
dat[14] = tdi[1];
dat[15] = tdi[2];
dat[16] = tdi[3];
_RSP_MEMORY(8);
return 0;
#endif
		}
			break;
		default:
			//_RSP_ILLEGAL_PARAMETER();
			break;
#endif
		}
#endif
		_RSP_OK();
		break;
	case JTAGICE_CMND_GET_PARAMETER:
		switch(dat[9])		// Parameter ID
		{
		case 0x01:			// Hardware Version
			PrepareRSP(RSP_PARAMETER,3);
			memcpy(&dat[9],(uint8*)&AVR_Device_HW_Version,2);
			break;
		case 0x02:			// FW Version
			PrepareRSP(RSP_PARAMETER,5);
			memcpy(&dat[9],(uint8*)&AVR_Device_FW_Version,4);
			break;
		case 0x06:			// OCD_Vtarget
			PrepareRSP(RSP_PARAMETER,3);
			dat[9] = Vtarget;
			dat[10] = Vtarget >> 8;
			break;
#if AVRP_JTAG_SHOULD_ENABLE
		case 0x07:			// OCD JTAG Clock
			PrepareRSP(RSP_PARAMETER,2);
			dat[9] = JTAG_Clock;
			break;
		case 0x0E:			// JTAGID_String
			if(!AVRP_Programming)
			{
#if ISP_JTAG_AutoPower_En
#if !ISP_JTAG_FourcePower_En
				if(Vtarget < Vtarget_HasPower)
#endif
				{
					ISP_JTAG_PowerOn();
					DelayMS(5);
				}
#endif
				JTAG_TAP_Init();
				JTAG_TAP_Reset();
			}
			AVR_JTAG_SendIns(JTAG_INS_IDCODE);

			JTAG_TAP_Data(0,(uint8*)&JTAGID_String,JTAG_REG_JTAGID_Len,JTAG_TAP_ENTER_IDLE);

			if(!AVRP_Programming)
			{
#if ISP_JTAG_AutoPower_En
				ISP_JTAG_PowerOff();
#endif
				JTAG_TAP_Fini();
			}

			PrepareRSP(RSP_PARAMETER,5);
			memcpy(&dat[9],&JTAGID_String,4);
			break;
#endif
		default:
			_RSP_ILLEGAL_PARAMETER();
			break;
		}
		break;
#if AVRP_JTAG_SHOULD_ENABLE
	case JTAGICE_CMND_WRITE_MEMORY:
#if AVRD_JTAG_SHOULD_ENABLE
		startaddr = dat[14] + ((uint16)dat[15] << 8);
		length = dat[10] + ((uint16)dat[11] << 8);
#endif
		switch(dat[9])
		{
#if AVRD_JTAG_SHOULD_ENABLE
		case MEMORY_TYPE_IO_SHADOW:
			break;
		case MEMORY_TYPE_SRAM:
			break;
		case MEMORY_TYPE_EEPROM:
			break;
		case MEMORY_TYPE_EVENT:
			break;
		case MEMORY_TYPE_EVENT + 1:
			_RSP_OK();
			break;
		case MEMORY_TYPE_SPM:
			break;
#endif
		case MEMORY_TYPE_FLASH_PAGE:
			dat[14] >>= 1;
			if(dat[15] & 0x01)
				dat[14] |= 0x80;
			dat[15] >>= 1;
			if(dat[16] & 0x01)
				dat[15] |= 0x80;

			highbyte = dat[15];
			lowbyte = dat[14];

			AVR_JTAG_SendIns(JTAG_INS_PROG_COMMANDS);
			JTAG_PROG_EnterFlashWrite();
			if(dat[17])
				JTAG_PROG_LoadAddrExtendedHighByte(1);
			JTAG_PROG_LoadAddrHighByte(highbyte);

			JTAG_PROG_LoadAddrLowByte(lowbyte);
			AVR_JTAG_SendIns(JTAG_INS_PROG_PAGELOAD);

			if(ucAllowFullPageBitstream)
			{
				JTAG_TAP_DataOut(dat + 18,uiFlashPageSize * 16,JTAG_TAP_ENTER_IDLE);
			}
			else
			{
				for(i = 0;i < (uint16)uiFlashPageSize * 2;i++)
					JTAG_TAP_Data_1Byte(dat[18 + i],8,0);
				JTAG_TAP_Enter_Idle_Mode();
			}

			AVR_JTAG_SendIns(JTAG_INS_PROG_COMMANDS);

			JTAG_PROG_WriteFlashPage();
			while(!JTAG_PROG_WriteFlashPageComplete());

			_RSP_OK();
			break;
		case MEMORY_TYPE_EEPROM_PAGE:
			AVR_JTAG_SendIns(JTAG_INS_PROG_COMMANDS);
			JTAG_PROG_EnterEEPROMWrite();

			JTAG_PROG_LoadAddrHighByte(dat[15]);
			for(i = 0;i < ucEepromPageSize;i++)
			{
				JTAG_PROG_LoadAddrLowByte(dat[14] + i);
				JTAG_PROG_LoadDataByte(dat[18 + i]);
				JTAG_PROG_LatchData();
			}

			JTAG_PROG_WriteEEPROMPage();
			while(!JTAG_PROG_WriteEEPROMPageComplete());

			_RSP_OK();
			break;
		case MEMORY_TYPE_FUSE_BITS:
			lowbyte = dat[10];		// number of bytes
			highbyte = dat[14];		// address

			AVR_JTAG_SendIns(JTAG_INS_PROG_COMMANDS);
			JTAG_PROG_EnterFuseWrite();

			for(tmp8 = 0;tmp8 < lowbyte;tmp8++)
			{
				if((highbyte + tmp8) == 0)
				{
					JTAG_PROG_LoadDataLowByte(dat[18 + tmp8]);
					JTAG_PROG_WriteFuseLowByte();
					//DelayMS(10);
					while(!JTAG_PROG_WriteFuseExtByteComplete());
				}
				else if((highbyte + tmp8) == 1)
				{
					JTAG_PROG_LoadDataLowByte(dat[18 + tmp8]);
					JTAG_PROG_WriteFuseHighByte();
					//DelayMS(10);
					while(!JTAG_PROG_WriteFuseExtByteComplete());
				}
				else
				{
					JTAG_PROG_LoadDataLowByte(dat[18 + tmp8]);
					JTAG_PROG_WriteFuseExtByte();
					//DelayMS(10);
					while(!JTAG_PROG_WriteFuseExtByteComplete());
				}
			}

			_RSP_OK();
			break;
		case MEMORY_TYPE_LOCK_BITS:
			AVR_JTAG_SendIns(JTAG_INS_PROG_COMMANDS);
			JTAG_PROG_EnterLockbitWrite();

			JTAG_PROG_LoadDataByte(dat[18]);
			JTAG_PROG_WriteLockbit();
			while(!JTAG_PROG_WriteLockbitComplete());

			_RSP_OK();
			break;
		default:
			_RSP_ILLEGAL_MEMORY_TYPE();
			break;
		}
		break;
	case JTAGICE_CMND_READ_MEMORY:
#if AVRD_JTAG_SHOULD_ENABLE
		startaddr = dat[14] + ((uint16)dat[15] << 8);
		length = dat[10] + ((uint16)dat[11] << 8);
#endif
		switch(dat[9])
		{
#if AVRD_JTAG_SHOULD_ENABLE
		case MEMORY_TYPE_IO_SHADOW:
			_RSP_ILLEGAL_MEMORY_TYPE();
			break;
		case MEMORY_TYPE_SRAM:
			AVR_JTAGOCD_SaveZR16();
			if(startaddr < 0x20)
				AVR_JTAGOCD_ReadGPR(startaddr,dat + 9,length);				// Read General Purpose Registers
			else if(startaddr < 0x60)
				AVR_JTAGOCD_ReadIO(startaddr - 0x20,dat + 9,length);		// Read IO
			else
				AVR_JTAGOCD_ReadSRAM(startaddr,dat + 9,length);				// Read SRAM
			AVR_JTAGOCD_RestoreZR16();

			_RSP_MEMORY(length);
			break;
		case MEMORY_TYPE_EEPROM:
			_RSP_ILLEGAL_MEMORY_TYPE();
			break;
		case MEMORY_TYPE_EVENT:
			_RSP_ILLEGAL_MEMORY_TYPE();
			break;
		case MEMORY_TYPE_SPM:
			AVR_JTAGOCD_ReadFlash(startaddr,dat + 9,length);

			_RSP_MEMORY(length);
			break;
#endif
		case MEMORY_TYPE_FLASH_PAGE:
			dat[14] >>= 1;
			if(dat[15] & 0x01)
				dat[14] |= 0x80;
			dat[15] >>= 1;
			if(dat[16] & 0x01)
				dat[15] |= 0x80;

			highbyte = dat[15];
			lowbyte = dat[14];

			AVR_JTAG_SendIns(JTAG_INS_PROG_COMMANDS);
			JTAG_PROG_EnterFlashRead();
			if(dat[17])
				JTAG_PROG_LoadAddrExtendedHighByte(1);
			JTAG_PROG_LoadAddrHighByte(highbyte);

			JTAG_PROG_LoadAddrLowByte(lowbyte);
			AVR_JTAG_SendIns(JTAG_INS_PROG_PAGEREAD);

			if(ucAllowFullPageBitstream)
			{
				JTAG_TAP_Data_1Byte(0,8,JTAG_TAP_ENTER_IDLE);

				JTAG_TAP_DataIn(dat + 9,uiFlashPageSize * 16,JTAG_TAP_ENTER_IDLE);
			}
			else
			{
				for(i = 0;i < (uint16)uiFlashPageSize * 2;i++)
					dat[9 + i] = JTAG_TAP_Data_1Byte(0,8,0);
				JTAG_TAP_Enter_Idle_Mode();
			}

			_RSP_MEMORY((uint16)uiFlashPageSize * 2);
			break;
		case MEMORY_TYPE_EEPROM_PAGE:
			AVR_JTAG_SendIns(JTAG_INS_PROG_COMMANDS);
			JTAG_PROG_EnterEEPROMRead();

			highbyte = dat[15];
			lowbyte = dat[14];

			for(i = 0;i < ucEepromPageSize;i++)
			{
				JTAG_PROG_LoadAddrHighByte(highbyte);
				JTAG_PROG_LoadAddrLowByte(lowbyte + i);
				JTAG_PROG_INS(0x3300 | (lowbyte + i));
				JTAG_PROG_INS(0x3200);
				dat[9 + i] = JTAG_PROG_INS(0x3300) & 0xFF;
			}
			_RSP_MEMORY(ucEepromPageSize);
			break;
		case MEMORY_TYPE_FUSE_BITS:
			lowbyte = dat[10];		// number of bytes
			highbyte = dat[14];		// address

			AVR_JTAG_SendIns(JTAG_INS_PROG_COMMANDS);
			JTAG_PROG_EnterFuseLockbitRead();

			fuse_tmp[0] = JTAG_PROG_ReadFuseLowByte();
			fuse_tmp[1] = JTAG_PROG_ReadFuseHighByte();
			fuse_tmp[2] = JTAG_PROG_ReadExtFuseByte();

			for(tmp8 = 0;tmp8 < lowbyte;tmp8++)
				dat[9 + tmp8] = fuse_tmp[tmp8 + highbyte];

			_RSP_MEMORY(lowbyte);
			break;
		case MEMORY_TYPE_LOCK_BITS:
			AVR_JTAG_SendIns(JTAG_INS_PROG_COMMANDS);
			JTAG_PROG_EnterFuseLockbitRead();

			dat[9] = JTAG_PROG_ReadLockbit();

			_RSP_MEMORY(1);
			break;
		case MEMORY_TYPE_SIGN_JTAG:
			lowbyte = dat[10];		// number of bytes
			highbyte = dat[14];		// address

			AVR_JTAG_SendIns(JTAG_INS_PROG_COMMANDS);
			JTAG_PROG_EnterSignByteRead();

			JTAG_PROG_LoadAddrByte(0);
			fuse_tmp[0] = JTAG_PROG_ReadSignByte();
			JTAG_PROG_LoadAddrByte(1);
			fuse_tmp[1] = JTAG_PROG_ReadSignByte();
			JTAG_PROG_LoadAddrByte(2);
			fuse_tmp[2] = JTAG_PROG_ReadSignByte();

			for(tmp8 = 0;tmp8 < lowbyte;tmp8++)
				dat[9 + tmp8] = fuse_tmp[tmp8 + highbyte];

			_RSP_MEMORY(lowbyte);
			break;
		case MEMORY_TYPE_OSCCAL_BYTE:
			AVR_JTAG_SendIns(JTAG_INS_PROG_COMMANDS);
			JTAG_PROG_EnterCaliByteRead();

			JTAG_PROG_LoadAddrByte(dat[14]);
			dat[9] = JTAG_PROG_ReadCaliByte();

			_RSP_MEMORY(1);
			break;
		default:
			_RSP_ILLEGAL_MEMORY_TYPE();
			break;
		}
		break;
#if AVRD_JTAG_SHOULD_ENABLE
	case JTAGICE_CMND_WRITE_PC:
		break;
	case JTAGICE_CMND_READ_PC:
		break;
#endif
	case JTAGICE_CMND_GO:
		_RSP_OK();
		break;
#if AVRD_JTAG_SHOULD_ENABLE
	case JTAGICE_CMND_SINGLE_STEP:
		_RSP_OK();
		break;
	case JTAGICE_CMND_FORCED_STOP:
		AVR_JTAGOCD_ForceStop();
		_RSP_OK();
		break;
#endif
	case JTAGICE_CMND_RESET:
		JTAG_TAP_Instr(JTAG_INS_AVR_RESET);
		JTAG_TAP_Data_1Byte(1,1,JTAG_TAP_ENTER_IDLE);
		DelayMS(1);
		JTAG_TAP_Instr(JTAG_INS_AVR_RESET);
		JTAG_TAP_Data_1Byte(0,1,JTAG_TAP_ENTER_IDLE);

//DelayMS(200);
#if 0
// For Test
AVR_JTAGOCD_CheckPC(tdo);

dat[9] = tdo[0];
dat[10] = tdo[1];
dat[11] = tdo[2];
dat[12] = tdo[3];
dat[13] = tdi[0];
dat[14] = tdi[1];
dat[15] = tdi[2];
dat[16] = tdi[3];
_RSP_MEMORY(8);
break;
#endif
#if AVRD_JTAG_SHOULD_ENABLE
		Target_MCU_State = 1;		// Running
#endif
		_RSP_OK();
		break;
	case JTAGICE_CMND_SET_DEVICE_DESCRIPTOR:
		dat[252] >>= 1;
		if(dat[253])
			dat[252] |= 0x80;
		uiFlashPageSize = dat[252];
		ucEepromPageSize = dat[254];
		ucAllowFullPageBitstream = dat[294];
#if AVRD_JTAG_SHOULD_ENABLE
		ucIDRAddress = dat[249];
		ucSPMCRAddress = dat[250];
		ucRAMPZAddress = dat[251];
		ucSPHaddr = dat[288];
		ucSPLaddr = dat[289];
		ucDWDRAddress = dat[292];
//		ucDWBasePC = dat[293];
		ucPCMaskExtended = dat[302];
		ucPCMaskHigh = dat[303];
		ucEindAddress = dat[304];
//		uiEECRAddress = dat[305];
#endif
		_RSP_OK();
		break;
#if AVRD_JTAG_SHOULD_ENABLE
	case JTAGICE_CMND_ERASEPAGE_SPM:
		break;
#endif
#endif
	case JTAGICE_CMND_GET_SYNC:
		_RSP_OK();
		break;
#if AVRP_JTAG_SHOULD_ENABLE
//	case JTAGICE_CMND_SELFTEST:
//		for(tmp8 = 0;tmp8 < 8;tmp8++)
//			dat[9 + tmp8] = 1;
//		_RSP_SELFTEST();
//		break;
#if AVRD_JTAG_SHOULD_ENABLE
	case JTAGICE_CMND_SET_BREAK:
		break;
	case JTAGICE_CMND_GET_BREAK:
		break;
#endif
	case JTAGICE_CMND_CHIP_ERASE:
		AVR_JTAG_SendIns(JTAG_INS_PROG_COMMANDS);
		JTAG_PROG_ChipErase();
		while(!JTAG_PROG_ChipEraseComplete());

		_RSP_OK();
		break;
	case JTAGICE_CMND_ENTER_PROGMODE:
		if(!AVRP_Programming)
		{
#if ISP_JTAG_AutoPower_En
#if !ISP_JTAG_FourcePower_En
			if(Vtarget < Vtarget_HasPower)
#endif
			{
				ISP_JTAG_PowerOn();
				DelayMS(5);
			}
#endif
			AVRP_Programming = 2;
			JTAG_TAP_Init();
			JTAG_TAP_Reset();
		}

		AVR_JTAG_SendIns(JTAG_INS_AVR_RESET);
		AVR_JTAG_SendDat(1,JTAG_REG_Reset_Len);

		AVR_JTAG_SendIns(JTAG_INS_PROG_ENABLE);
		AVR_JTAG_SendDat(0xA370,JTAG_REG_ProgrammingEnable_Len);

#if AVRD_JTAG_SHOULD_ENABLE || AVRD_DW_SHOULD_ENABLE
		Target_MCU_State = 2;	// Programming
#endif
		_RSP_OK();
		break;
	case JTAGICE_CMND_LEAVE_PROGMODE:
		AVR_JTAG_SendIns(JTAG_INS_PROG_COMMANDS);
		JTAG_PROG_LoadNoOperationCommand();

		AVR_JTAG_SendIns(JTAG_INS_PROG_ENABLE);
		AVR_JTAG_SendDat(0,JTAG_REG_ProgrammingEnable_Len);

		AVR_JTAG_SendIns(JTAG_INS_AVR_RESET);
		AVR_JTAG_SendDat(0,JTAG_REG_Reset_Len);

		JTAG_TAP_Fini();
		AVRP_Programming = 0;	
	
#if ISP_JTAG_AutoPower_En
		ISP_JTAG_PowerOff();
#endif
		_RSP_OK();
		break;
#if AVRD_JTAG_SHOULD_ENABLE
	case JTAGICE_CMND_SET_N_PARAMETERS:
		break;
	case JTAGICE_CMND_CLR_BREAK:
		break;
	case JTAGICE_CMND_RUN_TO_ADDR:
		break;
#endif
//	case JTAGICE_CMND_SPI_CMD:
//		break;
#if AVRD_JTAG_SHOULD_ENABLE
	case JTAGICE_CMND_CLEAR_EVENTS:
		break;
	case JTAGICE_CMND_RESTORE_TARGET:
		JTAG_TAP_Disable();
#if ISP_JTAG_AutoPower_En
		ISP_JTAG_PowerOff();
#endif
		AVRP_Programming = 0;	

		_RSP_OK();
		break;
#endif
#endif
	default:
		_RSP_FAILED();
		break;
	}

	return 0;
}
#endif		// #if AVRP_JTAG_SHOULD_ENABLE
