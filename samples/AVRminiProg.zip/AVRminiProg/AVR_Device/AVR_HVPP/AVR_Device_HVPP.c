/* Name: AVR_Device_HVPP.c
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2007-11-7 0:40:52
 */
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <string.h>

#include "../../type.h"
#include "../../app_cfg.h"

#include "../../MCU/gpio.h"

#include "../../Delay/delay.h"

#include "../AVR_Device_Common.h"

#include "AVR_Device_HVPP.h"

#include "../../AVR_Programming/HV/HV.h"
#include "../../AVR_Programming/HV/HVPP/HVPP.h"

#if AVRP_HVPP_SHOULD_ENABLE
uint8 AVRP_HVPP_ProcessProgCmd(uint8* dat,uint16 len)
{
	uint8 length8,mode,pagesize,j;
	uint16 length16,i;

	switch(dat[0] & AVRP_CMD_MSK)
	{
	case AVRP_CMD_ENTER_PROGMODE:
//dat[idx]	para(value)				Description
//dat[1]	stabDelay(100)			Delay(in ms) used for pin stabilization
//dat[2]	progModeDelay(0)		Delay(in ms) in connection with the EnterProgMode command execution
//dat[3]	latchCycles()			Number of xtal cycles used to latch OSCCAL
//dat[4]	toggleVtg(1)			Toggle Vtg when entering prog mode(0=no,1=yes).For parts with RSTDSBL functionality
//dat[5]	powerOffDelay()			Power-off delay.Additional delay(in ms) after Vtg is turned off in order to make sure the Vtg is low enough
//dat[6]	resetDelayMs()			RSTDELAY#1(in ms).Additional delay between Vtg is turned on and reset goes high
//dat[7]	resetDelayUs()			RSTDELAY#2(in us*10).Additional delay between Vtg is turned on and reset goes high.Total delay is RSTDELAY#1(ms) + RSTDELAY#2(us*10)
		AVRP_Programming = 3;

		HVPP_Init();

		// Power and Reset to '0'
		HV_TargetReset_0V();
		DelayMS(5);
		//DelayMS(dat[5]);	// powerOffDelay

		// TVCC on
		HV_TargetVCC_On();

		// resetDelay
		DelayMS(dat[6]);
		DelayUS(dat[7] * 10);

		// Toggle XTAL1 to latch OSCCAL, U can toggle a pin by set corresponding bit in PINX, but NOT all AVRs support that
		for(j = 0;j < dat[3];j++)
		{
			HVPP_XTAL1_Set();
			DelayUS(0);
			HVPP_XTAL1_Clr();
		}

		// Set Prog_enable PINs to '0', has been set to '0' in HVPP_Init()
		// PAGEL,XA0,XA1,BS1 in PP Mode

		// apply 12V to nRST
		HV_TargetReset_12V();

		DelayMS(dat[2]);

		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_EXIT_PROGMODE:
//dat[idx]	para(value)				Description
//dat[1]	stabDelay				Delay(in ms) used for pin stabilization
//dat[2]	resetDelay				Delay(in ms) for holding RESET low
		DelayMS(dat[2]);
//		HVPP_RDY_Wait();

		HVPP_Fini();

		DelayMS(dat[1]);

		AVRP_Programming = 0;
		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_CHIP_ERASE:
//dat[idx]	para(value)				Description
//dat[1]	pulseWidth				Width(in ms) of the nWR pulse. 0 => 1 cycle
//dat[2]	pollTimeout				Timeout period(in ms) to wait for RDY/BSY flag to rise.If 0,RDY/BSY flag is NOT used
		if(HVPP_RDY_Wait())
		{
			AVRP_TxLen = 2;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}

		HVPP_LoadCommand(HVCMD_CHIP_ERASE);
		HVPP_WriteDataLowByte();
//		HVPP_nWR_NPulse(HVPP_BS_LowByte,dat[1]);

		if(dat[2] && HVPP_RDY_Wait())
		{
			AVRP_TxLen = 2;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}

		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_PROGRAM_FLASH:
//dat[idx]	para(value)				Description
//dat[1]	Nmb bytes(MSB)			Total number of bytes to program(MSB)
//dat[2]	Nmb bytes(LSB)			Total number of bytes to program(LSB)
//dat[3]	mode					Mode byte
//dat[4]	pollTimeout				Poll timeout(in ms)
//dat[5]..	data..					Data to program
		length8 = dat[2] >> 1;
		if(dat[1] & 0x01)
			length8 |= 0x80;

		mode = dat[3];
		pagesize = pgm_read_word(HV_PageSize + ((mode & 0x0E) >> 1));

		if(HVPP_RDY_Wait())
		{
			AVRP_TxLen = 2;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}

		HVPP_LoadCommand(HVCMD_WRITE_FLASH);

		if(mode & 1)
		{
			// Page Mode
			length8 /= pagesize;
			for(i = 0;i < length8;i++)
			{
				length16 = __prog_addr;
				for(j = 0;j < pagesize;j++)
				{
					HVPP_LoadAddressLowByte(__prog_addr);
					HVPP_LoadDataLowByte(dat[5 + i * pagesize * 2 + j * 2]);
					HVPP_LoadDataHighByte(dat[6 + i * pagesize * 2 + j * 2]);

					HVPP_LatchFlashData();

					__prog_addr++;
				}
				if(mode & 0x80)
				{
					HVPP_LoadAddressHighByte(length16 >> 8);
					if(__prog_addr_over_64k)
						HVPP_LoadAddressExtendedHighByte(1);

					HVPP_WriteDataLowByte();

					if(HVPP_RDY_Wait())
					{
						AVRP_TxLen = 2;
						return AVRP_STATUS_RDY_BSY_TOUT;
					}
				}
			}
		}
		else
		{
			// Non Page Mode
			// All this for ATtiny28
			HVPP_LoadAddressHighByte(__prog_addr >> 8);
			for(i = 0;i < length8;i++)
			{
				HVPP_LoadAddressLowByte(__prog_addr);
				HVPP_LoadDataLowByte(dat[5 + i * 2]);
				HVPP_WriteDataLowByte();
				if(HVPP_RDY_Wait())
				{
					AVRP_TxLen = 2;
					return AVRP_STATUS_RDY_BSY_TOUT;
				}

				HVPP_LoadDataHighByte(dat[6 + i * 2]);
				HVPP_WriteDataHighByte();
				if(HVPP_RDY_Wait())
				{
					AVRP_TxLen = 2;
					return AVRP_STATUS_RDY_BSY_TOUT;
				}
				__prog_addr++;
			}
		}

		HVPP_LoadCommand(HVCMD_NOP);

		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_READ_FLASH:
//dat[idx]	para(value)				Description
//dat[1]	Nmb bytes(MSB)			Total number of bytes to read(MSB)
//dat[2]	Nmb bytes(LSB)			Total number of bytes to read(LSB)
		length8 = dat[2] >> 1;
		if(dat[1] & 0x01)
			length8 |= 0x80;

		HVPP_RDY_Wait();
		HVPP_LoadCommand(HVCMD_READ_FLASH);

		if(__prog_addr_over_64k)
			HVPP_LoadAddressExtendedHighByte(1);
		HVPP_LoadAddressHighByte(__prog_addr >> 8);
		for(i = 0;i < length8;i++)
		{
			HVPP_LoadAddressLowByte(__prog_addr);

			HVPP_EnableReadData(HVPP_BS_LowByte);
			dat[2 + 2 * i] = HVPP_ReadData();
			HVPP_ReadDataChangeByte(HVPP_BS_HighByte);
			dat[3 + 2 * i] = HVPP_ReadData();
			HVPP_DisableReadData(HVPP_BS_HighByte);

			__prog_addr++;
		}

		dat[2 + length8 * 2] = AVRP_STATUS_CMD_OK;
		AVRP_TxLen = 3 + length8 * 2;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_PROGRAM_EEPROM:
//dat[idx]	para(value)				Description
//same as AVRP_CMD_PROGRAM_FLASH
		length16 = dat[2] | (dat[1] << 8);

		mode = dat[3];
		pagesize = pgm_read_word(HV_PageSize + ((mode & 0x0E) >> 1)) * 2;

		if(HVPP_RDY_Wait())
		{
			AVRP_TxLen = 2;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}
		HVPP_LoadCommand(HVCMD_WRITE_EEPROM);

		if(mode & 1)
		{
			// Page Mode
			length8 = length16 / pagesize;
			for(i = 0;i < length8;i++)
			{
				HVPP_LoadAddressHighByte(__prog_addr >> 8);
				for(j = 0;j < pagesize;j++)
				{
					HVPP_LoadAddressLowByte(__prog_addr);
					HVPP_LoadDataLowByte(dat[5 + i * pagesize + j]);

					HVPP_LatchEEPROMData();

					__prog_addr++;
				}
				if(mode & 0x80)
				{
					HVPP_WriteDataLowByte();

					if(HVPP_RDY_Wait())
					{
						AVRP_TxLen = 2;
						return AVRP_STATUS_RDY_BSY_TOUT;
					}
				}
			}
		}
		else
		{
			// Non Page Mode
			// Is there any chip using HVPP and has Non-page-mode EEPROM?
		}

		HVPP_LoadCommand(HVCMD_NOP);

		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_READ_EEPROM:
//dat[idx]	para(value)				Description
//same as AVRP_CMD_READ_FLASH
		length16 = dat[2] | (dat[1] << 8);

		HVPP_RDY_Wait();
		HVPP_LoadCommand(HVCMD_READ_EEPROM);

		HVPP_LoadAddressHighByte(__prog_addr >> 8);
		for(i = 0;i < length16;i++)
		{
			HVPP_LoadAddressLowByte(__prog_addr);
			HVPP_EnableReadData(HVPP_BS_LowByte);
			dat[2 + i] = HVPP_ReadData();
			HVPP_DisableReadData(HVPP_BS_LowByte);

			__prog_addr++;
		}

		dat[2 + length16] = AVRP_STATUS_CMD_OK;
		AVRP_TxLen = 3 + length16;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_PROGRAM_FUSE:
//dat[idx]	para(value)				Description
//dat[1]	address					Address of data to program
//dat[2]	data					data to program
//dat[3]	pulseWidth				Width(ms) of nWR pulse(0 => 1 cycle)
//dat[4]	pollTimeout				Timeout(ms) for polling RDY/BSY(0 = don't poll)
		if(HVPP_RDY_Wait())
		{
			AVRP_TxLen = 2;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}

		mode = dat[1];
		if(mode == 0)
			mode = HVPP_BS_LowByte;
		else if(mode == 1)
			mode = HVPP_BS_HighByte;
		else if(mode == 2)
			mode = HVPP_BS_ExtLowByte;

		HVPP_LoadCommand(HVCMD_WRITE_FUSE);
		HVPP_LoadDataLowByte(dat[2]);
		HVPP_nWR_NPulse(mode,dat[3]);

		if(dat[4] && HVPP_RDY_Wait())
		{
			AVRP_TxLen = 2;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}

		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_READ_FUSE:
//dat[idx]	para(value)				Description
//dat[1]	address					Address of data to read
		HVPP_RDY_Wait();

		mode = dat[1];
		if(mode == 0)
			mode = HVPP_BS_LowByte;
		else if(mode == 1)
			mode = HVPP_BS_ExtHighByte;
		else if(mode == 2)
			mode = HVPP_BS_ExtLowByte;

		HVPP_LoadCommand(HVCMD_READ_FUSELCK);
		HVPP_EnableReadData(mode);
		dat[2] = HVPP_ReadData();
		HVPP_DisableReadData(mode);

		AVRP_TxLen = 3;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_PROGRAM_LOCKBIT:
//dat[idx]	para(value)				Description
//same as AVRP_CMD_PROGRAM_FUSE
		if(HVPP_RDY_Wait())
		{
			AVRP_TxLen = 2;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}

		HVPP_LoadCommand(HVCMD_WRITE_LOCK);
		HVPP_LoadDataLowByte(dat[2]);
		HVPP_WriteDataLowByte();
//		HVPP_nWR_NPulse(HVPP_BS_LowByte,dat[3]);

		if(dat[4] && HVPP_RDY_Wait())
		{
			AVRP_TxLen = 2;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}

		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_READ_LOCKBIT:
//dat[idx]	para(value)				Description
//same as AVRP_CMD_READ_FUSE
		HVPP_RDY_Wait();

		HVPP_LoadCommand(HVCMD_READ_FUSELCK);
		HVPP_EnableReadData(HVPP_BS_HighByte);
		dat[2] = HVPP_ReadData();
		HVPP_DisableReadData(HVPP_BS_HighByte);

		AVRP_TxLen = 3;
		return AVRP_STATUS_CMD_OK;
	case AVRP_CMD_READ_SIGNATURE:
//dat[idx]	para(value)				Description
//same as AVRP_CMD_READ_FUSE
		HVPP_RDY_Wait();

		HVPP_LoadCommand(HVCMD_READ_SIGCAL);

		HVPP_LoadAddressLowByte(dat[1]);
		HVPP_EnableReadData(HVPP_BS_LowByte);
		dat[2] = HVPP_ReadData();
		HVPP_DisableReadData(HVPP_BS_LowByte);

		AVRP_TxLen = 3;
		return AVRP_STATUS_CMD_OK;
	case AVRP_CMD_READ_OSCCAL:
//dat[idx]	para(value)				Description
//same as AVRP_CMD_READ_FUSE
		HVPP_RDY_Wait();

		HVPP_LoadCommand(HVCMD_READ_SIGCAL);

		HVPP_LoadAddressLowByte(dat[1]);
		HVPP_EnableReadData(HVPP_BS_HighByte);
		dat[2] = HVPP_ReadData();
		HVPP_DisableReadData(HVPP_BS_HighByte);

		AVRP_TxLen = 3;
		return AVRP_STATUS_CMD_OK;
		break;
	default:
		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_UNKNOWN;
		break;
	}
}
#endif		// #if AVRP_HVPP_SHOULD_ENABLE
