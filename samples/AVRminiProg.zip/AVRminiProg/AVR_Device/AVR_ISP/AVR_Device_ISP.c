/* Name: AVR_Device_ISP_SpeedUp.c
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2007-02-10
 */
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <string.h>

#include "../../type.h"
#include "../../app_cfg.h"

#include "../../MCU/gpio.h"
#include "../../MCU/eeprom.h"

#include "../../Delay/delay.h"

#include "../AVR_Device_Common.h"

#include "../../AVR_Programming/ISP/SPI/spi.h"
#include "AVR_Device_ISP.h"

#include "../../AVR_Programming/ISP/ISP.h"

#if AVRP_ISP_SHOULD_ENABLE
uint8 AVRISP_SPI_cmd[4];
uint8 AVRISP_SPI_ret[4];
uint8 AVRP_ISP_ProcessProgCmd(uint8* dat,uint16 len)
{
	uint16 i;
	uint16 tmp16,length16;
	uint8 operation = 0,command,command_tmp,tmp8,delay,length8;

	switch(dat[0] & AVRP_CMD_MSK)
	{
	case AVRP_CMD_ENTER_PROGMODE:
//dat[idx]	para(value)				Description
//dat[1]	timeout					Command timeout(in ms)
//dat[2]	stabDelay				Delay(in ms) used for pin stabilization
//dat[3]	cmdexeDelay				Delay(in ms) in connection with the EnterProgMode command execution
//dat[4]	synchLoops				Number of synchronization loops
//dat[5]	byteDelay				Delay(in ms) between each byte in the EnterProgMode command
//dat[6]	pollValue				Poll value:0x53 for AVR,0x69 for AT89xx
//dat[7]	pollIndex				Start address of received byte:0 = no polling,3 = AVR,4 = AT89xx
//dat[8]	cmd1
//dat[9]	cmd2
//dat[10]	cmd3
//dat[11]	cmd4
#if ISP_JTAG_AutoPower_En
#if !ISP_JTAG_FourcePower_En
		if(Vtarget < Vtarget_HasPower)
#endif
		{
			ISP_JTAG_PowerOn();
			DelayMS(5);
		}
#endif

#if ISP_AutoSpeed_En
Test_Speed:
		if(Reset_Polarity)
		{
			if(ISP_AutoSpeed)
				Program_Speed = ISP_Speed[operation];
		}
		else
		{
			Program_Speed = EEPROM_Read(0);
			ISP_AutoSpeed = 0;
		}
#endif
//		delay = dat[2];
		if(Reset_Polarity)
		{
			// AVR
			ISP_ClrRST();
			ISP_Init();
			SPI_SetClk(Program_Speed);
			// Atmel give a long delay,could be shorter
//			DelayMS(delay);
			DelayMS(1);
			ISP_SetRST();
//			DelayMS(delay);
			DelayMS(1);
			ISP_ClrRST();
		}
		else
		{
			// S51
			ISP_SetRST();
			ISP_Init();
			SPI_SetClk(Program_Speed);
//			DelayMS(delay);
			DelayMS(100);
			ISP_ClrRST();
//			DelayMS(delay);
			DelayMS(30);
			ISP_SetRST();
		}
		DelayMS(dat[3]);

		for(tmp8 = 0;tmp8 < 4;tmp8++)
		{
			AVRISP_SPI_ret[tmp8] = SPI_RW(dat[8 + tmp8]);
// NOT necessary to delay this delay
//			DelayMS(dat[5]);
		}
//		DelayMS(dat[3]);
		if((dat[7] > 0) && (AVRISP_SPI_ret[dat[7] - 1] != dat[6]))
		{
			// poll fails
#if ISP_AutoSpeed_En
			if(ISP_AutoSpeed && (operation < ISP_AutoSpeed_Max))
			{
				operation++;
				ISP_Fini();
				DelayMS(1);
				goto Test_Speed;
			}
			else
#endif
			{
#if ISP_JTAG_AutoPower_En
				ISP_JTAG_PowerOff();
#endif
				AVRP_TxLen = AVRISP_CMD_ENTER_PROGMODE_ISP_RLEN_F;
				return AVRP_STATUS_CMD_FAILED;
			}
		}

#if ISP_AutoSpeed_En
		if(operation < 7)
			tmp16 = ISP_AutoSpeed_CheckTimes_H;
		else
			tmp16 = ISP_AutoSpeed_CheckTimes_L;
		for(i = 0;(i < tmp16) && ISP_AutoSpeed;i++)
		{
			AVRISP_SPI_cmd[0] = 0x30;
			AVRISP_SPI_cmd[1] = 0x00;
			AVRISP_SPI_cmd[2] = 0x00;
			AVRISP_SPI_cmd[3] = 0x00;
			ISP_Comm(AVRISP_SPI_cmd,AVRISP_SPI_ret);
			if(AVRISP_SPI_ret[3] != 0x1E)
			{
				if(operation < ISP_AutoSpeed_Max)
				{
					operation++;
					ISP_Fini();
					DelayMS(1);
					goto Test_Speed;
				}
				else
				{
#if ISP_JTAG_AutoPower_En
					ISP_JTAG_PowerOff();
#endif
					AVRP_TxLen = AVRISP_CMD_ENTER_PROGMODE_ISP_RLEN_F;
					return AVRP_STATUS_CMD_FAILED;
				}
			}

			AVRISP_SPI_cmd[2] = 0x01;
			ISP_Comm(AVRISP_SPI_cmd,AVRISP_SPI_ret);
			if((AVRISP_SPI_ret[3] & 0xF0) != 0x90)
			{
				if(operation < ISP_AutoSpeed_Max)
				{
					operation++;
					ISP_Fini();
					DelayMS(1);
					goto Test_Speed;
				}
				else
				{
#if ISP_JTAG_AutoPower_En
					ISP_JTAG_PowerOff();
#endif
					AVRP_TxLen = AVRISP_CMD_ENTER_PROGMODE_ISP_RLEN_F;
					return AVRP_STATUS_CMD_FAILED;
				}
			}
		}
#endif

		AVRP_Programming = 1;
		AVRP_TxLen = AVRISP_CMD_ENTER_PROGMODE_ISP_RLEN_S;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_EXIT_PROGMODE:
//dat[idx]	para(value)				Description
//dat[1]	preDelay				Pre-delay(in ms)
//dat[2]	postDelay				Post-delay(in ms)
		DelayMS(20);		// Wait last operation ready
//		ISP_RDY_Wait();

		DelayMS(dat[1]);
		ISP_Fini();
		DelayMS(dat[2]);

		AVRP_Programming = 0;

#if ISP_JTAG_AutoPower_En
		ISP_JTAG_PowerOff();
#endif

		AVRP_TxLen = AVRISP_CMD_LEAVE_PROGMODE_ISP_RLEN_S;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_CHIP_ERASE:
//dat[idx]	para(value)				Description
//dat[1]	eraseDelay				Delay(in ms) to ensure that the erase of the device is finished
//dat[2]	pollMethod				Poll method,0 = use delay,1 = use RDY/BSY command
//dat[3]	cmd1
//dat[4]	cmd2
//dat[5]	cmd3
//dat[6]	cmd4
		if(ISP_RDY_Wait())
		{
			AVRP_TxLen = AVRISP_CMD_CHIP_ERASE_ISP_RLEN_F;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}

		ISP_Comm(&dat[3],(uint8*)AVRISP_SPI_ret);

		DelayMS(dat[1]);
		if(dat[2])
		{
			if(ISP_RDY_Wait())
			{
				AVRP_TxLen = AVRISP_CMD_CHIP_ERASE_ISP_RLEN_F;
				return AVRP_STATUS_RDY_BSY_TOUT;
			}
		}
//		else
//			DelayMS(dat[1]);

		AVRP_TxLen = AVRISP_CMD_CHIP_ERASE_ISP_RLEN_S;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_PROGRAM_FLASH:
//dat[idx]	para(value)				Description
//dat[1]	NumBytes(MSB)			Total number of bytes to program(MSB)
//dat[2]	NumBytes(LSB)			Total number of bytes to program(LSB)
//dat[3]	mode					Mode byte
//dat[4]	delay					Delay used for different types of programming termination,according to mode byte
//dat[5]	cmd1					Comamnd byte for Load Page
//dat[6]	cmd2					Command byte for Write Memory
//dat[7]	cmd3					Command byte for Read Memory
//dat[8]	poll1					
//dat[9]	poll2					
//data[10].	Data					Data to program
		operation = dat[3];
		command = dat[5];
		command_tmp = dat[7];

		if(ISP_RDY_Wait())
		{
			AVRP_TxLen = AVRISP_CMD_PROGRAM_FLASH_ISP_RLEN_F;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}

		if(operation & 0x01)
		{
			// Page Mode
			length8 = dat[2] >> 1;
			if(dat[1] & 1)
				length8 |= 0x80;

			tmp16 = __prog_addr;

			for(i = 0;i < length8;i++)
			{
				AVRISP_SPI_cmd[0] = command;
				AVRISP_SPI_cmd[1] = __prog_addr >> 8;
				AVRISP_SPI_cmd[2] = __prog_addr;
				AVRISP_SPI_cmd[3] = dat[10 + i * 2];
				ISP_Comm((uint8*)AVRISP_SPI_cmd,(uint8*)AVRISP_SPI_ret);

				AVRISP_SPI_cmd[0] = command | 0x08;
				AVRISP_SPI_cmd[3] = dat[11 + i * 2];
				ISP_Comm((uint8*)AVRISP_SPI_cmd,(uint8*)AVRISP_SPI_ret);

				__prog_addr++;
			}
			if(operation & 0x80)
			{
				// Write Flash Page
				AVRISP_SPI_cmd[0] = dat[6];
				AVRISP_SPI_cmd[1] = tmp16 >> 8;
				AVRISP_SPI_cmd[2] = tmp16;
				AVRISP_SPI_cmd[3] = 0;
				ISP_Comm((uint8*)AVRISP_SPI_cmd,(uint8*)AVRISP_SPI_ret);

				// Polling,AVRUSB makes a good delay
				// some chips like Mega8 may need more delay,most morden chips needn't
				if(!(operation & 0x08))
					DelayMS(2);
/*
				if(operation & 0x04)
				{
					// Value Polling
					tmp8 = dat[8];		// Flash use dat[8]
					if(dat[10] != tmp8)
					{
						delay = 250;
						do
						{
							AVRISP_SPI_cmd[0] = command_tmp;
							AVRISP_SPI_cmd[1] = tmp16 >> 8;
							AVRISP_SPI_cmd[2] = tmp16;
							AVRISP_SPI_cmd[3] = 0;
							ISP_Comm((uint8*)AVRISP_SPI_cmd,(uint8*)AVRISP_SPI_ret);
						}while((AVRISP_SPI_ret[3] == tmp8) && --delay);
						if(!delay | (AVRISP_SPI_ret[3] != dat[10]))
						{
							AVRP_TxLen = AVRISP_CMD_PROGRAM_FLASH_ISP_RLEN_F;
							return AVRP_STATUS_RDY_BSY_TOUT;
						}
					}
					else
						DelayMS(dat[4]);
				}
				else if(operation & 0x08)
				{
					// RDY/BSY Polling
//					if(ISP_RDY_Wait())
//					{
//						AVRP_TxLen = AVRISP_CMD_PROGRAM_FLASH_ISP_RLEN_F;
//						return AVRP_STATUS_RDY_BSY_TOUT;
//					}
				}
				else
				{
					// Delay
					DelayMS(dat[4]);
				}
*/
			}
		}
		else
		{
			// Non Page Mode
			length16 = ((uint16)(dat[1] & 1) << 8) | dat[2];

			for(i = 0;i < length16;i++)
			{
				if(i & 1)
					AVRISP_SPI_cmd[0] = command | 0x08;
				else
					AVRISP_SPI_cmd[0] = command;
				AVRISP_SPI_cmd[1] = __prog_addr >> 8;
				AVRISP_SPI_cmd[2] = __prog_addr;
				AVRISP_SPI_cmd[3] = dat[10 + i];
				ISP_Comm((uint8*)AVRISP_SPI_cmd,(uint8*)AVRISP_SPI_ret);

				// MUST Full Polling
				if(operation & 0x04)
				{
					// Value Polling
					tmp8 = dat[8];		// Flash use dat[8]
					if(dat[10 + i] != tmp8)
					{
						delay = 250;
						do
						{
							if(i & 1)
								AVRISP_SPI_cmd[0] = command_tmp | 0x08;
							else
								AVRISP_SPI_cmd[0] = command_tmp;
							AVRISP_SPI_cmd[3] = 0;
							ISP_Comm((uint8*)AVRISP_SPI_cmd,(uint8*)AVRISP_SPI_ret);
						}while((AVRISP_SPI_ret[3] == tmp8) && --delay);
						if(!delay | (AVRISP_SPI_ret[3] != dat[10 + i]))
						{
							AVRP_TxLen = AVRISP_CMD_PROGRAM_FLASH_ISP_RLEN_F;
							return AVRP_STATUS_RDY_BSY_TOUT;
						}
					}
					else
						DelayMS(dat[4]);
				}
				else if(operation & 0x08)
				{
					// RDY/BSY Polling
					if(ISP_RDY_Wait())
					{
						AVRP_TxLen = AVRISP_CMD_PROGRAM_FLASH_ISP_RLEN_F;
						return AVRP_STATUS_RDY_BSY_TOUT;
					}
				}
				else
				{
					// Delay
					DelayMS(dat[4]);
				}

				if(i & 1)
					__prog_addr++;
			}
		}

		AVRP_TxLen = AVRISP_CMD_PROGRAM_FLASH_ISP_RLEN_S;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_READ_FLASH:
//dat[idx]	para(value)				Description
//dat[1]	NumBytes(MSB)			Total number of bytes to read(MSB)
//dat[2]	NumBytes(LSB)			Total number of bytes to read(LSB)
//dat[3]	cmd1					Command for Read Memory
		ISP_RDY_Wait();

		length8 = dat[2] >> 1;
		if(dat[1] & 1)
			length8 |= 0x80;
		command = dat[3];

		for(i = 0;i < length8;i++)
		{
			AVRISP_SPI_cmd[0] = command;
			AVRISP_SPI_cmd[1] = __prog_addr >> 8;
			AVRISP_SPI_cmd[2] = __prog_addr;
			ISP_Comm((uint8*)AVRISP_SPI_cmd,(uint8*)AVRISP_SPI_ret);
			dat[2 + i * 2] = AVRISP_SPI_ret[3];

			AVRISP_SPI_cmd[0] = command | 0x08;
			ISP_Comm((uint8*)AVRISP_SPI_cmd,(uint8*)AVRISP_SPI_ret);
			dat[3 + i * 2] = AVRISP_SPI_ret[3];

			__prog_addr++;
		}
		dat[2 + length8 * 2] = AVRP_STATUS_CMD_OK;
		AVRP_TxLen = 3 + length8 * 2;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_PROGRAM_EEPROM:
//dat[idx]	para(value)				Description
//same as AVRP_CMD_PROGRAM_FLASH
		length16 = ((uint16)(dat[1] & 1) << 8) | dat[2];
//		if(length > 280)
//		{
//			AVRP_TxLen = 2;
//			return AVRP_STATUS_CMD_FAILED;
//		}

		operation = dat[3];
		command = dat[5];
		command_tmp = dat[7];

		if(ISP_RDY_Wait())
		{
			AVRP_TxLen = AVRISP_CMD_PROGRAM_FLASH_ISP_RLEN_F;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}

		if(operation & 0x01)
		{
			// Page Mode
			tmp16 = __prog_addr;

			for(i = 0;i < length16;i++)
			{
				AVRISP_SPI_cmd[0] = command;
				AVRISP_SPI_cmd[1] = __prog_addr >> 8;
				AVRISP_SPI_cmd[2] = __prog_addr;
				AVRISP_SPI_cmd[3] = dat[10 + i];
				ISP_Comm((uint8*)AVRISP_SPI_cmd,(uint8*)AVRISP_SPI_ret);

				__prog_addr++;
			}
			if(operation & 0x80)
			{
				// Write Flash Page
				AVRISP_SPI_cmd[0] = dat[6];
				AVRISP_SPI_cmd[1] = tmp16 >> 8;
				AVRISP_SPI_cmd[2] = tmp16;
				AVRISP_SPI_cmd[3] = 0;
				ISP_Comm((uint8*)AVRISP_SPI_cmd,(uint8*)AVRISP_SPI_ret);

				// Polling
				if(operation & 0x04)
				{
					// Value Polling
					tmp8 = dat[9];		// EEPROM use dat[9]
					if(dat[10] != tmp8)
					{
						delay = 250;
						do
						{
							AVRISP_SPI_cmd[0] = command_tmp;
							AVRISP_SPI_cmd[1] = tmp16 >> 8;
							AVRISP_SPI_cmd[2] = tmp16;
							AVRISP_SPI_cmd[3] = 0;
							ISP_Comm((uint8*)AVRISP_SPI_cmd,(uint8*)AVRISP_SPI_ret);
						}while((AVRISP_SPI_ret[3] == tmp8) && --delay);
						if(!delay | (AVRISP_SPI_ret[3] != dat[10]))
						{
							AVRP_TxLen = AVRISP_CMD_PROGRAM_FLASH_ISP_RLEN_F;
							return AVRP_STATUS_RDY_BSY_TOUT;
						}
					}
					else
						DelayMS(dat[4]);
				}
				else if(operation & 0x08)
				{
					// RDY/BSY Polling
//					if(ISP_RDY_Wait())
//					{
//						AVRP_TxLen = AVRISP_CMD_PROGRAM_FLASH_ISP_RLEN_F;
//						return AVRP_STATUS_RDY_BSY_TOUT;
//					}
				}
				else
				{
					// Delay
					DelayMS(dat[4]);
				}

			}
		}
		else
		{
			// Non Page Mode
			for(i = 0;i < length16;i++)
			{
				AVRISP_SPI_cmd[0] = command;
				AVRISP_SPI_cmd[1] = __prog_addr >> 8;
				AVRISP_SPI_cmd[2] = __prog_addr;
				AVRISP_SPI_cmd[3] = dat[10 + i];
				ISP_Comm((uint8*)AVRISP_SPI_cmd,(uint8*)AVRISP_SPI_ret);

				// MUST Full Polling
				if(operation & 0x04)
				{
					// Value Polling
					tmp8 = dat[9];		// EEPROM use dat[9]
					if(dat[10 + i] != tmp8)
					{
						tmp16 = 400;
						do
						{
							AVRISP_SPI_cmd[0] = command_tmp;
							AVRISP_SPI_cmd[3] = 0;
							ISP_Comm((uint8*)AVRISP_SPI_cmd,(uint8*)AVRISP_SPI_ret);
						}while((AVRISP_SPI_ret[3] == tmp8) && --tmp16);
						if(!tmp16 | (AVRISP_SPI_ret[3] != dat[10 + i]))
						{
							AVRP_TxLen = AVRISP_CMD_PROGRAM_FLASH_ISP_RLEN_F;
							return AVRP_STATUS_RDY_BSY_TOUT;
						}
					}
					else
						DelayMS(dat[4]);
				}
				else if(operation & 0x08)
				{
					// RDY/BSY Polling
					if(ISP_RDY_Wait())
					{
						AVRP_TxLen = AVRISP_CMD_PROGRAM_FLASH_ISP_RLEN_F;
						return AVRP_STATUS_RDY_BSY_TOUT;
					}
				}
				else
				{
					// Delay
					DelayMS(dat[4]);
				}

				__prog_addr++;
			}
		}

		AVRP_TxLen = AVRISP_CMD_PROGRAM_EEPROM_ISP_RLEN_S;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_READ_EEPROM:
//dat[idx]	para(value)				Description
//same as AVRP_CMD_READ_FLASH
		ISP_RDY_Wait();

		length16 = ((uint16)(dat[1] & 1) << 8) | dat[2];
//		if(length > 280)
//			length = 280;

		command = dat[3];

		for(i = 0;i < length16;i++)
		{
			AVRISP_SPI_cmd[0] = command;
			AVRISP_SPI_cmd[1] = __prog_addr >> 8;
			AVRISP_SPI_cmd[2] = __prog_addr;
			ISP_Comm((uint8*)AVRISP_SPI_cmd,(uint8*)AVRISP_SPI_ret);
			dat[2 + i] = AVRISP_SPI_ret[3];

			__prog_addr++;
		}
		dat[2 + length16] = AVRP_STATUS_CMD_OK;
		AVRP_TxLen = 3 + length16;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_PROGRAM_FUSE:
	case AVRP_CMD_PROGRAM_LOCKBIT:
//dat[idx]	para(value)				Description
//dat[1]	cmd1
//dat[2]	cmd2
//dat[3]	cmd3
//dat[4]	cmd4
		ISP_RDY_Wait();

		ISP_Comm(&dat[1],(uint8*)AVRISP_SPI_ret);

		dat[2] = AVRP_STATUS_CMD_OK;
		AVRP_TxLen = 3;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_READ_FUSE:
	case AVRP_CMD_READ_LOCKBIT:
	case AVRP_CMD_READ_SIGNATURE:
	case AVRP_CMD_READ_OSCCAL:
//dat[idx]	para(value)				Description
//dat[1]	RetAddr					Return address
//dat[2]	cmd1
//dat[3]	cmd2
//dat[4]	cmd3
//dat[5]	cmd4
		ISP_RDY_Wait();

		ISP_Comm(&dat[2],(uint8*)AVRISP_SPI_ret);
		dat[2] = AVRISP_SPI_ret[dat[1] - 1];

		dat[3] = AVRP_STATUS_CMD_OK;
		AVRP_TxLen = 4;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_SPECIAL_OPERATION:		// AVRISP_CMD_SPI_MULTI
//dat[idx]	para(value)				Description
//dat[1]	NumTx					Number of bytes to transmit
//dat[2]	NumRx					Number of bytes to receive
//dat[3]	RxStartAddr				Start address of returned data.Specifies on what transmitted byte the response is to be stored and returned
//dat[4]..	TxData					The data to be transmitted.The size is specified by NumTx
		operation = dat[1];	// Tx Len
		delay = dat[2];		// Rx Len
		command = dat[3];	// StartAddr

		length8 = (delay + command) > operation ? delay + command : operation;
		tmp8 = 0;

		for(i = 0;i < length8;i++)
		{
			if(i < operation)
				command_tmp = SPI_RW(dat[4 + i]);
			else
				command_tmp = SPI_RW(0);

			if((i >= command) && (tmp8 < delay))
				dat[tmp8++ + 2] = command_tmp;
		}

		dat[2 + delay] = AVRP_STATUS_CMD_OK;
		AVRP_TxLen = delay + 3;
		return AVRP_STATUS_CMD_OK;
		break;
	default:
		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_UNKNOWN;
		break;
	}
}
#endif		// #if AVRP_ISP_SHOULD_ENABLE
