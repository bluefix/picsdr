/* Name: AVR_Device_Common.c
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2008-03-10
 */
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <avr/wdt.h>
#include <string.h>

#include "../type.h"
#include "../app_cfg.h"

#include "../MCU/gpio.h"
#include "../MCU/watchdog.h"
#include "../MCU/eeprom.h"

#include "AVR_Device_Common.h"

#include "AVR_ISP/AVR_Device_ISP.h"
#include "AVR_HVPP/AVR_Device_HVPP.h"
#include "AVR_HVSP/AVR_Device_HVSP.h"
#include "AVR_JTAG/AVR_Device_JTAG.h"

#if AVR_DEVICE_OFFLINE_EN
#include "AVR_Phenix/AVR_Device_Phenix.h"
#endif

#include "../AVR_Programming/ISP/SPI/spi.h"

#if AVRD_JTAG_SHOULD_ENABLE
#include "../AVR_Debugging/JTAG/AVR_JTAGOCD.h"
#include "../AVR_Debugging/DW/AVR_DWOCD.h"
#endif


#if (AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII) || (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON)
// essential if using avrdude, for avrdude will eat first 8 bytes on bulk EP(maybe it is libusb who eats it), so just send a ZLP fisrt if Send_Sign_On is 1
uint8 Send_Sign_On = 0;
#endif

#if AVR_DEVICE_ATMEL == AVR_DEVICE_AVRISP_MKII
uint8 AVR_Device_Name[10] = "AVRISP_MK2";
#elif AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII
uint8 AVR_Device_Name[12] = "JTAGICE mkII";
#elif AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON
uint8 AVR_Device_Name[9] = "AVRDRAGON";
#elif AVR_DEVICE == AVR_DEVICE_STK600
uint8 AVR_Device_Name[6] = "STK600";
#endif

#if (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRISP_MKII)
uint8 Vtarget = 50;
#elif (AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII) || (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON)
uint16 Vtarget = 5000;
#endif

#if AVRP_HVPP_SHOULD_ENABLE || AVRP_HVSP_SHOULD_ENABLE
uint8 hvControlStack[32];
const uint8 HV_PageSize[8] PROGMEM = {128,1,2,4,8,16,32,64};
#endif

#if AVRP_ISP_SHOULD_ENABLE && ISP_AutoSpeed_En
uint8 ISP_AutoSpeed = 1;
#endif

// Parameters
uint8 Program_Speed;
#if AVRP_ISP_SHOULD_ENABLE
uint8 Reset_Polarity = 1;
uint8 Discharge_Delay;
#endif

#if AVRD_JTAG_SHOULD_ENABLE || AVRD_DW_SHOULD_ENABLE
uint8 Emulator_Mode = 2;		// 0x03
//uint8 JTAG_Clk;					// 0x07
uint8 OCD_Break_Cause;			// 0x08
//uint8 Timers_Running;			// 0x09
//uint8 Break_on_Charge_of_Flow;	// 0x0A
uint8 Target_MCU_State = 0;			// 0x1A
//uint8 Daisy_Chain_Info[4];		// 0x1B
//uint8 Boot_Address[4];			// 0x1C
uint32 Program_Entry_Point;	// 0x1F
//uint8 CAN_Flag;					// 0x22

uint8 TargetPower = 0;
#endif

uint8 AVRP_Programming = 0;		// used to control led blink

// for packet transiver
uint8 AVR_Device_DataBuff[CMD_MAX_PKGSIZE];

uint16 RSP_Len;
uint16 RSP_Len_tmp;

uint16 CMD_Len;
uint16 CMD_Len_tmp;


#if (AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII) || (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON)
uint16 AVRP_TxLen;
#endif


#if (AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII) || (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON)
/***************************************** CRC Calc. *****************************************/
const uint16 crc_tbl[256] PROGMEM = 
{0x0000, 0x1189, 0x2312, 0x329b, 0x4624, 0x57ad, 0x6536, 0x74bf,
 0x8c48, 0x9dc1, 0xaf5a, 0xbed3, 0xca6c, 0xdbe5, 0xe97e, 0xf8f7,
 0x1081, 0x0108, 0x3393, 0x221a, 0x56a5, 0x472c, 0x75b7, 0x643e,
 0x9cc9, 0x8d40, 0xbfdb, 0xae52, 0xdaed, 0xcb64, 0xf9ff, 0xe876,
 0x2102, 0x308b, 0x0210, 0x1399, 0x6726, 0x76af, 0x4434, 0x55bd,
 0xad4a, 0xbcc3, 0x8e58, 0x9fd1, 0xeb6e, 0xfae7, 0xc87c, 0xd9f5,
 0x3183, 0x200a, 0x1291, 0x0318, 0x77a7, 0x662e, 0x54b5, 0x453c,
 0xbdcb, 0xac42, 0x9ed9, 0x8f50, 0xfbef, 0xea66, 0xd8fd, 0xc974,
 0x4204, 0x538d, 0x6116, 0x709f, 0x0420, 0x15a9, 0x2732, 0x36bb,
 0xce4c, 0xdfc5, 0xed5e, 0xfcd7, 0x8868, 0x99e1, 0xab7a, 0xbaf3,
 0x5285, 0x430c, 0x7197, 0x601e, 0x14a1, 0x0528, 0x37b3, 0x263a,
 0xdecd, 0xcf44, 0xfddf, 0xec56, 0x98e9, 0x8960, 0xbbfb, 0xaa72,
 0x6306, 0x728f, 0x4014, 0x519d, 0x2522, 0x34ab, 0x0630, 0x17b9,
 0xef4e, 0xfec7, 0xcc5c, 0xddd5, 0xa96a, 0xb8e3, 0x8a78, 0x9bf1,
 0x7387, 0x620e, 0x5095, 0x411c, 0x35a3, 0x242a, 0x16b1, 0x0738,
 0xffcf, 0xee46, 0xdcdd, 0xcd54, 0xb9eb, 0xa862, 0x9af9, 0x8b70,
 0x8408, 0x9581, 0xa71a, 0xb693, 0xc22c, 0xd3a5, 0xe13e, 0xf0b7,
 0x0840, 0x19c9, 0x2b52, 0x3adb, 0x4e64, 0x5fed, 0x6d76, 0x7cff,
 0x9489, 0x8500, 0xb79b, 0xa612, 0xd2ad, 0xc324, 0xf1bf, 0xe036,
 0x18c1, 0x0948, 0x3bd3, 0x2a5a, 0x5ee5, 0x4f6c, 0x7df7, 0x6c7e,
 0xa50a, 0xb483, 0x8618, 0x9791, 0xe32e, 0xf2a7, 0xc03c, 0xd1b5,
 0x2942, 0x38cb, 0x0a50, 0x1bd9, 0x6f66, 0x7eef, 0x4c74, 0x5dfd,
 0xb58b, 0xa402, 0x9699, 0x8710, 0xf3af, 0xe226, 0xd0bd, 0xc134,
 0x39c3, 0x284a, 0x1ad1, 0x0b58, 0x7fe7, 0x6e6e, 0x5cf5, 0x4d7c,
 0xc60c, 0xd785, 0xe51e, 0xf497, 0x8028, 0x91a1, 0xa33a, 0xb2b3,
 0x4a44, 0x5bcd, 0x6956, 0x78df, 0x0c60, 0x1de9, 0x2f72, 0x3efb,
 0xd68d, 0xc704, 0xf59f, 0xe416, 0x90a9, 0x8120, 0xb3bb, 0xa232,
 0x5ac5, 0x4b4c, 0x79d7, 0x685e, 0x1ce1, 0x0d68, 0x3ff3, 0x2e7a,
 0xe70e, 0xf687, 0xc41c, 0xd595, 0xa12a, 0xb0a3, 0x8238, 0x93b1,
 0x6b46, 0x7acf, 0x4854, 0x59dd, 0x2d62, 0x3ceb, 0x0e70, 0x1ff9,
 0xf78f, 0xe606, 0xd49d, 0xc514, 0xb1ab, 0xa022, 0x92b9, 0x8330,
 0x7bc7, 0x6a4e, 0x58d5, 0x495c, 0x3de3, 0x2c6a, 0x1ef1, 0x0f78
};

#define CRC_INIT				0xFFFF
uint16 CRC_Val;

void CRC16(uint8 c)
{
	uint16 tbl_val;
	uint8 idx = (CRC_Val ^ c);

	tbl_val = pgm_read_word(crc_tbl + idx);

	CRC_Val = (CRC_Val >> 8) ^ tbl_val;
}


/***************************************** Common Responses *****************************************/
void PrepareRSP(uint8 ID,uint16 len)
{
	RSP_Len = len;
	RSP_Len_tmp = 0;
	AVR_Device_DataBuff[8] = ID;
}

#endif	// #if (AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII) || (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON)

/***************************************** Command Processors *****************************************/

#if AVRP_ISP_SHOULD_ENABLE || AVRP_HVPP_SHOULD_ENABLE || AVRP_HVSP_SHOULD_ENABLE || AVR_DEVICE_OFFLINE_EN
// Internal programming address
uint8 __prog_addr_over_64k;
uint16 __prog_addr;

uint8 AVRP_ProcessGenCmd(uint8* dat,uint16 len)
{
	switch(dat[0])
	{
#if (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRISP_MKII)
	case AVRP_CMD_SIGN_ON:
		dat[2] = sizeof(AVR_Device_Name);
		memcpy(&dat[3],AVR_Device_Name,sizeof(AVR_Device_Name));
		AVRP_TxLen = AVRISP_CMD_SIGN_ON_RLEN_S;
		break;
#endif
	case AVRP_CMD_SET_PARAMETER:
		switch(dat[1])
		{
#if AVRP_ISP_SHOULD_ENABLE
		case AVRISP_PARAM_SCK_DURATION:
			Program_Speed = dat[2];
#if ISP_AutoSpeed_En
			ISP_AutoSpeed = 0;
#endif
			if(EEPROM_Read(0) != Program_Speed)
				EEPROM_Write(0,Program_Speed);
			break;
		case AVRISP_PARAM_RESET_POLARITY:
			Reset_Polarity = dat[2];
			break;
		case AVRISP_PARAM_DISCHARGEDELAY:
//			Discharge_Delay = dat[2];
			break;
#endif
		default:
			AVRP_TxLen = AVRISP_CMD_SET_PARAMETER_RLEN_F;
			return AVRP_STATUS_CMD_FAILED;
			break;
		}
		AVRP_TxLen = AVRISP_CMD_SET_PARAMETER_RLEN_S;
		break;
	case AVRP_CMD_GET_PARAMETER:
		switch(dat[1])
		{
#if (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRISP_MKII)
		case AVRISP_PARAM_BUILD_NUMBER_LOW:
			dat[2] = AVRISP_mkII_BUILD_NUMBER;
			break;
		case AVRISP_PARAM_BUILD_NUMBER_HIGH:
			dat[2] = AVRISP_mkII_BUILD_NUMBER >> 8;
			break;
		case AVRISP_PARAM_HW_VER:
			dat[2] = AVRISP_mkII_HW_VER;
			break;
		case AVRISP_PARAM_SW_MAJOR:
			dat[2] = AVRISP_mkII_FW_MAJOR_VER;
			break;
		case AVRISP_PARAM_SW_MINOR:
			dat[2] = AVRISP_mkII_FW_MINOR_VER;
			break;
		case AVRISP_PARAM_VTARGET:
			dat[2] = Vtarget;
			break;
#endif
		// AVR Studio 4.13SP2b571 will read this even if not use ISP
		case AVRISP_PARAM_SCK_DURATION:
#if AVRP_ISP_SHOULD_ENABLE && ISP_AutoSpeed_En
			if(ISP_AutoSpeed && (Program_Speed > 6))
				Program_Speed = 0;
#endif
			dat[2] = Program_Speed;
			break;
#if AVRP_ISP_SHOULD_ENABLE
		case AVRISP_PARAM_RESET_POLARITY:
// will AVRISP mkII will read this byte
//			dat[2] = Reset_Polarity;
//			break;
		case AVRISP_PARAM_DISCHARGEDELAY:
// will AVRISP mkII will read this byte
//			dat[2] = Discharge_Delay;
#endif
		case AVRISP_PARAM_STATUS_TGT_CONN:
// not understand what to send according to USB-proto of AVRISP mkII
//			dat[2] = 0;
//			break;
		default:
			AVRP_TxLen = AVRISP_CMD_GET_PARAMETER_RLEN_F;
			return AVRP_STATUS_CMD_FAILED;
			break;
		}
		AVRP_TxLen = AVRISP_CMD_GET_PARAMETER_RLEN_S;
		break;
#if (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRISP_MKII)
	case AVRP_CMD_OSCCAL:
		AVRP_TxLen = AVRISP_CMD_OSCCAL_RLEN_S;
		break;
#endif
	case AVRP_CMD_LOAD_ADDRESS:
		__prog_addr_over_64k = dat[1];
		__prog_addr = (dat[3] << 8) + dat[4];
		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_OK;
		break;
#if (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRISP_MKII)
	case AVRP_CMD_FIRMWARE_UPGRADE:
		AVR_Device_Upgrade();
		break;
	case AVRP_CMD_RESET_PROTECTION:
		AVRP_TxLen = 2;
		break;
#endif
	default:
		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_UNKNOWN;
		break;
	}

	return AVRP_STATUS_CMD_OK;
}

void AVRP_ProcessCmd(uint8 *dat,uint16 len)
{
	uint8 tmp = 0;

	if((dat[0] & AVRP_CMD_PROGMODE_MSK) == AVRP_CMD_GENERAL)
		tmp = AVRP_ProcessGenCmd(dat,len);
#if AVRP_ISP_SHOULD_ENABLE
	else if((dat[0] & AVRP_CMD_PROGMODE_MSK) == AVRP_CMD_PROGMODE_ISP)
	{
		tmp = AVRP_ISP_ProcessProgCmd(dat,len);
	}
#endif
#if AVRP_HVPP_SHOULD_ENABLE || AVRP_HVSP_SHOULD_ENABLE
	else if(dat[0] == 0x2D)
	{
		// CMD_SET_CONTROL_STACK, for both HVPP and HVSP
		memcpy(hvControlStack,&dat[1],sizeof(hvControlStack));
		AVRP_TxLen = 2;
		tmp = AVRP_STATUS_CMD_OK;
	}
#if AVRP_HVSP_SHOULD_ENABLE
	else if((dat[0] & AVRP_CMD_PROGMODE_MSK) == AVRP_CMD_PROGMODE_HVSP)
		tmp = AVRP_HVSP_ProcessProgCmd(dat,len);
#endif
#if AVRP_HVPP_SHOULD_ENABLE
	else if((dat[0] & AVRP_CMD_PROGMODE_MSK) == AVRP_CMD_PROGMODE_HVPP)
		tmp = AVRP_HVPP_ProcessProgCmd(dat,len);
#endif
#endif
#if AVR_DEVICE_OFFLINE_EN
	else if((dat[0] & AVRP_CMD_PROGMODE_MSK) == AVRP_CMD_PHENIX)
	{
		tmp = AVRP_Phenix_ProcessProgCmd(dat,len);
	}
#endif
	else
	{
		AVRP_TxLen = 2;
		tmp = AVRP_STATUS_CMD_UNKNOWN;
	}

	dat[1] = tmp;
}
#endif

#if (AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII) || (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON)
void AVR_Device_ProcessCmd(uint8* dat,uint16 len)
{
	len -= 2;		// 2 bytes CRC

	if(dat[8] == JTAGICE_CMND_PROG_PACKET)
	{
#if AVRP_ISP_SHOULD_ENABLE || AVRP_HVPP_SHOULD_ENABLE || AVRP_HVSP_SHOULD_ENABLE || AVR_DEVICE_OFFLINE_EN
		AVRP_ProcessCmd(dat + 11,len - 11);

		memcpy(dat + 9,dat + 11,AVRP_TxLen);

		_RSP_SPI_DATA();
#else
		_RSP_ILLEGAL_COMMAND();
#endif
	}
#if (AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII) || (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON)
	else
	{
		AVRP_JTAG_ProcessProgCmd(dat,len);
	}
#endif
}
#endif

#if AVRD_JTAG_SHOULD_ENABLE || AVRD_DW_SHOULD_ENABLE
void AVR_Device_CheckEvent(void)
{
	uint8 tmp[4],pc[2];

	// Check TargetPower
	if(TargetPower)
	{
#if (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRISP_MKII)
		if(Vtarget < 27)
#elif (AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII) || (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON)
		if(Vtarget < 2700)
#endif
		{
			TargetPower = 0;
			_EVT_TARGET_POWER_OFF();
			return;
		}
	}
	else
	{
#if (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRISP_MKII)
		if(Vtarget >= 27)
#elif (AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII) || (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON)
		if(Vtarget >= 2700)
#endif
		{
			TargetPower = 1;
			_EVT_TARGET_POWER_ON();
			return;
		}
	}

	if(Target_MCU_State != 1)
		return;

	// Check External Reset
	

	// Check Sleep
	

	// Check ICE Power
	

	// Check IDR
	

	// Check Break;
	AVR_JTAGOCD_ReadOCD(AVR_JTAG_OCDREG_BSR,tmp);
	if(tmp[0])
	{
		// Break occurs
		AVR_JTAGOCD_CheckPC(pc);
		AVR_Device_DataBuff[9] = pc[0] - 1;
		AVR_Device_DataBuff[10] = pc[1];
		AVR_Device_DataBuff[11] = 0;
		AVR_Device_DataBuff[12] = 0;

		if(tmp[0] & (AVR_JTAG_BSR_PSB0 | AVR_JTAG_BSR_PSB1 | AVR_JTAG_BSR_BRK_INSTR))
			AVR_Device_DataBuff[13] = 1;		// Program Break
		else if(tmp[0] & (AVR_JTAG_BSR_PDSB))
			AVR_Device_DataBuff[13] = 2;		// Data Break PDSB
		else if(tmp[0] & (AVR_JTAG_BSR_PDMSB))
			AVR_Device_DataBuff[13] = 3;		// Data Break PDMSB

		Target_MCU_State = 0;		// Stopped

		_EVT_BREAK();
		return;
	}
}
#endif

#if (AVR_DEVICE == AVR_DEVICE_AVRISP_MKII)
void AVR_Device_Upgrade(void)
{
	cli();
	LED_Off(LED_Red | LED_Green);

	// Write EEPROM address 0xFF
	EEPROM_Write(0xFF,0);

	// Enable WDT,if your Bootloader can accept a wdt-reset
//	WDT_SetRstMode(WDT_CLK_DIV64K);
	while(1);
}
#endif
