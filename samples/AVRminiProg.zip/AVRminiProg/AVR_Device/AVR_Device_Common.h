/* Name: AVR_Device_Common.h
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2008-1-24 01:50
 */
#define RSP_MAX_PKGSIZE				278
#define CMD_MAX_PKGSIZE				317

extern uint8 Send_Sign_On;

#if (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRISP_MKII)
extern uint8 Vtarget;
#define Vtarget_HasPower			27
#elif (AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII) || (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON)
extern uint16 Vtarget;
#define Vtarget_HasPower			2700
#endif

#if AVRP_HVPP_SHOULD_ENABLE || AVRP_HVSP_SHOULD_ENABLE
extern uint8 hvControlStack[32];
extern const uint8 HV_PageSize[8];
#endif

#if AVRP_ISP_SHOULD_ENABLE && ISP_AutoSpeed_En
uint8 ISP_AutoSpeed;
#endif

#if AVRP_ISP_SHOULD_ENABLE
extern uint8 Program_Speed;
extern uint8 Reset_Polarity;
extern uint8 Discharge_Delay;
#endif

#if AVRD_JTAG_SHOULD_ENABLE || AVRD_DW_SHOULD_ENABLE
extern uint8 Emulator_Mode;				// 0x03
//extern uint8 JTAG_Clk;					// 0x07
extern uint8 OCD_Break_Cause;			// 0x08
//extern uint8 Timers_Running;			// 0x09
//extern uint8 Break_on_Charge_of_Flow;	// 0x0A
extern uint8 Target_MCU_State;			// 0x1A
//extern uint8 Daisy_Chain_Info[4];		// 0x1B
//extern uint8 Boot_Address[4];			// 0x1C
extern uint32 Program_Entry_Point;	// 0x1F
//extern uint8 CAN_Flag;					// 0x22
#endif

extern uint8 AVRP_Programming;

#if (AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII) || (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON)
#define CRC_INIT				0xFFFF
extern uint16 CRC_Val;
void CRC16(uint8);
#endif

#if AVR_DEVICE_ATMEL == AVR_DEVICE_AVRISP_MKII
uint8 AVR_Device_Name[10];
#elif AVR_DEVICE_ATMEL == AVR_DEVICE_JTAGICE_MKII
uint8 AVR_Device_Name[12];
#elif AVR_DEVICE_ATMEL == AVR_DEVICE_AVRDRAGON
uint8 AVR_Device_Name[9];
#elif AVR_DEVICE_ATMEL == AVR_DEVICE_STK600
uint8 AVR_Device_Name[6];
#endif


extern uint8 AVR_Device_DataBuff[CMD_MAX_PKGSIZE];

extern uint16 RSP_Len;
extern uint16 RSP_Len_tmp;

extern uint16 CMD_Len;
extern uint16 CMD_Len_tmp;

#if AVRP_ISP_SHOULD_ENABLE || AVRP_HVPP_SHOULD_ENABLE || AVRP_HVSP_SHOULD_ENABLE
extern uint8 __prog_addr_over_64k;
extern uint16 __prog_addr;
#endif

#if (AVR_DEVICE_ATMEL == AVR_DEVICE_AVRISP_MKII)
#define AVRP_TxLen	RSP_Len
#define AVR_Device_ProcessCmd AVRP_ProcessCmd
void AVRP_ProcessCmd(uint8*,uint16);
#else
extern uint16 AVRP_TxLen;
void AVR_Device_ProcessCmd(uint8*,uint16);
#endif

#if AVRD_JTAG_SHOULD_ENABLE || AVRD_DW_SHOULD_ENABLE
void AVR_Device_CheckEvent(void);
#endif

void AVR_Device_Upgrade(void);

/***************************************** Common Responses *****************************************/
void PrepareRSP(uint8,uint16);
#define _RSP_OK()							PrepareRSP(RSP_OK,1)
#define _RSP_FAILED()						PrepareRSP(RSP_FAILED,1)
#define _RSP_ILLEGAL_PARAMETER()			PrepareRSP(RSP_ILLEGAL_PARAMETER,1)
#define _RSP_ILLEGAL_MEMORY_TYPE()			PrepareRSP(RSP_ILLEGAL_MEMORY_TYPE,1)
#define _RSP_ILLEGAL_MEMORY_RANGE()			PrepareRSP(RSP_ILLEGAL_MEMORY_RANGE,1)
#define _RSP_ILLEGAL_COMMAND()				PrepareRSP(RSP_ILLEGAL_COMMAND,1)
#define _RSP_ILLEGAL_VALUE()				PrepareRSP(RSP_ILLEGAL_VALUE,1)
#define _RSP_ILLEGAL_JTAG_ID()				PrepareRSP(RSP_ILLEGAL_JTAG_ID,1)
#define _RSP_NO_TARGET_POWER()				PrepareRSP(RSP_NO_TARGET_POWER,1)
#define _RSP_ILLEGAL_POWER_STATE()			PrepareRSP(RSP_ILLEGAL_POWER_STATE,1)
#define _RSP_MEMORY(len)					PrepareRSP(RSP_MEMORY,1 + len)
#define _RSP_SPI_DATA()						PrepareRSP(RSP_SPI_DATA,AVRP_TxLen + 1)
#define _RSP_SELFTEST()						PrepareRSP(RSP_SELFTEST,9)



/***************************************** Common Events *****************************************/
#define _EVT_BREAK()						PrepareRSP(EVT_BREAK,6)
#define _EVT_TARGET_POWER_ON()				PrepareRSP(EVT_TARGET_POWER_ON,1)
#define _EVT_TARGET_POWER_OFF()				PrepareRSP(EVT_TARGET_POWER_OFF,1)
#define _EVT_EXT_RESET()					PrepareRSP(EVT_EXT_RESET,1)
#define _EVT_TARGET_SLEEP()					PrepareRSP(EVT_TARGET_SLEEP,1)
#define _EVT_TARGET_WAKEUP()				PrepareRSP(EVT_TARGET_WAKEUP,1)
#define _EVT_ICE_POWER_ERROR_STATE()		PrepareRSP(EVT_ICE_POWER_ERROR_STATE,1)
#define _EVT_ICE_POWER_OK()					PrepareRSP(EVT_ICE_POWER_OK,1)
#define _EVT_IDR_DIRTY()					PrepareRSP(EVT_IDR_DIRTY,2)


/***************************************** Const Definations *****************************************/
// Commands Type
#define AVRP_CMD_PROGMODE_MSK				0x30
#define AVRP_CMD_GENERAL					0x00
#define AVRP_CMD_PROGMODE_ISP				0x10
#define AVRP_CMD_PROGMODE_HVPP				0x20
#define AVRP_CMD_PROGMODE_HVSP				0x30

// Status(Reply)
#define AVRP_STATUS_CMD_OK					0x00
#define AVRP_STATUS_CMD_TOUT				0x80
#define AVRP_STATUS_RDY_BSY_TOUT			0x81
#define AVRP_STATUS_SET_PARAM_MISSING		0x82
#define AVRP_STATUS_CMD_FAILED				0xC0
#define AVRP_STATUS_CMD_UNKNOWN				0xC9

// Programming Command
#define AVRP_CMD_MSK						0x0F
#define AVRP_CMD_ENTER_PROGMODE				0x00
#define AVRP_CMD_EXIT_PROGMODE				0x01
#define AVRP_CMD_CHIP_ERASE					0x02
#define AVRP_CMD_PROGRAM_FLASH				0x03
#define AVRP_CMD_READ_FLASH					0x04
#define AVRP_CMD_PROGRAM_EEPROM				0x05
#define AVRP_CMD_READ_EEPROM				0x06
#define AVRP_CMD_PROGRAM_FUSE				0x07
#define AVRP_CMD_READ_FUSE					0x08
#define AVRP_CMD_PROGRAM_LOCKBIT			0x09
#define AVRP_CMD_READ_LOCKBIT				0x0A
#define AVRP_CMD_READ_SIGNATURE				0x0B
#define AVRP_CMD_READ_OSCCAL				0x0C
#define AVRP_CMD_SPECIAL_OPERATION			0x0D

// General Command
#define AVRP_CMD_SIGN_ON					0x01
#define AVRP_CMD_SET_PARAMETER				0x02
#define AVRP_CMD_GET_PARAMETER				0x03
#define AVRP_CMD_OSCCAL						0x05
#define AVRP_CMD_LOAD_ADDRESS				0x06
#define AVRP_CMD_FIRMWARE_UPGRADE			0x07
#define AVRP_CMD_RESET_PROTECTION			0x0A

// State Machine
#define STATEMACHINE_MESSAGE_START			0x01
#define STATEMACHINE_SEQUENCE_NUMBER		0x02
#define STATEMACHINE_MESSAGE_SIZE			0x03
#define STATEMACHINE_TOKEN					0x04
#define STATEMACHINE_MESSAGE_BODY			0x05
#define STATEMACHINE_CRC					0x06

// RSP
#define RSP_OK								0x80
#define RSP_FAILED							0xA0
#define RSP_ILLEGAL_PARAMETER				0xA1
#define RSP_PARAMETER						0x81
#define RSP_ILLEGAL_MEMORY_TYPE				0xA2
#define RSP_ILLEGAL_MEMORY_RANGE			0xA3
#define RSP_MEMORY							0x82
#define RSP_GET_BREAK						0x83
#define RSP_ILLEGAL_EMULATOR_MODE			0xA4
#define RSP_ILLEGAL_MCU_STATE				0xA5
#define RSP_PC								0x84
#define RSP_SELFTEST						0x85
#define RSP_SPI_DATA						0x88
#define RSP_ILLEGAL_COMMAND					0xAA
#define RSP_ILLEGAL_VALUE					0xA6
#define RSP_SIGN_ON							0x86
#define RSP_ILLEGAL_BREAKPOINT				0xA8
#define RSP_ILLEGAL_JTAG_ID					0xA9
#define RSP_NO_TARGET_POWER					0xAB
#define RSP_DEBUGWIRE_SYNC_FAILED			0xAC
#define RSP_ILLEGAL_POWER_STATE				0xAD

// EVT
#define EVT_INVALID							0x00
#define EVT_BASE							0xE0
#define EVT_BREAK							0xE0
#define EVT_RUN								0xE1
#define EVT_TARGET_POWER_ON					0xE4
#define EVT_TARGET_POWER_OFF				0xE5
#define EVT_DEBUG							0xE6
#define EVT_EXT_RESET						0xE7
#define EVT_TARGET_SLEEP					0xE8
#define EVT_TARGET_WAKEUP					0xE9
#define EVT_ICE_POWER_ERROR_STATE			0xEA
#define EVT_ICE_POWER_OK					0xEB
#define EVT_IDR_DIRTY						0xEC
#define EVT_NONE							0xEF
#define EVT_PROGRAM_BREAK					0xF1
#define EVT_PDSB_BREAK						0xF2
#define EVT_PDSMB_BREAK						0xF3
#define EVT_ERROR_PHY_X					
	#define ERROR_PHY_FORCE_BREAK_TIMEOUT	0xE2
	#define ERROR_PHY_RELEASE_BREAK_TIMEOUT	0xE3
	#define ERROR_PHY_MAX_BIT_LENGTH_DIFF	0xED
	#define ERROR_PHY_SYNC_TIMEOUT			0xF0
	#define ERROR_PHY_SYNC_TIMEOUT_BAUD		0xF4
	#define ERROR_PHY_SYNC_OUT_OF_RANGE		0xF5
	#define ERROR_PHY_SYNC_WAIT_TIMEOUT		0xF6
	#define ERROR_PHY_RECEIVE_TIMEOUT		0xF7
	#define ERROR_PHY_RECEIVED_BREAK		0xF8
	#define ERROR_PHY_OPT_RECEIVE_TIMEOUT	0xF9
	#define ERROR_PHY_OPT_RECEIVED_BREAK	0xFA
	#define RESULT_PHY_NO_ACTIVITY			0xFB

#define MESSAGE_START_CHAR					0x1B
#define TOKEN_CHAR							0x0E
