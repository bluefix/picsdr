/* Name: AVR_Device_HVSP.h
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2007-11-7 0:40:52
 */

uint8 AVRP_HVSP_ProcessProgCmd(uint8*,uint16);
