/* Name: AVR_Device_HVSP.c
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2008-1-24 01:50
 */
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <string.h>

#include "../../type.h"
#include "../../app_cfg.h"

#include "../../MCU/gpio.h"

#include "../../Delay/delay.h"

#include "../AVR_Device_Common.h"

#include "AVR_Device_HVSP.h"

#include "../../AVR_Programming/HV/HV.h"
#include "../../AVR_Programming/HV/HVSP/HVSP.h"


#if AVRP_HVSP_SHOULD_ENABLE

uint8 AVRP_HVSP_ProcessProgCmd(uint8* dat,uint16 len)
{
	uint8 length8,mode,j,pagesize;
	uint16 length16,i;

	switch(dat[0] & AVRP_CMD_MSK)
	{
	case AVRP_CMD_ENTER_PROGMODE:
//dat[idx]	para(value)				Description
//dat[1]	stabDelay(100)			Delay(in ms) used for pin stabilization
//dat[2]	cmdexeDelay()			Delay(in ms) in connection with the EnterProgMode command execution
//dat[3]	SynchCycles()			Number of synchronization clock cycles
//dat[4]	latchCycles()			Number of PulseXtal1_HVSP cycles
//dat[5]	toggleVtg(1)			Toggle Vtg when entering prog mode(0=no,1=yes).For parts with RSTDSBL functionality
//dat[6]	powerOffDelay()			Power-off delay.Additional delay(in ms) after Vtg is turned off in order to make sure the Vtg is low enough
//dat[7]	resetDelayMs()			RSTDELAY#1(in ms).Additional delay between Vtg is turned on and reset goes high
//dat[8]	resetDelayUs()			RSTDELAY#2(in us*10).Additional delay between Vtg is turned on and reset goes high.Total delay is RSTDELAY#1(ms) + RSTDELAY#2(us*10)
		AVRP_Programming = 4;

		HVSP_Init();

		// Power and Reset to '0'
		HV_TargetReset_0V();
		DelayMS(5);

		// Set Prog_enable PINs to '0'
		if(HVSP_AltProgEnablePin_En())
		{
			HVSP_ClrAltProgEnablePin();
		}
		else
		{
			HVSP_SDO_SetOutput();
			HVSP_SDO_Clr();
			HVSP_SDI_Clr();
			HVSP_SII_Clr();
		}

		// TVCC on
		HV_TargetVCC_On();

		// resetDelay
		DelayMS(dat[7]);
		DelayUS(dat[8] * 10);

		// Toggle SCI, U can toggle a pin by set corresponding bit in PINX, but NOT all AVRs support that
		for(j = 0;j < dat[3];j++)
		{
			HVSP_SCI_Set();
			DelayUS(0);
			HVSP_SCI_Clr();
		}

		// apply 12V to nRST
		HV_TargetReset_12V();
		DelayUS(0);

		// Set SDO input
		HVSP_SDO_SetInput();

		// cmdexeDelay
		DelayMS(dat[2]);

		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_EXIT_PROGMODE:
		DelayMS(dat[2]);
//		HVSP_RDY_Wait();

		HVSP_Fini();

		DelayMS(dat[1]);

		AVRP_Programming = 0;
		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_CHIP_ERASE:
		if(HVSP_RDY_Wait())
		{
			AVRP_TxLen = 2;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}

		HVSP_LoadCommand(HVCMD_CHIP_ERASE);
		HVSP_nWR_NPulse(HVSP_BS_LowByte);

		if(dat[2] && HVSP_RDY_Wait())
		{
			AVRP_TxLen = 2;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}

		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_PROGRAM_FLASH:
		length8 = dat[2] >> 1;
		if(dat[1] & 0x01)
			length8 |= 0x80;

		mode = dat[3];
		pagesize = pgm_read_word(HV_PageSize + ((mode & 0x0E) >> 1));

		if(HVSP_RDY_Wait())
		{
			AVRP_TxLen = 2;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}

		HVSP_LoadCommand(HVCMD_WRITE_FLASH);

		if(mode & 1)
		{
			// Page Mode
			length8 /= pagesize;
			for(i = 0;i < length8;i++)
			{
				length16 = __prog_addr;
				for(j = 0;j < pagesize;j++)
				{
					HVSP_LoadAddressLowByte(__prog_addr);
					HVSP_LoadDataLowByte(dat[5 + i * pagesize * 2 + j * 2]);
					HVSP_LoadDataHighByte(dat[6 + i * pagesize * 2 + j * 2]);

					HVSP_LatchFlashData();

					__prog_addr++;
				}
				if(mode & 0x80)
				{
					HVSP_LoadAddressHighByte(length16 >> 8);
					if(__prog_addr_over_64k)
						HVSP_LoadAddressExtendedHighByte(1);

					HVSP_WriteDataLowByte();

					if(HVSP_RDY_Wait())
					{
						AVRP_TxLen = 2;
						return AVRP_STATUS_RDY_BSY_TOUT;
					}
				}
			}
		}
		else
		{
			// Non Page Mode
			HVSP_LoadAddressHighByte(__prog_addr >> 8);
			for(i = 0;i < length8;i++)
			{
				HVSP_LoadAddressLowByte(__prog_addr);
				HVSP_LoadDataLowByte(dat[5 + i * 2]);
				HVSP_WriteDataLowByte();
				if(HVSP_RDY_Wait())
				{
					AVRP_TxLen = 2;
					return AVRP_STATUS_RDY_BSY_TOUT;
				}

				HVSP_LoadDataHighByte(dat[6 + i * 2]);
				HVSP_WriteDataHighByte();
				if(HVSP_RDY_Wait())
				{
					AVRP_TxLen = 2;
					return AVRP_STATUS_RDY_BSY_TOUT;
				}
				__prog_addr++;
			}
		}

		HVSP_LoadCommand(HVCMD_NOP);

		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_READ_FLASH:
		length8 = dat[2] >> 1;
		if(dat[1] & 0x01)
			length8 |= 0x80;

		HVSP_RDY_Wait();
		HVSP_LoadCommand(HVCMD_READ_FLASH);

		if(__prog_addr_over_64k)
			HVSP_LoadAddressExtendedHighByte(1);
		HVSP_LoadAddressHighByte(__prog_addr >> 8);
		for(i = 0;i < length8;i++)
		{
			HVSP_LoadAddressLowByte(__prog_addr);

			HVSP_EnableReadData(HVSP_BS_LowByte);
			dat[2 + 2 * i] = HVSP_ReadData(HVSP_BS_LowByte);
			HVSP_ReadDataChangeByte(HVSP_BS_HighByte);
			dat[3 + 2 * i] = HVSP_ReadData(HVSP_BS_HighByte);

			__prog_addr++;
		}

		dat[2 + length8 * 2] = AVRP_STATUS_CMD_OK;
		AVRP_TxLen = 3 + length8 * 2;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_PROGRAM_EEPROM:
		length16 = dat[2] | (dat[1] << 8);

		mode = dat[3];
		pagesize = pgm_read_word(HV_PageSize + ((mode & 0x0E) >> 1));

		HVSP_RDY_Wait();
		HVSP_LoadCommand(HVCMD_WRITE_EEPROM);

		if(mode & 1)
		{
			// Page Mode
			length8 = length16 / pagesize;
			for(i = 0;i < length8;i++)
			{
				HVSP_LoadAddressHighByte(__prog_addr >> 8);
				for(j = 0;j < pagesize;j++)
				{
					HVSP_LoadAddressLowByte(__prog_addr);
					HVSP_LoadDataLowByte(dat[5 + i * pagesize + j]);

					HVSP_LatchEEPROMData();

					__prog_addr++;
				}
				if(mode & 0x80)
				{
					HVSP_WriteDataLowByte();

					if(HVSP_RDY_Wait())
					{
						AVRP_TxLen = 2;
						return AVRP_STATUS_RDY_BSY_TOUT;
					}
				}
			}
		}
		else
		{
			// Non Page Mode
			HVSP_LoadAddressHighByte(__prog_addr >> 8);
			for(i = 0;i < length16;i++)
			{
				HVSP_LoadAddressLowByte(__prog_addr);
				HVSP_LoadDataLowByte(dat[5 + i * 2]);
				HVSP_WriteDataLowByte();
				if(HVSP_RDY_Wait())
				{
					AVRP_TxLen = 2;
					return AVRP_STATUS_RDY_BSY_TOUT;
				}

				HVSP_LoadDataHighByte(dat[6 + i * 2]);
				HVSP_WriteDataHighByte();
				if(HVSP_RDY_Wait())
				{
					AVRP_TxLen = 2;
					return AVRP_STATUS_RDY_BSY_TOUT;
				}
				__prog_addr++;
			}
		}

		HVSP_LoadCommand(HVCMD_NOP);

		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_READ_EEPROM:
		length16 = dat[2] | (dat[1] << 8);

		HVSP_RDY_Wait();
		HVSP_LoadCommand(HVCMD_READ_EEPROM);

		HVSP_LoadAddressHighByte(__prog_addr >> 8);
		for(i = 0;i < length16;i++)
		{
			HVSP_LoadAddressLowByte(__prog_addr);
			HVSP_EnableReadData(HVSP_BS_LowByte);
			dat[2 + i] = HVSP_ReadData(HVSP_BS_LowByte);

			__prog_addr++;
		}

		dat[2 + length16] = AVRP_STATUS_CMD_OK;
		AVRP_TxLen = 3 + length16;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_PROGRAM_FUSE:
//dat[idx]	para(value)				Description
//dat[1]	address					Address of byte to write
//dat[2]	data					data to be programmed
//dat[3]	pollTimeout				Poll timeout
		if(HVSP_RDY_Wait())
		{
			AVRP_TxLen = 2;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}

		mode = dat[1];
		if(mode == 0)
			mode = HVSP_BS_LowByte;
		else if(mode == 1)
			mode = HVSP_BS_HighByte;
		else if(mode == 2)
			mode = HVSP_BS_ExtLowByte;

		HVSP_LoadCommand(HVCMD_WRITE_FUSE);
		HVSP_LoadDataLowByte(dat[2]);
		HVSP_nWR_NPulse(mode);

		if(dat[3] && HVSP_RDY_Wait())
		{
			AVRP_TxLen = 2;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}

		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_READ_FUSE:
//dat[idx]	para(value)				Description
//dat[1]	address					address of byte to read
		HVSP_RDY_Wait();

		mode = dat[1];
		if(mode == 0)
			mode = HVSP_BS_LowByte;
		else if(mode == 1)
			mode = HVSP_BS_ExtHighByte;
		else if(mode == 2)
			mode = HVSP_BS_ExtLowByte;

		HVSP_LoadCommand(HVCMD_READ_FUSELCK);
		HVSP_EnableReadData(mode);
		dat[2] = HVSP_ReadData(mode);

		AVRP_TxLen = 3;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_PROGRAM_LOCKBIT:
//dat[idx]	para(value)				Description
// same as AVRP_CMD_PROGRAM_FUSE
		if(HVSP_RDY_Wait())
		{
			AVRP_TxLen = 2;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}

		HVSP_LoadCommand(HVCMD_WRITE_LOCK);
		HVSP_LoadDataLowByte(dat[2]);
		HVSP_nWR_NPulse(HVSP_BS_LowByte);

		if(dat[3] && HVSP_RDY_Wait())
		{
			AVRP_TxLen = 2;
			return AVRP_STATUS_RDY_BSY_TOUT;
		}

		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_OK;
		break;
	case AVRP_CMD_READ_LOCKBIT:
//dat[idx]	para(value)				Description
//same as AVRP_CMD_READ_FUSE
		HVSP_RDY_Wait();

		HVSP_LoadCommand(HVCMD_READ_FUSELCK);
		HVSP_EnableReadData(HVSP_BS_HighByte);
		dat[2] = HVSP_ReadData(HVSP_BS_HighByte);

		AVRP_TxLen = 3;
		return AVRP_STATUS_CMD_OK;
	case AVRP_CMD_READ_SIGNATURE:
//dat[idx]	para(value)				Description
//same as AVRP_CMD_READ_FUSE
		HVSP_RDY_Wait();

		HVSP_LoadCommand(HVCMD_READ_SIGCAL);

		HVSP_LoadAddressLowByte(dat[1]);
		HVSP_EnableReadData(HVSP_BS_LowByte);
		dat[2] = HVSP_ReadData(HVSP_BS_LowByte);

		AVRP_TxLen = 3;
		return AVRP_STATUS_CMD_OK;
	case AVRP_CMD_READ_OSCCAL:
//dat[idx]	para(value)				Description
//same as AVRP_CMD_READ_FUSE
		HVSP_RDY_Wait();

		HVSP_LoadCommand(HVCMD_READ_SIGCAL);

		HVSP_LoadAddressLowByte(dat[1]);
		HVSP_EnableReadData(HVSP_BS_HighByte);
		dat[2] = HVSP_ReadData(HVSP_BS_HighByte);

		AVRP_TxLen = 3;
		return AVRP_STATUS_CMD_OK;
		break;
	default:
		AVRP_TxLen = 2;
		return AVRP_STATUS_CMD_UNKNOWN;
		break;
	}
}
#endif		// #if AVRP_HVSP_SHOULD_ENABLE
