AVRminiProg is an integration of my previous-developed AVR programming tools: AVRminiISP, AVRminiJTAG and AVRminiDragon, which emulate official USB-interfaced programmers from Atmel. U can use AVRminiProg in the right same way U use Atmel programmers. Software supports Atmel��s programmer will also support AVRminiProg, and official AVRStudio is recommended.


LICENSE

AVRminiProg is published under GPLv2. see "license.txt".

AVRUSB is a product from http://www.obdev.at/products/avrusb/.


HARDWARE
Schematic and can be found at http://www.SimonQian.com/en/AVRminiProg/.
Default hardware is recommended especially for HV Programming.
U MUST change the corresponding macros in app_cfg.h if non default hardware is used.
Pins(default), see app_cfg for more information:
1 ADC(AD0)			sample target VCC, optional(configure AD_En in app_cfg.h)
1 SPI port(SPI0)	for ISP and JTAG operation, MUST be SPI0
1 Out pin(PD7)		control reset of target mcu for ISP operation
1 Out pin(PD6)		control TMS pin for JTAG operation, needn't if configured as AVRISP mkII(no JTAG operations).
2 Out pins(PD1,PD3)	control 2 LEDs, optional(define corresponding macros to empty)
1 ext int(INT0)		for AVRUSB D+
1 IO pin(PD4)		for AVRUSB D-
1 Out pin(NON)		for AVRUSB usbDeviceConnect(), optional(undefine USB_CFG_PULLUP_IOPORTNAME and USB_CFG_PULLUP_BIT)
If AVRPhenix is 	implemented lator, more ports are needed:
1 Input pin(PD0)	for Prog_Key, optional
pins needed to operate Dataflash


BOOTLOADER
USB-interfaced bootloaders are recommended, see http://www.obdev.at/products/avrusb/prjprog.html.
Homepage of AVRminiProg provides modified versions to support LEDs and support OSC frequency sellection.
If no bootloader is used, an JMP on reset pin of controller to the target reset control pin is recommended, thus U can use other programmer to update firmware.


FIRMWARE
AVRStudio + WINAVR is recommended, other GCC compile for AVR will be also OK(avr-gcc 4.1.2 and avrdude 5.5 is tested).
If avr-gcc is used under Linux, some changes MUST be down:
1.In Makefile line 9, change "avr-gcc.exe" to "avr-gcc". AVRStudio will automatically add ".exe", which is not needed by avr-gcc.
2.In Makefile line 117,change "@avr-size -C --mcu=${MCU} ${TARGET}" to "@avr-size -d AVRminiProg.hex ${TARGET}".Modify app_cfg.h according to your hardware, modify Makefile in the 'defalt' directory for your AVR chip and OSC frequency(if AVRStudio is used, configure in the Project-->Configuration Options), and then just compile it.
Cautions: avrdude 5.5 will clear the unused bits in extend fuse bits, but it is unsafe to program '0' to unused bits.


USE JMPLESS FIRMWARE UPGRADE
This feature is only available when configured as AVRISP mkII. After click the Upgrade button in AVRStudio, AVRminiProg will write 0x00 to address 0xFF in EEPROM. Get more information in AVR_Device_Upgrade function in AVR_Device_Common.c(for example your bootloader can accept a wdt-reset).


FUSES
No Watchdog is used.
Configure the BOD voltage to the value suitable for the voltage you used as power supply.
Caution: If power supply to the target is needed, define BOD voltage a bit lower to avoid reset on BOD by a sudden load change.
Disable JTAG if JTAG pins are used for Non JTAG operation(If JTAG is enabled, you cannot control these pins.).
Configure the Boot Flash Section to the size suitable for the bootloader U use, if no bootloader is used, disable it.
Configure the 'Boot Reset Vector Enabled' option if bootloader need to use interrupt.
'Preserve EEPROM memory through the Chip Erase Cycle' option could be useful if U will update firmware by a way Chip Erase will be launched and want to preserve the configurations made by Software(eg: Programming Speed).
Ext OSC 8.0+ MHz is required by AVRUSB, and 'Device clock by 8 internally' option shouldn't be assigned.


If U have any proglems and suggestion, please mail me: webmaster#SimonQian.com(replace # with @)


VERSION
AVRminiProg RC(2008.03.01)
