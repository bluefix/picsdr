/* Name: JTAG_TAP.h
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2007-12-22 07:46
 */
#define JTAG_TAP_ENTER_IDLE				1

#define JTAG_TAP_Idle()					(JTAG_TAP_TCK_CLR(),JTAG_TAP_TMS_SET(),JTAG_TAP_TDI_SET())


void JTAG_TAP_Enter_DR_Mode(void);
void JTAG_TAP_Enter_IR_Mode(void);
void JTAG_TAP_Enter_Idle_Mode(void);

uint8 JTAG_TAP_ShiftDataInOut_1Byte(uint8 tdi,uint8 len);
void JTAG_TAP_ShiftDataInOut(uint8 *tdi,uint8 *tdo,uint16 len);

void JTAG_TAP_Instr(uint8 instr);
uint8 JTAG_TAP_Data_1Byte(uint8 tdi,uint8 len,uint8 idle);
uint16 JTAG_TAP_Data_2Bytes(uint16 tdi,uint8 len,uint8 idle);
void JTAG_TAP_Data(uint8 *tdi,uint8 *tdo,uint16 len,uint8 idle);
#define JTAG_TAP_DataIn(tdo,len,idle)		JTAG_TAP_Data((uint8*)0,tdo,len,idle)
#define JTAG_TAP_DataOut(tdi,len,idle)		JTAG_TAP_Data(tdi,(uint8*)0,len,idle)

extern uint8 JTAG_Clock;

void JTAG_TAP_Reset();
void JTAG_TAP_Init(void);
void JTAG_TAP_Fini(void);
