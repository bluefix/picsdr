/* Name: JTAG_TAP.c
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2007-12-22 07:46
 */
#include <avr/io.h>

#include "../../type.h"
#include "../../app_cfg.h"

#include "../../MCU/gpio.h"

#include "../../Delay/delay.h"

#include "../ISP/SPI/spi.h"
#include "JTAG_TAP.h"
#include "AVR_JTAG.h"

#if AVRP_JTAG_SHOULD_ENABLE

#define JTAG_TAP_TCKP_DLY()			
#define JTAG_TAP_TCK_DLY()			

uint8 JTAG_Clock = 0;

void JTAG_TAP_ChangeStatus(uint8 tms,uint8 len)
{
	uint8 i,msk;

	for(i = 0;i < len;i++)
	{
		msk = (1 << i);
		if(tms & msk)
			JTAG_TAP_TMS_SET();
		else
			JTAG_TAP_TMS_CLR();

		JTAG_TAP_TCK_SET();
		JTAG_TAP_TCKP_DLY();
		JTAG_TAP_TCK_DLY();
		JTAG_TAP_TCK_CLR();
	}
}

uint8 JTAG_TAP_ShiftDataInOut_1Byte(uint8 tdi,uint8 len)
{
	uint8 msk,tdo = 0;

	msk = 1;
	JTAG_TAP_TMS_CLR();
	while(len)
	{
		if(tdi & msk)
			JTAG_TAP_TDI_SET();
		else
			JTAG_TAP_TDI_CLR();

		if(JTAG_TAP_TDO_GET())
			tdo |= msk;

		if(len == 1)
			JTAG_TAP_TMS_SET();

		JTAG_TAP_TCK_SET();
		JTAG_TAP_TCKP_DLY();
		JTAG_TAP_TCK_DLY();
		JTAG_TAP_TCK_CLR();

		msk <<= 1;
		len--;
	}

	// Enter Update-IR or Update_DR Mode
//	JTAG_TAP_TMS_SET();
	JTAG_TAP_TCK_SET();
	JTAG_TAP_TCKP_DLY();
	JTAG_TAP_TCK_CLR();

	return tdo;
}

void JTAG_TAP_ShiftDataInOut(uint8 *tdi,uint8 *tdo,uint16 len)
{
	uint8 i = 0,tmp,len_remain = len % 8,tdi_tmp;
	uint16 bytes = len / 8;

	JTAG_TAP_TMS_CLR();

	if(!len_remain)
	{
		len_remain = 8;
		bytes--;
	}

	if(bytes)
	{
		SPI_Init();
#if 1
		SPCR = (1 << SPE) | (1 << MSTR) | (1 << DORD);
		SPSR = (1 << SPI2X);
#else
		SPI_SetClk(0);
		SPCR |= (1 << DORD);
#endif

		if(tdi)
			SPI_SetData(tdi[i]);
		else
			SPI_SetData(0);
		bytes--;
		while(bytes)
		{
			SPI_WaitReady();
			if(tdo)
				tdo[i] = SPI_GetData();
			i++;
			if(tdi)
				SPI_SetData(tdi[i]);
			else
				SPI_SetData(0);

			bytes--;
		}
		SPI_WaitReady();
		if(tdo)
			tdo[i] = SPI_GetData();
		i++;
		SPI_Disable();
	}

	if(tdi)
		tdi_tmp = tdi[i];
	else
		tdi_tmp = 0;
	tmp = JTAG_TAP_ShiftDataInOut_1Byte(tdi_tmp,len_remain);
	if(tdo)
		tdo[i] = tmp;
}

void JTAG_TAP_Reset(void)
{
	JTAG_TAP_ChangeStatus(0x1F,6);
}

void JTAG_TAP_Enter_DR_Mode(void)
{
	JTAG_TAP_ChangeStatus(0x01,3);
}

void JTAG_TAP_Enter_IR_Mode(void)
{
	JTAG_TAP_ChangeStatus(0x03,4);
}

void JTAG_TAP_Enter_Idle_Mode(void)
{
#if 1
	JTAG_TAP_ChangeStatus(0x00,1);
#else
	JTAG_TAP_TMS_CLR();
	JTAG_TAP_TCK_SET();
	JTAG_TAP_TCKP_DLY();
	JTAG_TAP_TCK_CLR();
#endif
//	JTAG_TAP_Idle();
}

void JTAG_TAP_Instr(uint8 instr)
{
	JTAG_TAP_Enter_IR_Mode();

	JTAG_TAP_ShiftDataInOut_1Byte(instr,JTAG_INS_Len);
}

void JTAG_TAP_Data(uint8 *tdi,uint8 *tdo,uint16 len,uint8 idle)
{
	JTAG_TAP_Enter_DR_Mode();

	JTAG_TAP_ShiftDataInOut(tdi,tdo,len);

	if(idle)
		JTAG_TAP_Enter_Idle_Mode();
}

uint8 JTAG_TAP_Data_1Byte(uint8 tdi,uint8 len,uint8 idle)
{
	uint8 tdo;

	JTAG_TAP_Enter_DR_Mode();
	tdo = JTAG_TAP_ShiftDataInOut_1Byte(tdi,len);

	if(idle)
		JTAG_TAP_Enter_Idle_Mode();

	return tdo;
}

uint16 JTAG_TAP_Data_2Bytes(uint16 tdi,uint8 len,uint8 idle)
{
	uint16 tdo;

	JTAG_TAP_Enter_DR_Mode();

	// Data Out
	JTAG_TAP_ShiftDataInOut((uint8*)&tdi,(uint8*)&tdo,len);

	if(idle)
		JTAG_TAP_Enter_Idle_Mode();

	return tdo;
}

void JTAG_TAP_Init(void)
{
/*
	JTAG_TAP_TMS_SETGPIO();
	JTAG_TAP_TCK_SETGPIO();
	JTAG_TAP_TDI_SETGPIO();
	JTAG_TAP_TDO_SETGPIO();
	JTAG_TAP_TRST_SETGPIO();
*/
	JTAG_TAP_TMS_SET();
	JTAG_TAP_TMS_SETOUTPUT();

	JTAG_TAP_TCK_CLR();
	JTAG_TAP_TCK_SETOUTPUT();

	JTAG_TAP_TDI_SET();
	JTAG_TAP_TDI_SETOUTPUT();

	JTAG_TAP_TDO_SETINPUT();
/*
	JTAG_TAP_TRST_SET();
	JTAG_TAP_TRST_SETOUTPUT();
*/
}

void JTAG_TAP_Fini(void)
{
	JTAG_TAP_TMS_SETINPUT();
	JTAG_TAP_TCK_SETINPUT();
	JTAG_TAP_TDI_SETINPUT();
	JTAG_TAP_TDO_SETINPUT();
//	JTAG_TAP_TRST_SETINPUT();
}
#endif		// #if AVRP_JTAG_SHOULD_ENABLE
