/* Name: AVR_JTAG.h
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2007-12-22 07:46
 */
// Instructions:
#define JTAG_INS_Len							4
// Public Instructions:
#define JTAG_INS_EXTEST							0x00
#define JTAG_INS_IDCODE							0x01
#define JTAG_INS_SAMPLE_PRELOAD					0x02
#define JTAG_INS_BYPASS							0x0F
// AVR Specified Public Instructions:
#define JTAG_INS_AVR_RESET						0x0C
#define JTAG_INS_PROG_ENABLE					0x04
#define JTAG_INS_PROG_COMMANDS					0x05
#define JTAG_INS_PROG_PAGELOAD					0x06
#define JTAG_INS_PROG_PAGEREAD					0x07
// AVR specified Private Instructions:
#define JTAG_INS_DBG_FORCE_BRK					0x08
#define JTAG_INS_DBG_RUN						0x09
// IR 4	,0x0A
// DR 16,instr_1
// ......
// DR 16,instr_n
#define JTAG_INS_DBG_INSTR						0x0A
// Read/Write internal Addres Space
// IR 4	,0x0B
// DR 5	,0 + ins_addr	// if write, omit
// DR 16,addr
// DR 5,RW + ins_addr
// 
// Read OCDR
// IR 4	,0x0B
// DR 5	,0x0C
// DR 16,0
#define JTAG_INS_DBG_OCD						0x0B

// AVR Debug Registers
#define AVR_JTAG_OCDREG_PSB0					0
#define AVR_JTAG_OCDREG_PSB1					1
#define AVR_JTAG_OCDREG_PDMSB					2
#define AVR_JTAG_OCDREG_PDSB					3
#define AVR_JTAG_OCDREG_BCR						8  /* break control register  */
#define AVR_JTAG_OCDREG_BSR						9  /* break control and status register */
#define AVR_JTAG_OCDREG_COMM_DATA				12 /* communication data OCDR register */
#define AVR_JTAG_OCDREG_COMM_CTL				13 /* control and status of OCDR register */

#define AVR_JTAG_OCDREG_HIGHBYTE				8
// BCR bits in high byte of break control register
#define AVR_JTAG_BCR_COMP_MSK					(1 << (9 - AVR_JTAG_OCDREG_HIGHBYTE))
#define AVR_JTAG_BCR_PDMSB_SINGLE_BRK			(1 << (10 - AVR_JTAG_OCDREG_HIGHBYTE))
#define AVR_JTAG_BCR_EN_PSB0					(1 << (11 - AVR_JTAG_OCDREG_HIGHBYTE))
#define AVR_JTAG_BCR_EN_PSB1					(1 << (12 - AVR_JTAG_OCDREG_HIGHBYTE))
#define AVR_JTAG_BCR_BRK_ON_FLOW				(1 << (13 - AVR_JTAG_OCDREG_HIGHBYTE))
#define AVR_JTAG_BCR_RD_PC						(1 << (14 - AVR_JTAG_OCDREG_HIGHBYTE))
#define AVR_JTAG_BCR_TMR_RUN_ON_BRK				(1 << (15 - AVR_JTAG_OCDREG_HIGHBYTE))
// BSR bits
#define AVR_JTAG_BSR_BRK_INSTR					(1 << 0)
#define AVR_JTAG_BSR_FORCED						(1 << 1)
#define AVR_JTAG_BSR_STAT						(1 << 2)
#define AVR_JTAG_BSR_PDSB						(1 << 3)
#define AVR_JTAG_BSR_PDMSB						(1 << 4)
#define AVR_JTAG_BSR_PSB0						(1 << 5)
#define AVR_JTAG_BSR_PSB1						(1 << 6)
#define AVR_JTAG_BSR_FLOW						(1 << 7)
// Control and status bits
#define AVR_JTAG_CTL_SET_OCDR					(1 << 2)
#define AVR_JTAG_CTL_RES_1						(1 << 3)
#define AVR_JTAG_CTL_EN_OCDR					(1 << (15 - AVR_JTAG_OCDREG_HIGHBYTE))

#define AVR_JTAG_WR_OCDR						(1 << 4)


// Data Registers:
#define JTAG_REG_Bypass_Len						1
#define JTAG_REG_DeviceID_Len					32

#define JTAG_REG_Reset_Len						1
#define JTAG_REG_JTAGID_Len						32
#define JTAG_REG_ProgrammingEnable_Len			16
#define JTAG_REG_ProgrammingCommand_Len			15
#define JTAG_REG_FlashDataByte_Len				16


// JTAG Programming Instructions:
#define JTAG_PROG_OPERATIONCOMPLETE				0x0200
#define JTAG_PROG_INS(d)						AVR_JTAG_SendDat(d,JTAG_REG_ProgrammingCommand_Len)
#define JTAG_PROG_LoadAddrExtendedHighByte(c)	JTAG_PROG_INS(0xB00 | ((c) & 0xFF))
#define JTAG_PROG_LoadAddrHighByte(a)			JTAG_PROG_INS(0x0700 | ((a) & 0xFF))
#define JTAG_PROG_LoadAddrLowByte(b)			JTAG_PROG_INS(0x0300 | ((b) & 0xFF))
#define JTAG_PROG_LoadAddrByte(b)				JTAG_PROG_LoadAddrLowByte(b)
#define JTAG_PROG_LoadDataLowByte(i)			JTAG_PROG_INS(0x1300 | ((i) & 0xFF))
#define JTAG_PROG_LoadDataHighByte(i)			JTAG_PROG_INS(0x1700 | ((i) & 0xFF))
#define JTAG_PROG_LoadDataByte(i)				JTAG_PROG_LoadDataLowByte(i)
#define JTAG_PROG_LatchData()					(JTAG_PROG_INS(0x3700),JTAG_PROG_INS(0x7700),JTAG_PROG_INS(0x3700))
// Chip Erase
#define JTAG_PROG_ChipErase()					(JTAG_PROG_INS(0x2380),JTAG_PROG_INS(0x3180),JTAG_PROG_INS(0x3380),JTAG_PROG_INS(0x3380))
#define JTAG_PROG_ChipEraseComplete()			(JTAG_PROG_INS(0x3380) & JTAG_PROG_OPERATIONCOMPLETE)

// Write Flash
#define JTAG_PROG_EnterFlashWrite()				JTAG_PROG_INS(0x2310)
#define JTAG_PROG_WriteFlashPage()				(JTAG_PROG_INS(0x3700),JTAG_PROG_INS(0x3500),JTAG_PROG_INS(0x3700),JTAG_PROG_INS(0x3700))
#define JTAG_PROG_WriteFlashPageComplete()		(JTAG_PROG_INS(0x3700) & JTAG_PROG_OPERATIONCOMPLETE)

// Read Flash
#define JTAG_PROG_EnterFlashRead()				JTAG_PROG_INS(0x2302)

// Write EEPROM
#define JTAG_PROG_EnterEEPROMWrite()			JTAG_PROG_INS(0x2311)
#define JTAG_PROG_WriteEEPROMPage()				(JTAG_PROG_INS(0x3300),JTAG_PROG_INS(0x3100),JTAG_PROG_INS(0x3300),JTAG_PROG_INS(0x3300))
#define JTAG_PROG_WriteEEPROMPageComplete()		(JTAG_PROG_INS(0x3300) & JTAG_PROG_OPERATIONCOMPLETE)

// Read EEPROM
#define JTAG_PROG_EnterEEPROMRead()				JTAG_PROG_INS(0x2303)

// Write Fuses
#define JTAG_PROG_EnterFuseWrite()				JTAG_PROG_INS(0x2340)
#define JTAG_PROG_WriteFuseExtByte()			(JTAG_PROG_INS(0x3B00),JTAG_PROG_INS(0x3900),JTAG_PROG_INS(0x3B00),JTAG_PROG_INS(0x3B00))
#define JTAG_PROG_WriteFuseExtByteComplete()	(JTAG_PROG_INS(0x3700) & JTAG_PROG_OPERATIONCOMPLETE)
#define JTAG_PROG_WriteFuseHighByte()			(JTAG_PROG_INS(0x3700),JTAG_PROG_INS(0x3500),JTAG_PROG_INS(0x3700),JTAG_PROG_INS(0x3700))
#define JTAG_PROG_WriteFuseHighByteComplete()	(JTAG_PROG_INS(0x3700) & JTAG_PROG_OPERATIONCOMPLETE)
#define JTAG_PROG_WriteFuseLowByte()			(JTAG_PROG_INS(0x3300),JTAG_PROG_INS(0x3100),JTAG_PROG_INS(0x3300),JTAG_PROG_INS(0x3300))
#define JTAG_PROG_WriteFuseLowByteComplete()	(JTAG_PROG_INS(0x3300) & JTAG_PROG_OPERATIONCOMPLETE)

// Write Lockbits
#define JTAG_PROG_EnterLockbitWrite()			JTAG_PROG_INS(0x2320)
#define JTAG_PROG_WriteLockbit()				(JTAG_PROG_INS(0x3300),JTAG_PROG_INS(0x3100),JTAG_PROG_INS(0x3300),JTAG_PROG_INS(0x3300))
#define JTAG_PROG_WriteLockbitComplete()		(JTAG_PROG_INS(0x3300) & JTAG_PROG_OPERATIONCOMPLETE)

// Read Fuses/Lockbits
#define JTAG_PROG_EnterFuseLockbitRead()		JTAG_PROG_INS(0x2304)
#define JTAG_PROG_ReadExtFuseByte()				(JTAG_PROG_INS(0x3A00),JTAG_PROG_INS(0x3B00))
#define JTAG_PROG_ReadFuseHighByte()			(JTAG_PROG_INS(0x3E00),JTAG_PROG_INS(0x3F00))
#define JTAG_PROG_ReadFuseLowByte()				(JTAG_PROG_INS(0x3200),JTAG_PROG_INS(0x3300))
#define JTAG_PROG_ReadLockbit()					(JTAG_PROG_INS(0x3600),JTAG_PROG_INS(0x3700))

// Read Signature
#define JTAG_PROG_EnterSignByteRead()			JTAG_PROG_INS(0x2308)
#define JTAG_PROG_ReadSignByte()				(JTAG_PROG_INS(0x3200),JTAG_PROG_INS(0x3300))

// Read Calibration Byte
#define JTAG_PROG_EnterCaliByteRead()			JTAG_PROG_INS(0x2308)
#define JTAG_PROG_ReadCaliByte()				(JTAG_PROG_INS(0x3600),JTAG_PROG_INS(0x3700))

// No Operation Command
#define JTAG_PROG_LoadNoOperationCommand()		(JTAG_PROG_INS(0x2300),JTAG_PROG_INS(0x3300))








#define AVR_JTAG_SendIns(ins)					JTAG_TAP_Instr((uint8)(ins))
#define AVR_JTAG_SendDat(dat,len)				JTAG_TAP_Data_2Bytes((uint16)(dat),(len),JTAG_TAP_ENTER_IDLE)

void AVR_JTAG_Init(void);
