/* Name: HVPP.c
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2007-12-22 07:46
 */
#include <avr/io.h>

#include "../../../type.h"
#include "../../../app_cfg.h"

#include "../../../MCU/gpio.h"

#include "../../../Delay/delay.h"

#include "../HV.h"
#include "HVPP.h"


#if AVRP_HVPP_SHOULD_ENABLE

extern uint8 hvControlStack[32];

void HVPP_ChangeMode(uint8 mode)
{
	HVPP_CTRL_Out(mode);
}

uint8 HVPP_WriteData(uint8 mode,uint8 data)
{
	HVPP_ChangeMode(mode);

	HVPP_DATA_SetOutput();
	HVPP_DATA_Out(data);

#ifdef HVPP_SignalDelay_InUS
	DelayUS(HVPP_SignalDelay_InUS);
#endif

	HVPP_XTAL1_PPulse();

#ifdef HVPP_SignalDelay_InUS
	DelayUS(HVPP_SignalDelay_InUS);
#endif

	return HVPP_Success;
}

void HVPP_Init(void)
{
	HV_Init();

//	HVPP_DATA_SetInput();
	HVPP_XTAL1_Clr();
	HVPP_XTAL1_SetOutput();
	HVPP_CTRL_Out(hvControlStack[0]);
	HVPP_CTRL_SetOutput();
}

void HVPP_Fini(void)
{
	HV_Fini();

	HVPP_DATA_SetInput();
	HVPP_CTRL_SetInput();
	HVPP_XTAL1_SetInput();
	HVPP_DATA_Out(0);
	HVPP_CTRL_Out(0);
	HVPP_XTAL1_Clr();
}

uint8 HVPP_RDY_Wait(void)
{
	uint16 dly = 0xFFFF;

	while(!HVPP_RDY_Get() && (--dly > 0));

	if(dly)
		return HVPP_Success;
	else
		return HVPP_Error;
}

#endif		// #if AVRP_HVPP_SHOULD_ENABLE
