/* Name: HVPP.h
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2007-12-22 07:46
 */
#define HVPP_CONN(a,b)							a ## b

#define HVPP_DIRPort(name)						HVPP_CONN(DDR,name)
#define HVPP_PINPort(name)						HVPP_CONN(PIN,name)
#define HVPP_PORTPort(name)						HVPP_CONN(PORT,name)

#define HVPP_CTRL_DIR							HVPP_DIRPort(HVPP_CTRL_PORT_NAME)
#define HVPP_CTRL_PIN							HVPP_PINPort(HVPP_CTRL_PORT_NAME)
#define HVPP_CTRL_PORT							HVPP_PORTPort(HVPP_CTRL_PORT_NAME)

#define HVPP_DATA_DIR							HVPP_DIRPort(HVPP_DATA_PORT_NAME)
#define HVPP_DATA_PIN							HVPP_PINPort(HVPP_DATA_PORT_NAME)
#define HVPP_DATA_PORT							HVPP_PORTPort(HVPP_DATA_PORT_NAME)

#define HVPP_DATA_SetOutput()					(HVPP_DATA_DIR = 0xFF)
#define HVPP_DATA_SetInput()					(HVPP_DATA_DIR = 0)
#define HVPP_DATA_Out(d)						(HVPP_DATA_PORT = (d))
#define HVPP_DATA_In()							(HVPP_DATA_PIN)

#define HVPP_CTRL_SetOutput()					(HVPP_CTRL_DIR = HVPP_CTRL_GetSig(HVPP_CTRLIDX_PAGEL,HVPP_BS_HighByte))
#define HVPP_CTRL_SetInput()					(HVPP_CTRL_DIR = 0)
#define HVPP_CTRL_Out(d)						(HVPP_CTRL_PORT = (d))

// Format of hvControlStack
// Mega48:		0x0E,0x1E,0x0F,0x1F,0x2E,0x3E,0x2F,0x3F,0x4E,0x5E,0x4F,0x5F,0x6E,0x7E,0x6F,0x7F,0x66,0x76,0x67,0x77,0x6A,0x7A,0x6B,0x7B,0xBE,0xFD,0x00,0x01,0x00,0x00,0x00,0x00
// Opt(Offset):	LoadAddr(0)        ,LoadData(4)        ,LoadCommand(8)     ,LoadNone(12)       ,nWR(16)            ,nOE(20)            ,PAGEL(24),    ,Pin Of RDY(27)
// BS:			L   ,H   ,ExtL,ExtH,L   ,H   ,ExtL,ExtH,L   ,H   ,ExtL,ExtH,L   ,H   ,ExtL,ExtH,L   ,H   ,ExtL,ExtH,L   ,H   ,ExtL,ExtH,L   ,H   ,
// HVPP ByteStatus
#define HVPP_BS_LowByte							0
#define HVPP_BS_HighByte						1
#define HVPP_BS_ExtLowByte						2
#define HVPP_BS_ExtHighByte						3

// HVPP operation
#define HVPP_CTRLIDX_LoadAddr					0
#define HVPP_CTRLIDX_LoadData					4
#define HVPP_CTRLIDX_LoadCommand				8
#define HVPP_CTRLIDX_LoadNone					12
#define HVPP_CTRLIDX_nWR						16
#define HVPP_CTRLIDX_nOE						20
#define HVPP_CTRLIDX_PAGEL						24
#define HVPP_CTRLIDX_PinOfRDY					27

#define HVPP_CTRL_GetSig(op,bs)					hvControlStack[(op) + (bs)]

#define HVPP_GetMode()							(HVPP_CTRL_PIN)

#define HVPP_RDY_Get()							(HVPP_GetMode() & (1 << HVPP_CTRL_GetSig(HVPP_CTRLIDX_PinOfRDY,0)))
uint8 HVPP_RDY_Wait(void);

void HVPP_ChangeMode(uint8 mode);

uint8 HVPP_WriteData(uint8 mode,uint8 data);

#define HVPP_LoadCommand(cmd)					HVPP_WriteData(HVPP_CTRL_GetSig(HVPP_CTRLIDX_LoadCommand,HVPP_BS_LowByte),(cmd))

#define HVPP_LoadData(bs,data)					HVPP_WriteData(HVPP_CTRL_GetSig(HVPP_CTRLIDX_LoadData,(bs)),(data))
#define HVPP_LoadDataLowByte(data)				HVPP_LoadData(HVPP_BS_LowByte,(data))
#define HVPP_LoadDataHighByte(data)				HVPP_LoadData(HVPP_BS_HighByte,(data))
#define HVPP_LoadDataExtendedLowByte(data)		HVPP_LoadData(HVPP_BS_ExtLowByte,(data))
#define HVPP_LoadDataExtendedHighByte(data)		HVPP_LoadData(HVPP_BS_ExtHighByte,(data))

#define HVPP_WriteDataLowByte()					HVPP_nWR_NPulse(HVPP_BS_LowByte,0)
#define HVPP_WriteDataHighByte()				HVPP_nWR_NPulse(HVPP_BS_HighByte,0)
#define HVPP_WriteDataExtendedLowByte()			HVPP_nWR_NPulse(HVPP_BS_ExtLowByte,0)
#define HVPP_WriteDataExtendedHighByte()		HVPP_nWR_NPulse(HVPP_BS_ExtHighByte,0)

#define HVPP_LoadAddress(bs,addr)				HVPP_WriteData(HVPP_CTRL_GetSig(HVPP_CTRLIDX_LoadAddr,(bs)),(addr))
#define HVPP_LoadAddressLowByte(addr)			HVPP_LoadAddress(HVPP_BS_LowByte,(addr))
#define HVPP_LoadAddressHighByte(addr)			HVPP_LoadAddress(HVPP_BS_HighByte,(addr))
#define HVPP_LoadAddressExtendedLowByte(addr)	HVPP_LoadAddress(HVPP_BS_ExtLowByte,(addr))
#define HVPP_LoadAddressExtendedHighByte(addr)	HVPP_LoadAddress(HVPP_BS_ExtHighByte,(addr))

#define HVPP_nWR_NPulse(bs,dly)					(HVPP_ChangeMode(HVPP_CTRL_GetSig(HVPP_CTRLIDX_nWR,(bs)))/*,DelayMS(dly)*/,HVPP_ChangeMode(HVPP_CTRL_GetSig(HVPP_CTRLIDX_LoadNone,(bs))))
#ifdef HVPP_SignalDelay_InUS
#define HVPP_XTAL1_PPulse()						(HVPP_XTAL1_Set(),DelayUS(HVPP_SignalDelay_InUS),HVPP_XTAL1_Clr())
#else
#define HVPP_XTAL1_PPulse()						(HVPP_XTAL1_Set(),HVPP_XTAL1_Clr())
#endif
#define HVPP_LatchFlashData()					(HVPP_ChangeMode(HVPP_CTRL_GetSig(HVPP_CTRLIDX_PAGEL,HVPP_BS_HighByte)),HVPP_ChangeMode(HVPP_CTRL_GetSig(HVPP_CTRLIDX_LoadNone,HVPP_BS_HighByte)))
#define HVPP_LatchEEPROMData()					(HVPP_ChangeMode(HVPP_CTRL_GetSig(HVPP_CTRLIDX_PAGEL,HVPP_BS_LowByte)),HVPP_ChangeMode(HVPP_CTRL_GetSig(HVPP_CTRLIDX_LoadNone,HVPP_BS_LowByte)))

#define HVPP_EnableReadData(bs)					(HVPP_DATA_SetInput(),HVPP_ReadDataChangeByte(bs))
#define HVPP_ReadDataChangeByte(bs)				HVPP_ChangeMode(HVPP_CTRL_GetSig(HVPP_CTRLIDX_nOE,(bs)))
#define HVPP_DisableReadData(bs)				HVPP_ChangeMode(HVPP_CTRL_GetSig(HVPP_CTRLIDX_LoadNone,(bs)))
#ifdef HVPP_SignalDelay_InUS
#define HVPP_ReadData()							(DelayUS(HVPP_SignalDelay_InUS),HVPP_DATA_In())
#else
#define HVPP_ReadData()							(HVPP_DATA_In())
#endif


void HVPP_Init(void);
void HVPP_Fini(void);

#define HVPP_Error						1
#define HVPP_Success					0
