/* Name: HV.c
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2008-02-04
 */
#include <avr/io.h>

#include "../../type.h"
#include "../../app_cfg.h"

#include "../../MCU/gpio.h"

#if HV_12V_EN && (AVRP_HVPP_SHOULD_ENABLE || AVRP_HVSP_SHOULD_ENABLE)
#include "../../MCU/adc.h"

extern volatile uint8 Boost_Stable;
#endif

#if AVRP_HVPP_SHOULD_ENABLE || AVRP_HVSP_SHOULD_ENABLE
void HV_Init(void)
{
	uint16 WaitStableCnt = 0;

	HV_TargetVCC_Init();
	HV_TargetReset_Init();

	HV_Boost_Init();

#if HV_12V_EN
#if HV_Test_TVCC_12V
LED_On(LED_Red);
#endif
	// Boost circuit MUST be tested by enable HV_Test_TVCC_12V, or program will be blocked here
	while(!Boost_Stable && --WaitStableCnt);
#if HV_Test_TVCC_12V
LED_On(LED_Green);
#endif
#endif
}

void HV_Fini(void)
{
	HV_Boost_Fini();

	HV_TargetVCC_Fini();
	HV_TargetReset_Fini();
}
#endif		// #if AVRP_HVPP_SHOULD_ENABLE || AVRP_HVSP_SHOULD_ENABLE
