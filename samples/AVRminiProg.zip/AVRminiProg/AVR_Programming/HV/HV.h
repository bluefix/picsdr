/* Name: HV.h
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2008-1-20 02:37
 */
// Thanks to AVRDoper from http://www.obdev.at/products/avrusb/avrdoper.html.
// Some codes are copied from that project.

/* control lines for high voltage serial (and parallel) programming */
// 7(I)    6(O)    5(O)    4(O) |  3(O)    2(O)    1(O)    0(O)
// RDY(PP) XA1     XA0     BS1  |  /WR     /OE     BS2     PAGEL
#define HVCTL_PAGEL 			(1 << 0)
#define HVCTL_BS2   			(1 << 1)
#define HVCTL_nOE   			(1 << 2)
#define HVCTL_nWR   			(1 << 3)
#define HVCTL_BS1   			(1 << 4)
#define HVCTL_XA0   			(1 << 5)
#define HVCTL_XA1   			(1 << 6)

/* actions: */
#define HVACT_ADDR				0
#define HVACT_DATA				HVCTL_XA0
#define HVACT_CMD				HVCTL_XA1
#define HVACT_NONE				(HVCTL_XA1 | HVCTL_XA0)
#define HVACT_PAGEL				(HVCTL_XA1 | HVCTL_XA0 | HVCTL_PAGEL)

/* bs: */
#define HVBS_LOW				0
#define HVBS_HIGH				HVCTL_BS1
#define HVBS_EXTLOW				HVCTL_BS2
#define HVBS_EXTHIGH			(HVCTL_BS1 | HVCTL_BS2)

/* modes: */
#define HVRW_WRITE				HVCTL_nOE		// nOE high,nWR low
#define HVRW_READ				HVCTL_nWR		// nWR high,nOE low
#define HVRW_NORW				(HVCTL_nWR | HVCTL_nOE)

#define HVCTL(action,bs,mode)	((action) | (bs) | (mode))

#define HVCTL_LoadAddr(bs)		HVCTL(HVACT_ADDR,(bs),HVRW_NORW)
#define HVCTL_LoadData(bs)		HVCTL(HVACT_DATA,(bs),HVRW_NORW)
#define HVCTL_LoadCommand(bs)	HVCTL(HVACT_CMD,(bs),HVRW_NORW)
#define HVCTL_nWR_Clr(bs)		HVCTL(HVACT_NONE,(bs),HVRW_WRITE)
#define HVCTL_nOE_Clr(bs)		HVCTL(HVACT_NONE,(bs),HVRW_READ)
#define HVCTL_PAGEL_Set(bs)		HVCTL(HVACT_PAGEL,(bs),HVRW_NORW)
#define HVCTL_None(bs)			HVCTL(HVACT_NONE,(bs),HVRW_NORW)

/* high voltage parallel and serial programming commands */
#define HVCMD_CHIP_ERASE		0x80
#define HVCMD_WRITE_FUSE		0x40
#define HVCMD_WRITE_LOCK		0x20
#define HVCMD_WRITE_FLASH		0x10
#define HVCMD_WRITE_EEPROM		0x11
#define HVCMD_READ_SIGCAL		0x08
#define HVCMD_READ_FUSELCK		0x04
#define HVCMD_READ_FLASH		0x02
#define HVCMD_READ_EEPROM		0x03
#define HVCMD_NOP				0x00

void HV_Init(void);
void HV_Fini(void);
