/* Name: HVSP.h
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2008-1-24 01:50
 */
#define HVSP_RDY_Get()							HVSP_SDO_Get()

#define HVSP_BS_LowByte							HVBS_LOW
#define HVSP_BS_HighByte						HVBS_HIGH
#define HVSP_BS_ExtLowByte						HVBS_EXTLOW
#define HVSP_BS_ExtHighByte						HVBS_EXTHIGH

// Last byte in hvControlStack indicates whether to alter ProgEnable Pins
#define HVSP_AltProgEnablePin_En()				hvControlStack[31]

uint8 HVSP_Comm(uint8 sii,uint8 sdi);
#define HVSP_ChangeMode(mode)					HVSP_Comm((mode),0)

#define HVSP_LoadCommand(cmd)					HVSP_Comm(HVCTL_LoadCommand(HVSP_BS_LowByte),(cmd))

#define HVSP_LoadData(bs,data)					HVSP_Comm(HVCTL_LoadData(bs),(data))
#define HVSP_LoadDataLowByte(data)				HVSP_LoadData(HVSP_BS_LowByte,(data))
#define HVSP_LoadDataHighByte(data)				HVSP_LoadData(HVSP_BS_HighByte,(data))
#define HVSP_LoadDataExtendedLowByte(data)		HVSP_LoadData(HVSP_BS_ExtLowByte,(data))
#define HVSP_LoadDataExtendedHighByte(data)		HVSP_LoadData(HVSP_BS_ExtHighByte,(data))

#define HVSP_WriteDataLowByte()					HVSP_nWR_NPulse(HVSP_BS_LowByte)
#define HVSP_WriteDataHighByte()				HVSP_nWR_NPulse(HVSP_BS_HighByte)
#define HVSP_WriteDataExtendedLowByte()			HVSP_nWR_NPulse(HVSP_BS_ExtLowByte)
#define HVSP_WriteDataExtendedHighByte()		HVSP_nWR_NPulse(HVSP_BS_ExtHighByte)

#define HVSP_LoadAddress(bs,addr)				HVSP_Comm(HVCTL_LoadAddr(bs),(addr))
#define HVSP_LoadAddressLowByte(addr)			HVSP_LoadAddress(HVSP_BS_LowByte,(addr))
#define HVSP_LoadAddressHighByte(addr)			HVSP_LoadAddress(HVSP_BS_HighByte,(addr))
#define HVSP_LoadAddressExtendedLowByte(addr)	HVSP_LoadAddress(HVSP_BS_ExtLowByte,(addr))
#define HVSP_LoadAddressExtendedHighByte(addr)	HVSP_LoadAddress(HVSP_BS_ExtHighByte,(addr))

#define HVSP_nWR_NPulse(bs)						(HVSP_ChangeMode(HVCTL_nWR_Clr(bs)),HVSP_ChangeMode(HVCTL_None(bs)))
#define HVSP_LatchFlashData()					(HVSP_ChangeMode(HVCTL_PAGEL_Set(HVSP_BS_HighByte)),HVSP_ChangeMode(HVCTL_None(HVSP_BS_HighByte)))
#define HVSP_LatchEEPROMData()					(HVSP_ChangeMode(HVCTL_PAGEL_Set(HVSP_BS_LowByte)),HVSP_ChangeMode(HVCTL_None(HVSP_BS_LowByte)))

#define HVSP_EnableReadData(bs)					HVSP_ReadDataChangeByte(bs)
#define HVSP_ReadDataChangeByte(bs)				HVSP_ChangeMode(HVCTL_nOE_Clr(bs))
#define HVSP_ReadData(bs)						HVSP_Comm(HVCTL_None(bs),0)


uint8 HVSP_RDY_Wait(void);
void HVSP_Init(void);
void HVSP_Fini(void);

#define HVSP_Error						1
#define HVSP_Success					0
