/* Name: HVSP.h
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2007-12-30 13:51
 */
#include <avr/io.h>

#include "../../../type.h"
#include "../../../app_cfg.h"

#include "../../../MCU/gpio.h"

#include "../../../Delay/delay.h"

#include "../HV.h"
#include "HVSP.h"

#if AVRP_HVSP_SHOULD_ENABLE

uint8 HVSP_Comm(uint8 sii,uint8 sdi)
{
	uint8 i,sdo;

	HVSP_SII_Clr();
	HVSP_SDI_Clr();
	HVSP_SCI_Set();
	sdo = 0;
	HVSP_SCI_Clr();

	for(i = 0;i < 8;i++)
	{
		sdo <<= 1;
		if(HVSP_SDO_Get())
			sdo |= 1;

		if(sii & 0x80)
			HVSP_SII_Set();
		else
			HVSP_SII_Clr();
		if(sdi & 0x80)
			HVSP_SDI_Set();
		else
			HVSP_SDI_Clr();

		HVSP_SCI_Set();
		sdi <<= 1;
		sii <<= 1;
		HVSP_SCI_Clr();
	}

	HVSP_SII_Clr();
	HVSP_SDI_Clr();

	HVSP_SCI_Set();
	HVSP_SCI_Clr();
	HVSP_SCI_Set();
	HVSP_SCI_Clr();

	return sdo;
}

uint8 HVSP_RDY_Wait(void)
{
	uint16 dly = 0xFFFF;

	while(!HVSP_RDY_Get() && (--dly > 0));

	if(dly)
		return HVSP_Success;
	else
		return HVSP_Error;
}

void HVSP_Init(void)
{
	HV_Init();

	HVSP_SCI_Clr();
	HVSP_SCI_SetOutput();
	HVSP_SDI_SetOutput();
	HVSP_SII_SetOutput();
}

void HVSP_Fini(void)
{
	HV_Fini();

	HVSP_SDO_SetInput();
	HVSP_SDI_SetInput();
	HVSP_SII_SetInput();
	HVSP_SCI_SetInput();
}

#endif		// #if AVRP_HVSP_SHOULD_ENABLE
