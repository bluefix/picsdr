/* Name: ISP.c
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2007-11-18 04:53
 */
#include <avr/io.h>

#include "../../type.h"
#include "../../app_cfg.h"

#include "../../MCU/gpio.h"

#include "SPI/spi.h"
#include "ISP.h"

#if AVRP_ISP_SHOULD_ENABLE

#if ISP_AutoSpeed_En
uint8 ISP_Speed[10] = {0,1,2,3,4,5,6,0x3E,0x95,0xA3};
#endif

uint8 ISP_RDY_Wait()
{
	uint8 dly = 50,cmd[4] = {0xF0,0x00,0x00,0x00},ret[4];

poll:
	ISP_Comm((uint8*)cmd,(uint8*)ret);		// poll RDY/BSY
	if((ret[3] & 1) && (--dly > 0))
		goto poll;

	if(dly)
		return ISP_Success;
	else
		return ISP_Error;
}

void ISP_Comm(uint8 *data,uint8 *ret)
{
	uint8 tmp;

	if(SPI_Emu)
	{
		for(tmp = 0;tmp < 4;tmp++)
		{
			ret[tmp] = SPI_RW_Emu(data[tmp]);
		}
	}
	else
	{
		tmp = 0;
		SPI_SetData(data[tmp]);
		for(;tmp < 3;tmp++)
		{
			ret[tmp] = SPI_RW_HW(data[tmp + 1]);
		}
		SPI_WaitReady();
		ret[tmp] = SPI_GetData();
	}
}

void ISP_Init(void)
{
	ISP_SetRSTOutput();
	SPI_Init();
}

void ISP_Fini(void)
{
	SPI_Disable();
	SPI_SetSCKInput();
	SPI_SetMOSIInput();
	SPI_SetMISOInput();
	ISP_SetRSTInput();
}
#endif		// #if AVRP_ISP_SHOULD_ENABLE
