/* Name: SPI.h
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2007-11-10 5:11
 */
// Only Support Master Mode

#define SPI_DATA_LEN			8
#define SPI_MSB					(1 << (SPI_DATA_LEN - 1))

void SPI_Init(void);


#define SPI_Disable()			SPCR = 0
#define SPI_IsReady()			(SPSR & (1 << SPIF))
#define SPI_SetData(d)			SPDR = d
#define SPI_GetData()			SPDR
#define SPI_WaitReady()			while (!SPI_IsReady())

uint8 SPI_RW_Emu(uint8 data);
uint8 SPI_RW_HW(uint8 data);
void SPI_SetClk(uint8 ps);
uint8 SPI_RW(uint8 data);

extern uint8 SPI_Emu;
