/* Name: SPI.c
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2007-11-10 5:11
 */
#include <avr/io.h>

#include "../../../type.h"
#include "../../../app_cfg.h"

#include "../../../MCU/gpio.h"

#include "../../../Delay/delay.h"

#include "spi.h"

#if AVRP_ISP_SHOULD_ENABLE || AVRP_JTAG_SHOULD_ENABLE

#if AVRP_ISP_SHOULD_ENABLE
uint8 SPI_Emu = 0;
uint8 SPI_Dly;

void SPI_Delay(uint8 dly)
{
	if(dly > 0)
		dly++;
	while(dly--)DelayUS(30);
}

void SPI_SetClk(uint8 ps)
{
	if(ps > 5)
	{
		SPI_Emu = 1;
		SPI_Dly = (ps >> 4);
		SPI_Disable();
	}
	else
	{
		SPI_Emu = 0;
		SPCR = (1 << SPE) | (1 << MSTR);

		if(ps & 1)
			SPSR = 0;
		else
			SPSR = (1 << SPI2X);
		SPCR &= ~((1 << SPR0) | (1 << SPR1));
		SPCR |= (ps >> 1) + 1;
	}
}


uint8 SPI_RW_Emu(uint8 data)
{
	uint8 tmp,ret = 0;

	for(tmp = SPI_DATA_LEN;tmp;tmp--)
	{
		if(data & SPI_MSB)
			SPI_SetMOSI();
		else
			SPI_ClrMOSI();
		data <<= 1;

		SPI_Delay(SPI_Dly);

		SPI_SetSCK();

		SPI_Delay(SPI_Dly);

		ret <<= 1;
		if(SPI_GetMISO())
			ret |= 1;

		SPI_Delay(SPI_Dly);

		SPI_ClrSCK();

		SPI_Delay(SPI_Dly);
	}
	return ret;
}

uint8 SPI_RW_HW(uint8 data)
{
	uint8 ret;

	SPI_WaitReady();

	ret =  SPI_GetData();

	SPI_SetData(data);

	return ret;
}

uint8 SPI_RW(uint8 data)
{
	uint8 ret;

	if(SPI_Emu)
	{
		ret = SPI_RW_Emu(data);
	}
	else
	{
		SPI_SetData(data);

		SPI_WaitReady();

		ret = SPI_GetData();
	}

	return ret;
}
#endif		// #if AVRP_ISP_SHOULD_ENABLE

void SPI_Init(void)
{
#ifdef SPI_SS_Init
	SPI_SS_Init();
#endif

	SPI_ClrSCK();

	SPI_SetSCKOutput();
	SPI_SetMOSIOutput();
	SPI_SetMISOInput();
}
#endif		// #if AVRP_ISP_SHOULD_ENABLE || AVRP_JTAG_SHOULD_ENABLE
