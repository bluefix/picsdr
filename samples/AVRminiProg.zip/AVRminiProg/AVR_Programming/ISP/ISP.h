/* Name: ISP.h
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2007-11-16 23:41
 */
// ISP Interfaces:
// MOSI		<-->	O	defined in spi module
// MISO		<-->	I	defined in spi module
// SCK		<-->	O	defined in spi module
// RST		<-->	O

#define ISP_RST_Off()									if(Reset_Polarity)ISP_SetRST();else ISP_ClrRST()
#define ISP_RST_On()									if(Reset_Polarity)ISP_ClrRST();else ISP_SetRST()


void ISP_Init(void);
void ISP_Fini(void);
void ISP_Comm(uint8*,uint8*);

#define ISP_Error					1
#define ISP_Success					0

#if ISP_AutoSpeed_En
extern uint8 ISP_Speed[10];
#define ISP_AutoSpeed_Max			7
#define ISP_AutoSpeed_CheckTimes_H	1
#define ISP_AutoSpeed_CheckTimes_L	1
#endif

uint8 ISP_RDY_Wait(void);
