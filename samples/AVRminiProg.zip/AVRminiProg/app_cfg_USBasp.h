/* Name: app_cfg_USBasp.h
 * Project: AVRminiProg
 * Author: Simon Qian
 * License: See License.txt
 * Last Update: 2007-12-22 07:46
 */

/******************************** AVRminiProgUSBasp ********************************/
//  AVRminiProgUSBasp is compatible with USBasp in hardware. For AVRminiProg need more
//code, so Mega48 can NOT be used. If JTAG programming is needed, use Mega168.

#ifndef APP_CFG_INCLUDED

#define APP_CFG_INCLUDED

#define AVR_DEVICE					(AVR_DEVICE_AVRISP_MKII | 0)

// if AVR_DEVICE_AVRISP_MKII is sellected, only ISP could be enabled, others will be ignored
// if AVR_DEVICE_JTAGICE_MKII is sellected, HV Programming will be ignored
#define AVR_PROG_ISP_EN				1
#define AVR_PROG_JTAG_EN			1
#define AVR_PROG_HVPP_EN			0			// NOT supported by USBasp
#define AVR_PROG_HVSP_EN			0			// NOT supported by USBasp

#define AVR_DBG_JTAG_EN				0			// NOT implemented, don't use
#define AVR_DBG_DW_EN				0			// NOT implemented, don't use

/*************************** ADC *****************************/
// devices like USBasp has no AD connected to target VCC,just define AD_En to 0
#define AD_En						1

// VREF can be ADC_VREF_AVCC or ADC_VREF_BANDGAP
#define AD_VCC_MUX					(ADC_VREF_BANDGAP | ADC_CHANNEL_ADC3)
#define ADVref						11			// in 100mA,so 11 means 1.1V
#define AD_VCC_RATE					6			// see below, equals to (R1 + R2) / R2
// target VCC ------ R1 ------ ADC
//                           |
//        GND ------ R2 ------
// 
// for Reference Voltage (AVCC will change according to different current load, BANDGAP will not):
// if AVCC is used, resistor1 = resistor2 = 10K					AD_VCC_RATE should be 2
// if BANDGAP is used, resistor1 = 10K, resistor2 = 2K			AD_VCC_RATE should be 6
// I use AVCC as reference, and resistor1 = 10K, resistor2 = 2K	AD_VCC_RATE is 6
// Of cource other values are also acceptable, just use different R1 and R2

/*************************** LED *****************************/
#define LED_Green					P(1)		// indicates connected to PC
#define LED_Red						P(0)		// indicates target VCC

#define LED_Init()					do{PortC_SetPin(LED_Green | LED_Red);PortC_SetOutput(LED_Green | LED_Red);}while(0)
#define LED_On(led)					PortC_ClrPin(led)
#define LED_Off(led)				PortC_SetPin(led)
#define LED_IsOn(led)				!PortC_GetPin(led)


/*************************** JTAG *****************************/
#define JTAG_TAP_TMS				P(2)
// MUST be SPI0 as ISP interface,so that one adaptor is enough for both ISP and JTAG.
#define JTAG_TAP_TCK				P(5)		// MUST be the same PIN as SPI_SCK
#define JTAG_TAP_TDI				P(3)		// MUST be the same PIN as SPI_MOSI
#define JTAG_TAP_TDO				P(4)		// MUST be the same PIN as SPI_MISO

#define JTAG_TAP_TMS_SETOUTPUT()	PortB_SetOutput(JTAG_TAP_TMS)
#define JTAG_TAP_TMS_SETINPUT()		PortB_SetInput(JTAG_TAP_TMS)
#define JTAG_TAP_TMS_SET()			PortB_SetPin(JTAG_TAP_TMS)
#define JTAG_TAP_TMS_CLR()			PortB_ClrPin(JTAG_TAP_TMS)

#define JTAG_TAP_TCK_SETOUTPUT()	PortB_SetOutput(JTAG_TAP_TCK)
#define JTAG_TAP_TCK_SETINPUT()		PortB_SetInput(JTAG_TAP_TCK)
#define JTAG_TAP_TCK_SET()			PortB_SetPin(JTAG_TAP_TCK)
#define JTAG_TAP_TCK_CLR()			PortB_ClrPin(JTAG_TAP_TCK)

#define JTAG_TAP_TDI_SETOUTPUT()	PortB_SetOutput(JTAG_TAP_TDI)
#define JTAG_TAP_TDI_SETINPUT()		PortB_SetInput(JTAG_TAP_TDI)
#define JTAG_TAP_TDI_SET()			PortB_SetPin(JTAG_TAP_TDI)
#define JTAG_TAP_TDI_CLR()			PortB_ClrPin(JTAG_TAP_TDI)

#define JTAG_TAP_TDO_SETINPUT()		PortB_SetInput(JTAG_TAP_TDO)
#define JTAG_TAP_TDO_GET()			PortB_GetPin(JTAG_TAP_TDO)
#define JTAG_TAP_TDO_SET()			PortB_SetPin(JTAG_TAP_TDO)
#define JTAG_TAP_TDO_CLR()			PortB_ClrPin(JTAG_TAP_TDO)

/*************************** ISP *****************************/
// if error occurs during programming with AutoSpeed set,
// just set ISP speed in AVRSutdio and AVRminiProg will disable AutoSpeed
// If U don't like it, change ISP_AutoSpeed_En to 0
// If used, an 12M or 15M osc is recommended
// There is some other configurations in ISP.h file. If problems occur, define this to 0
#define ISP_AutoSpeed_En			1

// SPI Port for ISP(SPI0 Must be used)
#define SPI_MISO					P(4)
#define SPI_MOSI					P(3)
#define SPI_SCK						P(5)
#define SPI_SS						P(2)

// in Master SPI mode,if SS is input, SS MUST be held high to ensure master SPI operation
// so configure SS to output or input with pullup, just sellect one below
// undefine both if SS pin is used as RESET control like USBasp
// SPI_SS is strongly recommended as ISP_RST and JTAG_TAP_TMS, and undefine both
//#define SPI_SS_Init()				do{PortB_SetPin(SPI_SS);PortB_SetInput(SPI_SS);}while(0)
//#define SPI_SS_Init()				PortB_SetOutput(SPI_SS)

#define SPI_SetMOSIOutput()			PortB_SetOutput(SPI_MOSI)
#define SPI_SetMOSIInput()			PortB_SetInput(SPI_MOSI)
#define SPI_SetMOSI()				PortB_SetPin(SPI_MOSI)
#define SPI_ClrMOSI()				PortB_ClrPin(SPI_MOSI)

#define SPI_SetMISOInput()			PortB_SetInput(SPI_MISO)
#define SPI_GetMISO()				PortB_GetPin(SPI_MISO)

#define SPI_SetSCKOutput()			PortB_SetOutput(SPI_SCK)
#define SPI_SetSCKInput()			PortB_SetInput(SPI_SCK)
#define SPI_SetSCK()				PortB_SetPin(SPI_SCK)
#define SPI_ClrSCK()				PortB_ClrPin(SPI_SCK)

#define ISP_RST						P(2)
#define ISP_SetRST()				PortB_SetPin(ISP_RST)
#define ISP_ClrRST()				PortB_ClrPin(ISP_RST)
#define ISP_SetRSTOutput()			PortB_SetOutput(ISP_RST)
#define ISP_SetRSTInput()			PortB_SetInput(ISP_RST)

/*************************** VHPP *****************************/

/*************************** HVSP *****************************/


/*************************** AVRUSB *****************************/
/* ---------------------------- Hardware Config ---------------------------- */

#define USB_CFG_IOPORTNAME      B
/* This is the port where the USB bus is connected. When you configure it to
 * "B", the registers PORTB, PINB and DDRB will be used.
 */
#define USB_CFG_DMINUS_BIT      0
/* This is the bit number in USB_CFG_IOPORT where the USB D- line is connected.
 * This may be any bit in the port.
 */
#define USB_CFG_DPLUS_BIT       1
/* This is the bit number in USB_CFG_IOPORT where the USB D+ line is connected.
 * This may be any bit in the port. Please note that D+ must also be connected
 * to interrupt pin INT0!
 */
#define USB_CFG_CLOCK_KHZ       (F_CPU/1000)
/* Clock rate of the AVR in MHz. Legal values are 12000, 15000, 16000 or 16500.
 * The 16.5 MHz version of the code requires no crystal, it tolerates +/- 1%
 * deviation from the nominal frequency. All other rates require a precision
 * of 2000 ppm and thus a crystal!
 * Default if not specified: 12 MHz
 */
/* ----------------------- Optional Hardware Config ------------------------ */

/* #define USB_CFG_PULLUP_IOPORTNAME   D */
/* If you connect the 1.5k pullup resistor from D- to a port pin instead of
 * V+, you can connect and disconnect the device from firmware by calling
 * the macros usbDeviceConnect() and usbDeviceDisconnect() (see usbdrv.h).
 * This constant defines the port on which the pullup resistor is connected.
 */
/* #define USB_CFG_PULLUP_BIT          4 */
/* This constant defines the bit number in USB_CFG_PULLUP_IOPORT (defined
 * above) where the 1.5k pullup resistor is connected. See description
 * above for details.
 */

/*************************** KEY *****************************/
#define PROGKEY_Pin					(1 << 0)
#define PROGKEY_Init()				do{PortD_SetPin(PROGKEY_Pin);PortD_SetInput(PROGKEY_Pin);}while(0)
#define PROGKEY_IsDown()			!PortD_GetPin(PROGKEY_Pin)

/*************************** Dataflash *****************************/

#endif		// #ifndef APP_CFG_INCLUDED
