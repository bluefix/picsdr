#include "types.h"
#include "eeprom_map.h"
#include "utilities.h"
#include "global_data.h"

#ifndef COMPILING_FIRMWARE
   #include "test.h"
#endif

#ifdef COMPILING_FIRMWARE

     #include <p18cxxx.h>

#pragma code APPLICATION

#endif

#pragma udata PIN_REGISTERS_SECTION 

far pin_register_t pin_update_registers[NUMBER_OF_PHYSICAL_PINS + 1];


#pragma udata access ACCESS_RAM_FIXED 
near uint8 txbuffer[TXBUFFER_LENGTH];
near uint8 rxbuffer[RXBUFFER_LENGTH];
near pin_register_t tp;
near pin_register2_t tp2;
near uint8 virtual_pin;
near uint8 current_physical_pin;

#pragma udata
