#include "types.h"
#include "utilities.h"
#include "global_data.h"
#ifndef COMPILING_FIRMWARE
   #include "test.h"
#endif

#pragma code APPLICATION
#pragma romdata APPLICATION_DATA
//TODO Not tested
void lcd107_setdata(uint8 a) {  
	uint8 local_j;
        local_j = a;
        local_j >>=4;
	vpin_high();
	set_pin(tp.lcd_107.D4pin,(local_j & 0x01)) ; 
	local_j >>=1; 
	set_pin(tp.lcd_107.D5pin,(local_j &0x01) );
	local_j >>=1; 
        set_pin(tp.lcd_107.D6pin,(local_j & 0x01)) ; 
	local_j >>=1; 
	set_pin(tp.lcd_107.D7pin,(local_j & 0x01) );
	vpin_low();

	local_j = a;
	vpin_high();
	set_pin(tp.lcd_107.D4pin,(local_j & 0x01)) ; 
	local_j >>=1; 
	set_pin(tp.lcd_107.D5pin,(local_j &0x01) );
	local_j >>=1; 
        set_pin(tp.lcd_107.D6pin,(local_j & 0x01)) ; 
	local_j >>=1; 
	set_pin(tp.lcd_107.D7pin,(local_j & 0x01) );
	vpin_low();
}

static void clock_data(uint8 data);
static void clock_cmd(uint8 data) ;

#define LCD107_MODE_STRING 0
#define LCD107_MODE_STRING2 1
void init_lcd_107(void)
{
	if (rxbuffer[0] == CONFIGURE_CHANNEL_MODE_0)
	{
		tp.lcd_107.state = 254;
		tp.lcd_107.RSpin = map_pin(rxbuffer[3]);
		set_mode(tp.lcd_107.RSpin, PIN_MODE_CONTROLLED);
		tp.lcd_107.D4pin = map_pin(rxbuffer[4]);
		set_mode(tp.lcd_107.D4pin, PIN_MODE_CONTROLLED);
		tp.lcd_107.D5pin = map_pin(rxbuffer[5]);
		set_mode(tp.lcd_107.D5pin, PIN_MODE_CONTROLLED);
		tp.lcd_107.D6pin = map_pin(rxbuffer[6]);
		set_mode(tp.lcd_107.D6pin, PIN_MODE_CONTROLLED);
		tp.lcd_107.D7pin = map_pin(rxbuffer[7]);
		set_mode(tp.lcd_107.D7pin, PIN_MODE_CONTROLLED);
	}
	if (rxbuffer[0] == CONFIGURE_CHANNEL_MODE_1)
	{
		tp.lcd_107.state = 254;

	}
	else if (rxbuffer[0] == CONFIGURE_CHANNEL_MODE_2)
	{
		tp.generic.buffer= RXBUFFER16(3);
		get_tp2(tp.lcd_107.RSpin);
		tp2.lcd_107.length = rxbuffer[5];
		tp2.lcd_107.delay = RXBUFFER16(6);
		tp2.generic.buffer = 0;
		tp2.lcd_107.offset = 0;
		tp.lcd_107.mode = LCD107_MODE_STRING;
		put_tp2(tp.lcd_107.RSpin);

				tp.lcd_107.state = 253;
			set_pin(tp.lcd_107.RSpin,HIGH);
			vpin_low();	
	}
	else if (rxbuffer[0] == CONFIGURE_CHANNEL_MODE_3)
	{
			//Set CGRAM location
	        clock_cmd(0x40 | (rxbuffer[3] & 0x3F));
	        clock_data(rxbuffer[4]);
	        clock_data(rxbuffer[5]);
	        clock_data(rxbuffer[6]);
	        clock_data(rxbuffer[7]);
		tp.lcd_107.state = 0;

	}
	else if (rxbuffer[0] == CONFIGURE_CHANNEL_MODE_4)
	{
		get_tp2(tp.lcd_107.RSpin);
		tp2.lcd_107.address2 =  RXBUFFER16(3);
		tp2.lcd_107.length2 = rxbuffer[5];
		tp2.lcd_107.offset = 0;
		tp2.lcd_107.offset2 = 0;
		tp.lcd_107.mode = LCD107_MODE_STRING2;
		put_tp2(tp.lcd_107.RSpin);

				tp.lcd_107.state = 0;
	}
}

void update_lcd_107(void)
{
     uint16 actual_offset;
     switch (tp.lcd_107.state)
     {
	     case 170: 
	              //delay 
		      ++tp.lcd_107.state;
	     break;
	  case 200:
	     set_pin(tp.lcd_107.RSpin,LOW);
	     clock_data(0x1C);
		      ++tp.lcd_107.state;
	  break;
	  case 201:
	     set_pin(tp.lcd_107.RSpin,LOW);
	     clock_data(0x14);
		      ++tp.lcd_107.state;
	  break;
	  case 202:
	     set_pin(tp.lcd_107.RSpin,LOW);
	     clock_data(0x28);
		      ++tp.lcd_107.state;
	  break;
	  case 203:
	     set_pin(tp.lcd_107.RSpin,LOW);
	     clock_data(0x4F);
		      ++tp.lcd_107.state;
	  break;
	  case 204:
	     set_pin(tp.lcd_107.RSpin,LOW);
	     clock_data(0xE0);
		      tp.lcd_107.state = 0 ;
	  break;
     case 253:
                get_tp2(tp.lcd_107.RSpin);
	        clock_cmd(0x20);  // 4 bit interface
    		      DELAY_1MS();
	        clock_cmd(0x28);  // 4bit interface, two lines
    		      DELAY_1MS();
	        clock_cmd(0x0C);  // Display On
    		      DELAY_1MS();
	        clock_cmd(0x06);  // Cursor increment, no shift 
    		      DELAY_1MS();
	        clock_cmd(0x80);  // Display address 0 
    		      DELAY_1MS();
		clock_cmd(0x02); //Cursor home
    		      DELAY_1MS();
                 tp.lcd_107.state = 0;
    break;

		
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    case 10:
    case 11:
    case 12:
    case 13:
    case 14:
    case 15:
    case 16:
    case 17:
    case 18:
    case 19:
    case 20:
    case 21:
    case 22:
    case 23:
    case 24:
    case 25:
    case 26:
    case 27:
    case 28:
    case 29:
    case 30:
    case 31:
    case 32:
    case 33:
    case 34:
    case 35:
    case 36:
    case 37:
    case 38:
    case 39:
    case 40:
    case 41:
    case 42:
    case 43:
    case 44:
    case 45:
    case 46:
    case 47:
                get_tp2(tp.lcd_107.RSpin);
                if (tp.lcd_107.state == 0)
		{
			clock_cmd(0x80);  // Display address 0 
		}
		else if (tp.lcd_107.state == 24)
		{
			clock_cmd(0xC0);
		}
		if (tp.lcd_107.mode == LCD107_MODE_STRING)
		{
			if (tp2.lcd_107.length > 48 )
			{
				if( tp2.generic.buffer >= tp2.lcd_107.delay )
				{
				   ++tp2.lcd_107.offset;
				   if (tp2.lcd_107.offset >= tp2.lcd_107.length )
				   {
					   tp2.lcd_107.offset = 0;
				   }
				   tp2.generic.buffer = 0;
				}
				else 
				{
					++ tp2.generic.buffer;
				}
			}
			else
			{
				tp2.lcd_107.offset = 0;
			}
			actual_offset = tp2.lcd_107.offset + tp.lcd_107.state;
			if (actual_offset >= tp2.lcd_107.length)
			{
				actual_offset -= tp2.lcd_107.length;
			}
			actual_offset += tp.generic.buffer;
			if (tp.lcd_107.state < tp2.lcd_107.length)
			{
			clock_data(get_user_buffer(actual_offset));
			}
			else
			{
				clock_data(' ');
			}
		} else if (tp.lcd_107.mode == LCD107_MODE_STRING2) {
			if( tp2.generic.buffer == (tp2.lcd_107.delay >> 2)  )
			{
			   ++tp2.lcd_107.offset;
			}
			if (tp2.generic.buffer >= (tp2.lcd_107.delay))
			{
			  ++tp2.lcd_107.offset2;
			  tp2.generic.buffer = 0;
			} 
			else 
			{
				++tp2.generic.buffer;
			}
			if (tp.lcd_107.state < 24)
			{
				if (tp2.lcd_107.length > 24 )
				{
					   if (tp2.lcd_107.offset >= tp2.lcd_107.length )
					   {
						   tp2.lcd_107.offset = 0;
					   }
				}
				else
				{
					tp2.lcd_107.offset = 0;
				}
				actual_offset = tp2.lcd_107.offset + tp.lcd_107.state;
				if (actual_offset >= tp2.lcd_107.length)
				{
					actual_offset -= tp2.lcd_107.length;
				}
				actual_offset += tp.generic.buffer;
				if (tp.lcd_107.state  < tp2.lcd_107.length)
				{
				clock_data(get_user_buffer(actual_offset));
				}
				else
				{
					clock_data(' ');
				}
		     }
		     else
		     {
				if (tp2.lcd_107.length2 > 24 )
				{
					   if (tp2.lcd_107.offset2 >= tp2.lcd_107.length2 )
					   {
						   tp2.lcd_107.offset2 = 0;
					   }
				}
				else
				{
					tp2.lcd_107.offset2 = 0;
				}
				actual_offset = tp2.lcd_107.offset2 + tp.lcd_107.state - 24;
				if (actual_offset >= tp2.lcd_107.length2)
				{
					actual_offset -= tp2.lcd_107.length2;
				}
				actual_offset += tp2.lcd_107.address2;
				if (tp.lcd_107.state - 24 < tp2.lcd_107.length2)
				{
				clock_data(get_user_buffer(actual_offset));
				}
				else
				{
					clock_data(' ');
				}
		 
		     }
		}
		++tp.lcd_107.state;
		if (tp.lcd_107.state == 48)
		{
			tp.lcd_107.state = 0;
		}
		put_tp2(tp.lcd_107.RSpin);
	break;
    case 254:
    break;	
    default:
	tp.lcd_107.state ++;
    break;
     }
}

void clock_data(uint8 data)
{
    		set_pin(tp.lcd_107.RSpin,HIGH) ;
		lcd107_setdata(data);
}
void clock_cmd(uint8 data)
{
    		set_pin(tp.lcd_107.RSpin,LOW) ;
		lcd107_setdata(data);
}


#ifndef COMPILING_FIRMWARE
#ifdef TEST_LCD_107

void test_lcd_callback(void)
{
   hd44780_update(0);
   return;
}
int main (void)
{
     
     int i;
    
     virtual_pin = map_pin(1);

     for (i = 0; i < 100 ; ++i)
     {
	user_buffer[i] = (i %('z' - '0')) + '0';
     }

     init_hd44780(0,   //uint8 instance
		  map_pin(1),   // uint8 Epin
		  map_pin(2),   // uint8 RSpin
		  map_pin(3),   // uint8 datapin7
		  map_pin(4),   // uint8 datapin6
		  map_pin(5),   // uint8 datapin5
		  map_pin(6),   // uint8 datapin4 
		  2,   // uint8 lines
		  24,   // uint8 width
		  0,   // uint8 linestart0
		  0x40,   // uint8 linestart1
		  255,   // uint8 linestart2
		  255);   // uint8 linestart3)
    register_update_func( test_lcd_callback);
       
    rxbuffer[0] = CONFIGURE_CHANNEL_MODE_0;
    rxbuffer[1] = 1;
    rxbuffer[2] = PIN_MODE_USER_1;
    rxbuffer[3] = 2;
    rxbuffer[4] = 6 ;
    rxbuffer[5] = 5 ;
    rxbuffer[6] = 4 ;
    rxbuffer[7] = 3 ;
    init_lcd_107();

    rxbuffer[0] = CONFIGURE_CHANNEL_MODE_2;
    rxbuffer[1] = 1;
    rxbuffer[2] = PIN_MODE_USER_1;
    rxbuffer[3] = 0;
    rxbuffer[4] = 0 ;
    rxbuffer[5] = 60 ;
    rxbuffer[6] = 0;
    rxbuffer[7] = 100 ;
    init_lcd_107();

    for (i = 0; i < 1000; ++i)
    {
       update_lcd_107();
       if ((i % 50) == 0)
       {
	  printf ("Time %d:\n",i);
	  print_hd44780(0,1,1);
	  printf ("\n\n");
       }
    }
}
#endif
#endif

