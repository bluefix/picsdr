#!perl -w

use strict;
my $highlimit = 0xE000;
my $lowlimit = 0xC000;
my $base_address = 0;
my $current_address = 0;
my %data;

my $output = shift @ARGV;

open(OUTPUT,">$output");
binmode OUTPUT;
open(EXPORT,">$output.exp");
binmode OUTPUT;
while (<>)
{
   if (/^:02000004(....)..\s*$/	)
   {
	   $base_address = hex($1);
   }
   elsif (/^:..(....)00(.*)..\s*$/)
   {
      my $current_address = $base_address + hex($1);
      my $data = $2; 
      my @data = $data =~ /(..)/g;
      foreach (@data)
      {
	     $data{$current_address++} = hex($_); 
      }
   }
}
foreach (sort {$a<=>$b} (keys (%data)))
{
	if ($_ < $lowlimit or $_ >= $highlimit)
	{
		delete $data{$_};
	}
}

for (my $i = $lowlimit; $i < $highlimit; ++$i)
{
	if (not defined ($data{$i}))
	{
		$data{$i} = 0xFF;
	}
}

my $exportnow = 0;
my $prevchar = '';
foreach (sort {$a<=>$b} (keys (%data)))
{
#	printf ("%4X %2X\n",$_,$data{$_});
       print OUTPUT chr($data{$_});
       if ($exportnow)
       {
	       my $string = sprintf("%2X%2X",$data{$_},$prevchar);
	       $string =~ s/ /0/g;
	       print EXPORT "$string\n";
	       $exportnow = 0;
       }
       else
        {
	       $exportnow = 1;
	       $prevchar = $data{$_};
	}
#       print OUTPUT chr($_ % 256);
}

close OUTPUT;
close EXPORT;
