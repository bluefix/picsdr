#define EEPROM_FIRST_CHECKSUMED_ADDRESS 0x0002  //Used by Boot
#define EEPROM_LAST_CHECKSUMED_ADDRESS 0x01FF   //Used by Boot
#define EEPROM_ADDRESS_STAY_IN_BOOT 0x0002  //Used by Boot
#define EEPROM_ADDRESS_PIN_STAY_IN_BOOT_ENABLE 0x0003 //Used by Boot
#define EEPROM_ADDRESS_CHECKSUM_H 0x0000 //Used by Boot
#define EEPROM_ADDRESS_CHECKSUM_L 0x0001 //Used by Boot
#define EEPROM_ADDRESS_UART_BAUD_RATE_H 0x0004
#define EEPROM_ADDRESS_UART_BAUD_RATE_L 0x0005
#define EEPROM_ADDRESS_RANDOM_SEED_SOURCE 0x0006
#define EEPROM_ADDRESS_POWERUP_COUNT_ENABLE 0x0007
#define EEPROM_ADDRESS_COMMAND_COUNTER 0x01FF
#define EEPROM_ADDRESS_USER_AREA 0x0200
#define EEPROM_ADDRESS_POWERUP_COUNT 1020
#define LAST_EEPROM_ADDRESS 1023
#if defined __18F4620

#define EEPROM_READ(_address) \
   { \
        EEADRH = ((uint8)(((uint16) (_address)) >> 8 )); \
        EEADR  = ((uint8) (_address)); \
        EECON1bits.EEPGD = 0; \
        EECON1bits.RD = 1; \
   }

#endif

        
        
         
