#if (!defined (_TYPES_H_))
#define _TYPES_H_

#ifdef __18CXX

#define uint8 unsigned char
#define uint16 unsigned int 
#define int16 signed int 
#define uint32 unsigned long
#define int32 signed long
#define uint24 unsigned long short
#define int24 signed  long short

#define COMPILING_FIRMWARE

#else

#define uint8 unsigned char
#define int8 signed char
#define uint16 unsigned short 
#define int16 signed short 
#define uint32 unsigned int
#define int32 signed int
#define uint24 unsigned long
#define int24 signed long 

#define near
#define far
#define rom


#endif

#ifdef BIG_ENDIAN
typedef union mixed32_n{
	uint32 u;
	int32 s;
	struct mixed32_uwords_n{ 
		uint16 h;
		uint16 l;
        }uwords;
	struct mixed32_midword_n{ 
		uint8 dummy1 ;
		uint16 u;
		uint8 dummy2;

        }midword;
        struct {
	   uint8 h;
	   uint8 mh;
	   uint8 ml;
	   uint8 l;
	}bytes;
}mixed32_t;

typedef union mixed24_n{
	uint24 u;
	int24 s;
        struct {
#ifndef COMPILING_FIRMWARE
	   uint8 buffer;
#endif
	   uint8 h;
	   uint8 m;
	   uint8 l;
	}bytes;
}mixed24_t;

typedef union mixed16_n{
	uint16 u;
	int16 s;
        struct {
	   uint8 highbyte;
	   uint8 lowbyte;
	}bytes;
}mixed16_t;
#else
typedef union mixed32_n{
	uint32 u;
	int32 s;
	struct mixed32_uwords_n{ 
		uint16 l;
		uint16 h;
        }uwords;
        struct {
           uint24 u;
	   uint8 filler;
	}u24;
	struct mixed32_midword_n{ 
		uint8 dummy1 ;
		uint16 u;
		uint8 dummy2;

        }midword;
        struct {
	   uint8 l;
	   uint8 ml;
	   uint8 mh;
	   uint8 h;
	}bytes;
}mixed32_t;

typedef union mixed24_n{
	uint24 u;
	int24 s;
        struct {
	   uint8 l;
	   uint8 m;
	   uint8 h;
#ifndef COMPILING_FIRMWARE
	   uint8 buffer;
#endif
	}bytes;
}mixed24_t;

typedef union mixed16_n{
	uint16 u;
	int16 s;
        struct {
	   uint8 lowbyte;
	   uint8 highbyte;
	}bytes;
}mixed16_t;
#endif

typedef union _pin_register_t{ 
      uint8 bytes[16];

      struct generic_n {
	     uint8 bytes[8];
             uint16 buffer;
	     uint8 mode;
	     uint8 hw_mode;
	     uint8 duty_cycle;
	     uint8 hw_counter;
	     uint8 hw_support;
	     } generic;
      struct lcd_111_n {
	      uint8 RSpin;
	      uint8 resetpin;
	      uint8 mode;
	      uint8 D0pin;
	      uint8 D1pin;
	      uint8 D2pin;
	      uint8 D3pin;
	      uint8 state;
      }lcd_111;
      struct lcd_107_n {
	      uint8 RSpin;
	      uint8 mode;
	      uint8 D4pin;
	      uint8 D5pin;
	      uint8 D6pin;
	      uint8 D7pin;
	      uint8 state;
      }lcd_107;

} pin_register_t;
           

typedef union _pin_register2_t{

      uint8 bytes[16];

      struct generic2_n {
	     uint8 bytes[8];
             uint16 buffer;
	     uint8 mode;
	     } generic;
      struct lcd_111_n2{
	      uint8 D4pin;
	      uint8 D5pin;
	      uint8 D6pin;
	      uint8 D7pin;
	      uint8 length;
	      uint16 delay;
	      uint8 offset;
      } lcd_111;
      struct lcd_107_n2{
	      uint16 delay;
	      uint16 address2; 
	      uint8 length;
	      uint8 offset;
	      uint8 length2;
	      uint8 offset2;
	      //counter to next scroll in buffer
      } lcd_107;

} pin_register2_t;

typedef struct executive_settings_n{
	uint8 run_foreground:1;
	uint8 in_foreground:1;
	uint8 throughput:1;
	uint8 buffer_dirty:1;
}   executive_settings_t;

typedef struct communication_settings_n{
	uint8 uart_address_received:1;
	uint8 uart_checksum_received:1;
	uint8 uart_use_checksum:1;
	uint8 processrxbetweenpins:1;
}comm_settings_t;

typedef struct queue_flags_bits_n{
        uint8 wasempty:1;
        uint8 wasfull:1;
        uint8 compressing:1;
}queue_flags_bits_t;

typedef union queue_flags_union_n{
         uint8 flagsuint8;
	 queue_flags_bits_t bits;
}queue_flags_t;

typedef	union generic_queue_n{
	struct ram_queue_n{
        uint8 type:4;
        uint8 addressh:4;
        uint8 addressl;
	queue_flags_t flags;
        uint8 pad;
        uint16 queuesize;
        uint16 queuelength; 
        uint16 head;
	uint8 reserved[6];
	} ramq;

	struct flash_queue_n{
        uint8 type:4;
        uint8 addressh:4;
        uint8 addressl;
	queue_flags_t flags;
        uint8 pad;
        uint16 queuesize;
        uint16 flashaddr; 
        uint16 head;
        uint8 reserved[6];
	} flash;

	struct ram_rle_byte_queue_n{
        uint8 type:4;
        uint8 addressh:4;
        uint8 addressl;
	queue_flags_t flags;
	uint8 escapeval;
        uint16 queuesize;
        uint16 queuelength; 
        uint16 head;
	uint16 lastentry;
	uint8 lastval;
	uint8 lastlastval;
	uint8 reserved[2];
	} ram_rle_byte;

	struct ram_rle_word_queue_n{
        uint8 type:4;
        uint8 addressh:4;
        uint8 addressl;
	queue_flags_t flags;
	uint8 escapeval;
        uint16 queuesize;
        uint16 queuelength; 
        uint16 head;
	uint16 lastentry;
	uint16 lastval;
	uint16 lastlastval;
	} ram_rle_word;

	struct ram_string_queue_n{
        uint8 type:4;
        uint8 addressh:4;
        uint8 addressl;
	queue_flags_t flags;
	uint8 direction:1;  // 0 = left (to lower address)
	uint8 use_leading1:1;
	uint8 use_leading2:1;
	uint8 use_trailing1:1;
	uint8 use_trailing2:1;
	uint8 leading_zero:1;
	uint8 leading_space:1;
        uint16 queuesize;
	uint16 head;
	uint8 leading1;
	uint8 leading2;
	uint8 trailing1;
	uint8 trailing2;
	uint8 mode;
	uint8 reserved[5];
	} ram_string;

} queue_header_t;


typedef struct sin_data_n
{
    int16 k;
    int16 data1;
    int16 data2;
} sin_data_t;
#endif
