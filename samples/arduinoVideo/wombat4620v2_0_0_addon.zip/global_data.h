#if ! defined (_GLOBAL_DATA_H_)

#define _GLOBAL_DATA_H_

#ifdef __18CXX
  #include <p18cxxx.h>
  #pragma code APPLICATION
  #pragma romdata APPLICATION_DATA



#else

  #define extern

#endif


#define _GLOBAL_DATA_H_
#define RXBUFFER_LENGTH 8
#define TXBUFFER_LENGTH 8

#define LITTLE_ENDIAN

#if defined (__18F4620)
        #define THROUGHPUT_PIN 6 
        #define FG_FRAMES_PER_SEC 1000
        #define SIZE_OF_USER_BUFFER 512 
	#define NUMBER_ANALOG_INPUTS 13 
	#define NUMBER_OF_PHYSICAL_PINS 40
	#define NUMBER_OF_VIRTUAL_PINS 41
	#define NUM_DATA_PROCESSORS 8
	#define CRYSTAL_SPEED  8000000
        #define PLL_MULTIPLIER 4
//  	#define CRYSTAL_SPEED  10000000
	#define SDO_VIRTUAL_PIN 24
	#define SDI_VIRTUAL_PIN 23
	#define SCK_VIRTUAL_PIN 18
	#define CVREF_VIRTUAL_PIN 2 
        #define CCP1_VIRTUAL_PIN 17
        #define CCP2_VIRTUAL_PIN 16
        #define INT0_VIRTUAL_PIN 33
        #define INT1_VIRTUAL_PIN 34
        #define INT2_VIRTUAL_PIN 35
        #define CLOCK_TIME
        #define EUSART
        #define INTERNAL_OSCILLATOR

        #define T3_TICKS_PER_MS 2000
        #define AUTOBAUD        
#endif

#if defined(__18F458)

	#define FG_FRAMES_PER_SEC 1000
        #define SIZE_OF_USER_BUFFER 128 
	#define CRYSTAL_SPEED  10000000
	#define NUMBER_ANALOG_INPUTS 8 
	#define NUMBER_OF_PHYSICAL_PINS 40
	#define NUMBER_OF_VIRTUAL_PINS 41 
	#define NUM_DATA_PROCESSORS 8
	#define SDO_VIRTUAL_PIN 24
	#define SDI_VIRTUAL_PIN 23
	#define SCK_VIRTUAL_PIN 18
#endif

#ifndef COMPILING_FIRMWARE
        #define THROUGHPUT_PIN 6 
        #define FG_FRAMES_PER_SEC 1000
        #define SIZE_OF_USER_BUFFER 512 
	#define NUMBER_ANALOG_INPUTS 13 
	#define NUMBER_OF_PHYSICAL_PINS 40
	#define NUMBER_OF_VIRTUAL_PINS 41
	#define CRYSTAL_SPEED  8000000
        #define PLL_MULTIPLIER 4
	#define SDO_VIRTUAL_PIN 24
	#define SDI_VIRTUAL_PIN 23
	#define SCK_VIRTUAL_PIN 18
	#define CVREF_VIRTUAL_PIN 2 
        #define CCP1_VIRTUAL_PIN 18
        #define CCP2_VIRTUAL_PIN 17
        #define CLOCK_TIME
        #define EUSART
        #define INTERNAL_OSCILLATOR

        #define T3_TICKS_PER_MS 2000
        #define AUTOBAUD        
#endif


extern near uint8 rxbuffer[RXBUFFER_LENGTH];
extern near uint8 txbuffer[TXBUFFER_LENGTH];
extern near uint8 local_i, local_j, local_k; 
extern near mixed16_t local_temp16_1; 
extern near mixed16_t local_temp16_2;
extern mixed32_t local_temp32_1;
extern mixed32_t local_temp32_2;
extern mixed16_t ADbuffer[NUMBER_ANALOG_INPUTS];
extern far pin_register_t pin_update_registers[NUMBER_OF_PHYSICAL_PINS + 1];

extern near uint8 current_physical_pin;
extern near uint8 virtual_pin;

extern near pin_register_t tp;
extern near pin_register2_t tp2;
extern near uint8 tp2_pin;
extern uint8 user_buffer[SIZE_OF_USER_BUFFER];

extern near uint8 process_pins_physical_pin;

extern far uint8 external_memory_0_pin;
extern far uint8 external_memory_1_pin;
extern far uint16 rxbuffer_overflow;
extern far uint16 queue_address;
extern rom const uint8 user_flash_buffer[1024];
extern far executive_settings_t executive_settings; 
extern far uint32 bg_systime;
extern far mixed32_t random_number;
extern far uint16 clock_partial_seconds;
extern far uint8 clock_seconds;
extern far uint8 clock_minutes;
extern far uint8 clock_hours;
extern far uint16 clock_days;
extern uint32 rx_interrupts;
extern uint32 tx_interrupts;
extern uint32 AD_interrupts;
extern near uint16 vpulse_length;
extern uint8 CCP1_data[8];
extern void (*t1_interrupt_function)(void);
extern void (*ccp1_interrupt_function)(void);

extern mixed16_t INT0_counter;
extern mixed24_t INT0_HighCapture;
extern mixed24_t INT0_LowCapture;
extern mixed24_t INT0_HighCaptureOld;
extern mixed24_t INT0_LowCaptureOld;
extern uint8     INT0_mode;  //0 = High to low, 1 = low to high, 2 = both
extern uint8     INT0_LastEvent ;
extern mixed16_t INT1_counter;
extern mixed24_t INT1_HighCapture;
extern mixed24_t INT1_LowCapture;
extern mixed24_t INT1_HighCaptureOld;
extern mixed24_t INT1_LowCaptureOld;
extern uint8     INT1_mode;  //0 = High to low, 1 = low to high, 2 = both
extern uint8     INT1_LastEvent ;
extern mixed16_t INT2_counter;
extern mixed24_t INT2_HighCapture;
extern mixed24_t INT2_LowCapture;
extern mixed24_t INT2_HighCaptureOld;
extern mixed24_t INT2_LowCaptureOld;
extern uint8     INT2_mode;  //0 = High to low, 1 = low to high, 2 = both
extern uint8     INT2_LastEvent ;
extern mixed16_t CCP1_counter;
extern mixed24_t CCP1_LowCaptureOld;
extern mixed24_t CCP1_HighCaptureOld;
extern mixed24_t CCP1_LowCapture;
extern mixed24_t CCP1_HighCapture;
extern uint8     CCP1_LastEvent;  // 1 = high, 0 = low;
extern mixed16_t CCP2_counter;
extern mixed24_t CCP2_LowCaptureOld;
extern mixed24_t CCP2_HighCaptureOld;
extern mixed24_t CCP2_LowCapture;
extern mixed24_t CCP2_HighCapture;
extern uint8     CCP2_LastEvent;  // 1 = high, 0 = low;
extern far sin_data_t sin_data[3];
extern uint8 uart_rxbuffer_counter;
#ifdef COMPILING_FIRMWARE
#define PIN_MODE_DIRECT      0
#define PIN_MODE_CONTROLLED  1
#define PIN_MODE_4BITOUT     2
#define PIN_MODE_PARALLEL_8  3
#define PIN_MODE_MORSE       4
#define PIN_MODE_HYSTERESIS  5
#define PIN_MODE_AD_DIRECT     6 
#define PIN_MODE_AD_1ST_ORDER  7 
#define PIN_MODE_KEYPAD_SCAN_ROW 8
//#define PIN_MODE_WATCHDOG        9
#define PIN_MODE_DIAGNOSTIC      10
#define PIN_MODE_ROTARY_ENC      11
#define PIN_MODE_DEBOUNCE        12
#define PIN_MODE_COUNTER         13
#define PIN_MODE_PIN_THROUGHPUT  14
#define PIN_MODE_AD_AVERAGE      15
#define PIN_MODE_PULSE     16
#define PIN_MODE_SERVO     17
#define PIN_MODE_PWM_DIRECT       18 
#define PIN_MODE_PWM_FOLLOW_DIRECT    19 
#define PIN_MODE_PWM_QUEUE_FIXED_PERIOD 20 
#define PIN_MODE_PWM_QUEUE_VARIABLE_PERIOD 21 
#define PIN_MODE_PIN_LOGIC 22 
#define PIN_MODE_STEPPER_UN4 23
#define PIN_MODE_SPI_MASTER 25
#define PIN_MODE_HD44780_GENERIC 27
#define PIN_MODE_USER_0            0xF0
#define PIN_MODE_USER_1            0xF1
#define PIN_MODE_USER_2            0xF2
#define PIN_MODE_PING 0xF3 
#define PIN_MODE_USER_4 0xF4 
#else
#define PIN_MODE_DIRECT      0
#define PIN_MODE_CONTROLLED  1
//#define PIN_MODE_4BITOUT     2
//#define PIN_MODE_PARALLEL_8  3
//#define PIN_MODE_MORSE       4
//#define PIN_MODE_HYSTERESIS  5
#define PIN_MODE_AD_DIRECT     6 
//#define PIN_MODE_AD_1ST_ORDER  7 
//#define PIN_MODE_KEYPAD_SCAN_ROW 8
//#define PIN_MODE_WATCHDOG        9
//#define PIN_MODE_DIAGNOSTIC      10
//#define PIN_MODE_ROTARY_ENC      11
//#define PIN_MODE_DEBOUNCE        12
//#define PIN_MODE_COUNTER         13
//#define PIN_MODE_PIN_THROUGHPUT  14
//#define PIN_MODE_AD_AVERAGE      15
//#define PIN_MODE_PULSE     16
//#define PIN_MODE_SERVO     17
#define PIN_MODE_PWM_DIRECT       18 
//#define PIN_MODE_PWM_FOLLOW_DIRECT    19 
//#define PIN_MODE_PWM_QUEUE_FIXED_PERIOD 20 
//#define PIN_MODE_PWM_QUEUE_VARIABLE_PERIOD 21 
//#define PIN_MODE_PIN_LOGIC 22 
//#ifdef TEST_UN4STEP
//#define PIN_MODE_STEPPER_UN4 23
//#endif
//#define PIN_MODE_UART_TX 24
//#define PIN_MODE_SPI_MASTER 25
#define PIN_MODE_HD44780_GENERIC 27
//#define PIN_MODE_USER_0            0xF0
//#define PIN_MODE_USER_1            0xF1
//#define PIN_MODE_USER_2            0xF2
//#define PIN_MODE_PING 0xF3 
//#define PIN_MODE_USER_4 0xF4 
#endif

#define DP_MODE_OFF        0
#define DP_MODE_DERIVATIVE 1
#define DP_MODE_ROTATE_RIGHT 2
#define DP_MODE_PIN_COMPARE 3

#define DATA_STREAMER_MODE_OFF 0
#define DATA_STREAMER_MODE_SEQUENTIAL_LETTERS 1
#define DATA_STREAMER_MODE_CONSTANT_QUEUE 2
#define DATA_STREAMER_MODE_HEX_BUFFER 3


#define BROADCAST_ADDRESS 0xFF

#define QUEUE_UART_RX_ESCAPE 0x1B //(ESCAPE)
#define BUFFER_RANDOM_NUMBER 253
#define BUFFER_ZERO_VALUE 252
#define BUFFER_UART_RX_OVERFLOWS 251
#define BUFFER_CLOCK_SECONDS 250
#define BUFFER_CLOCK_MINUTES 249
#define BUFFER_CLOCK_HOURS 248
#define BUFFER_CLOCK_DAYS 247
#define BUFFER_RX_INTERRUPTS 246
#define BUFFER_TX_INTERRUPTS 245
#define BUFFER_SINE_SUM_3 244
#define BUFFER_SINE_SUM_2 243
#define BUFFER_SINE_3 242
#define BUFFER_SINE_2 241
#define BUFFER_SINE_1 240

#define CONFIGURE_CHANNEL_MODE_0 200
#define CONFIGURE_CHANNEL_MODE_1 201
#define CONFIGURE_CHANNEL_MODE_2 202
#define CONFIGURE_CHANNEL_MODE_3 203
#define CONFIGURE_CHANNEL_MODE_4 204
#define CONFIGURE_CHANNEL_MODE_5 205

#define HW_MODE_INTERNAL 0
#define HW_MODE_MCP4821 9
#define HW_MODE_MCP41XXX 10
#define HW_MODE_DINGO_16 11
#endif
