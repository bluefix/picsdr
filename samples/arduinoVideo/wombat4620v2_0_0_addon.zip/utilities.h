#if (!defined (_utilities_h))
#define _utilities_h

#include "types.h"
#include "global_data.h"
uint8 map_physical_pin_ad(uint8 pin);
uint8 read_pin (uint8 pin);
void set_pin (uint8 pin, uint8 mode);
#define toggle_pin(_a) {set_pin (_a, !read_pin(_a));}
//#define vpin_high() {set_pin(virtual_pin,HIGH);}
void vpin_high(void);
//#define vpin_low() {set_pin(virtual_pin,LOW);}
void vpin_low(void);
//#define vpin_input() {set_pin(virtual_pin,INPUT);}
void vpin_input(void);
void vpin_set(uint8 state);
void pin_high(uint8 pin);
void pin_low(uint8 pin);
void pin_input(uint8 pin);
//#define vpin_set(_a) {set_pin(virtual_pin,_a);}
//#define vpin_read() read_pin(virtual_pin)

void EEPROM_WRITE(uint16 address, uint8 value) ;

#define read_ad(_a) ADbuffer[map_physical_pin_ad(_a)].u


uint16 vread_ad(void);

uint8 vpin_read(void);
uint8 push_byte(uint8 data);
uint8 push_word(uint16 data);
uint8 get_queue_status(void);
uint16 get_queue_size(void);
uint16 get_queue_length(void);
uint16 get_queue_freespace(void);
uint8 get_queue_flags(void) ;
uint8 shift_byte(uint8 *data_byte);
uint8 shift_word(uint16 *data_word);
uint8 read_byte(uint8 *data_byte);
uint8 read_word(uint16 *data_byte);
uint8 ascii_to_val(uint8);
uint8 val_to_ascii(uint8);
void val16_to_hex(mixed16_t val, uint8* string);
uint16 hex_ascii_to_val16(uint8* ptr,uint8 counter);
uint32 hex_ascii_to_val32(uint8* ptr,uint8 counter);
uint16 dec_ascii_to_val16(uint8* ptr,uint8 counter);
uint32 dec_ascii_to_val32(uint8* ptr,uint8 counter);
uint8 initialize_queue(uint16 queue_length);
uint8 initialize_string_queue( uint16 queue_length, uint8 mode, uint8 initial_val, uint8 direction);
void copy_queue_to_user();
void get_queue_from_user();
uint8 get_user_buffer(uint16 offset);
void put_user_buffer(uint16 offset, uint8 data);
void get_user_buffer_block(uint16 offset, uint16 length, uint8* dest);
void put_user_buffer_block(uint16 offset, uint16 length, uint8* source);
void set_pwm(uint8 virtual_pin, uint16 width);
void vset_pwm(uint16 width);
void update_pwm(void);
uint16 get_buffer(uint8);
void put_buffer(uint8,uint16);
void get_pin_registers(void);
void put_pin_registers(void);
void vpulse_high(void);
uint8 slow_SPI00_send(uint8 data,uint8 delay);
void delay_cycles(void);
void delay_cycles16(uint16 cycles);
#define DELAY_CYCLES(_a) {vpulse_length = _a; delay_cycles();}
#define DELAY_1MS() {delay_cycles16(CRYSTAL_SPEED / 1000); }
void put_tp2(uint8 pin);
void get_tp2(uint8 pin);

uint16 random(void);
void random_seed(uint32);
uint16 gen_sin_wave (uint8 wavenum);

#define LOW 0
#define HIGH 1
#define INPUT 2

#define QUEUE_BYTE_STORED         0
#define QUEUE_BAD_ADDR            1
#define QUEUE_FULL                2
#define QUEUE_EMPTY               3
#define QUEUE_CREATED             4
#define QUEUE_PAST_END_OF_MEMORY  5
#define QUEUE_BYTE_SHIFTED        6
#define QUEUE_STATUS_OK           7
#define QUEUE_CORRUPT             8
#define QUEUE_NOT_FULL            9
#define QUEUE_NOT_SUPPORTED      10
#define RAM_QUEUE 0x00
#define FLASH_ARRAY 0x01
#define RAM_RLE_BYTE 0x02
#define RAM_RLE_WORD 0x03
#define RAM_STRING 0x04

#define RAM_STRING_MODE_RAW  0
#define RAM_STRING_MODE_HEX_NOLEAD  1
#define RAM_STRING_MODE_DEC_NOLEAD  2
#define RAM_STRING_MODE_HEX_LEADING_ZERO 3
#define RAM_STRING_MODE_DEC_LEADING_ZERO 4
#define RAM_STRING_MODE_HEX_LEADING_SPACE 5
#define RAM_STRING_MODE_DEC_LEADING_SPACE 6
#define RAM_STRING_DOWN 0
#define RAM_STRING_UP 1
#define HIGH_BYTE_16(a) ( (uint8) ( a >> 8 ) )
#define LOW_BYTE_16(a) ( (uint8)  a )

#define HIGH_BYTE_32(a) ( (uint8) ( a >> 24 ) )
#define MH_BYTE_32(a) ( (uint8) ( (a >> 16) & 0xFF ) )
#define ML_BYTE_32(a) ( (uint8) ( (a >> 8) & 0xFF ) )
#define LOW_BYTE_32(a) ( (uint8)  a )
#define set_register_memory(pin,field,value) {pin_update_registers[pin].field = value;}
#define set_register_memory2(pin,field,value) {((pin_register2_t*)pin_update_registers)[pin].field = value;}
#define get_register_memory(pin,field) pin_update_registers[pin].field 
#define get_register_memory2(pin,field) ((pin_register2_t*)pin_update_registers)[pin].field 
#define set_mode(_a,_b) {pin_update_registers[_a].generic.mode = _b;}
#define get_mode(pin) pin_update_registers[pin].generic.mode 
#define set_hw_mode(_a,_b) {pin_update_registers[_a].generic.hw_mode = _b;}
#define set_hw_option(_a,_b) {pin_update_registers[_a].generic.duty_cycle = _b;}
#define get_hw_option(_a) pin_update_registers[_a].generic.duty_cycle 
#define set_buffer(a,b) {pin_update_registers[a].generic.buffer = b;}

#define ENABLE_CCP1_CAPTURE() { CCP1CON = 0x04; T3CONbits.T3CCP2 = 1; PIR1bits.CCP1IF = 0; PIE1bits.CCP1IE = 1; }
#define DISABLE_CCP1_CAPTURE() {  PIE1bits.CCP1IE = 0; }
#define ENABLE_CCP2_CAPTURE() { CCP2CON = 0x04; T3CONbits.T3CCP2 = 1; PIR2bits.CCP2IF = 0; PIE2bits.CCP2IE = 1; }
#define DISABLE_CCP2_CAPTURE() {  PIE2bits.CCP2IE = 0; }
#define ENABLE_INT0_CAPTURE() { INTCONbits.INT0IF = 0; INTCONbits.INT0IE = 1;  }
#define DISABLE_INT0_CAPTURE() {  INTCONbits.INT0IE = 0; }
#define ENABLE_INT1_CAPTURE() { INTCON3bits.INT1IF = 0; INTCON3bits.INT1IE = 1;  }
#define DISABLE_INT1_CAPTURE() {  INTCON3bits.INT1IE = 0; }
#define ENABLE_INT2_CAPTURE() { INTCON3bits.INT2IF = 0; INTCON3bits.INT2IE = 1;  }
#define DISABLE_INT2_CAPTURE() {  INTCON3bits.INT2IE = 0; }
#define RXBUFFER16(a) ((((uint16)rxbuffer[a]) <<8) + rxbuffer[a + 1])
#define ASSIGN_RXBUFFER16(dest,a)\
{                                \
	((mixed16_t*)&dest)->bytes.highbyte = rxbuffer[a]; \
	((mixed16_t*)&dest)->bytes.lowbyte  = rxbuffer[a+1]; \
}
extern rom const uint8 uint8_bitfield_invert[8] ;
extern rom const uint16 uint16_bitfield[16];
extern rom const uint8 uint8_bitfield[8]; // = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
extern rom const uint8 uint8_bitlowermask[8]; // = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};

extern rom const uint8 map_next_physical_pin[NUMBER_OF_PHYSICAL_PINS + 1];

#define map_pin(_a) ((_a <= NUMBER_OF_PHYSICAL_PINS)?_a:255)
#define unmap_pin(_a) _a

extern void error(void);
#ifdef __C18XX

#define DISABLE_ALL_INTERRUPTS() {INTCONbits.GIEL = 0; INTCONbits.GIEH = 0; }
#define ENABLE_ALL_INTERRUPTS() {INTCONbits.GIEL = 1; INTCONbits.GIEH = 1; }

#else

#define DISABLE_ALL_INTERRUPTS() { }
#define ENABLE_ALL_INTERRUPTS() { }

#endif

#ifdef EUSART
#define SET_BAUD_RATE(_a) { SPBRG = ((CRYSTAL_SPEED  / ((uint32)_a) / 16 * PLL_MULTIPLIER) - 1) & 0x00FF; SPBRGH = ((CRYSTAL_SPEED  / ((uint32)_a)/ 16 * PLL_MULTIPLIER) - 1) >>8; }
#else
#define SET_BAUD_RATE(_a) { SPBRG = (CRYSTAL_SPEED  / ((uint32)_a) / 64  - 1) & 0x00FF; }
#endif

#ifndef COMPILING_FIRMWARE

extern void print_pin(int pin,unsigned char high,unsigned char low);
#endif
#endif
