#include "types.h"
#include "utilities.h"
#include "global_data.h"
#pragma code USERCODE 
#pragma romdata USERDATA

#define setdata(_a) {  set_pin(tp.lcd_111.D0pin,(_a & 0x01) > 0) ; \
	set_pin(tp.lcd_111.D1pin,(_a&0x02) > 0);\
        set_pin(tp.lcd_111.D2pin,(_a & 0x04) > 0) ; \
	set_pin(tp.lcd_111.D3pin,(_a&0x08) > 0);\
        set_pin(tp2.lcd_111.D4pin,(_a & 0x10) > 0) ; \
	set_pin(tp2.lcd_111.D5pin,(_a&0x20) > 0);\
        set_pin(tp2.lcd_111.D6pin,(_a & 0x40) > 0) ; \
	set_pin(tp2.lcd_111.D7pin,(_a&0x80) > 0);\
	}

static void clock_data(uint8 data);

#define LCD111_MODE_STRING 0
#define LCD111_MODE_GRAPH 1
void init_lcd_111(void)
{
	if (rxbuffer[0] == CONFIGURE_CHANNEL_MODE_0)
	{
		tp.lcd_111.state = 254;
		tp.lcd_111.RSpin = map_pin(rxbuffer[3]);
		set_mode(tp.lcd_111.RSpin, PIN_MODE_CONTROLLED);
		tp.lcd_111.resetpin = map_pin(rxbuffer[4]);
		set_mode(tp.lcd_111.resetpin, PIN_MODE_CONTROLLED);
		tp.lcd_111.D0pin = map_pin(rxbuffer[5]);
		set_mode(tp.lcd_111.D0pin, PIN_MODE_CONTROLLED);
		tp.lcd_111.D1pin = map_pin(rxbuffer[6]);
		set_mode(tp.lcd_111.D1pin, PIN_MODE_CONTROLLED);
		tp.lcd_111.D2pin = map_pin(rxbuffer[7]);
		set_mode(tp.lcd_111.D2pin, PIN_MODE_CONTROLLED);
	}
	if (rxbuffer[0] == CONFIGURE_CHANNEL_MODE_1)
	{
		tp.lcd_111.state = 254;

		get_tp2(tp.lcd_111.RSpin);
		tp.lcd_111.D3pin = map_pin(rxbuffer[3]);
		set_mode(tp.lcd_111.D3pin, PIN_MODE_CONTROLLED);
		tp2.lcd_111.D4pin = map_pin(rxbuffer[4]);
		set_mode(tp2.lcd_111.D4pin, PIN_MODE_CONTROLLED);
		tp2.lcd_111.D5pin = map_pin(rxbuffer[5]);
		set_mode(tp2.lcd_111.D5pin, PIN_MODE_CONTROLLED);
		tp2.lcd_111.D6pin = map_pin(rxbuffer[6]);
		set_mode(tp2.lcd_111.D6pin, PIN_MODE_CONTROLLED);
		tp2.lcd_111.D7pin = map_pin(rxbuffer[7]);
		set_mode(tp2.lcd_111.D7pin, PIN_MODE_CONTROLLED);
		put_tp2(tp.lcd_111.RSpin);
	}
	else if (rxbuffer[0] == CONFIGURE_CHANNEL_MODE_2)
	{
		tp.generic.buffer= RXBUFFER16(3);
		get_tp2(tp.lcd_111.RSpin);
		tp2.lcd_111.length = rxbuffer[5];
		tp2.lcd_111.delay = RXBUFFER16(6);
		tp2.generic.buffer = 0;
		tp2.lcd_111.offset = 0;
		tp.lcd_111.mode = LCD111_MODE_STRING;
		put_tp2(tp.lcd_111.RSpin);

			if (tp.lcd_111.resetpin != 255)
			{
				tp.lcd_111.state = 170;
				set_pin(tp.lcd_111.resetpin, LOW);
			}
			else
			{
				tp.lcd_111.state = 253;
			}
			pin_high(tp.lcd_111.RSpin);
			vpin_low();	
	}
	else if (rxbuffer[0] == CONFIGURE_CHANNEL_MODE_3)
	{
			//Set CGRAM location
    		pin_low(tp.lcd_111.RSpin) ;
	        clock_data(0xA0 | (rxbuffer[3] & 0x1F));
    		pin_high(tp.lcd_111.RSpin) ;
    		DELAY_1MS();
	        clock_data(rxbuffer[4]);
    		pin_high(tp.lcd_111.RSpin) ;
    		DELAY_1MS();
	        clock_data(rxbuffer[5]);
    		pin_high(tp.lcd_111.RSpin) ;
    		DELAY_1MS();
	        clock_data(rxbuffer[6]);
    		pin_high(tp.lcd_111.RSpin) ;
    		DELAY_1MS();
	        clock_data(rxbuffer[7]);
		tp.lcd_111.state = 0;

	}
	else if (rxbuffer[0] == CONFIGURE_CHANNEL_MODE_4)
	{
			tp.generic.buffer= map_pin(rxbuffer[3]);
			tp.lcd_111.state = 253;
			pin_high(tp.lcd_111.RSpin);
			tp.lcd_111.mode = LCD111_MODE_GRAPH;
			tp.lcd_111.state = 253;
			vpin_low();	
	}
	else if (rxbuffer[0] == CONFIGURE_CHANNEL_MODE_5)
	{
		//TODO: test and document
		tp.generic.buffer= RXBUFFER16(3);
		get_tp2(tp.lcd_111.RSpin);
		tp2.lcd_111.length = rxbuffer[5];
		tp2.lcd_111.delay = RXBUFFER16(6);
		tp2.generic.buffer = 0;
		tp2.lcd_111.offset = 0;
		tp.lcd_111.mode = LCD111_MODE_STRING;
		put_tp2(tp.lcd_111.RSpin);

	}
}

void update_lcd_111()
{
     uint16 actual_offset;
     uint8 i;

     if (tp.lcd_111.state == 254)
     {
           return;
     }
     get_tp2(tp.lcd_111.RSpin);


     if (tp.lcd_111.state < 24)
     {
		if (tp.lcd_111.mode == LCD111_MODE_STRING)
		{
			if (tp2.lcd_111.length > 24 )
			{
				if( tp2.generic.buffer >= tp2.lcd_111.delay )
				{
				   ++tp2.lcd_111.offset;
				   if (tp2.lcd_111.offset >= tp2.lcd_111.length )
				   {
					   tp2.lcd_111.offset = 0;
				   }
				   tp2.generic.buffer = 0;
				}
				else 
				{
					++ tp2.generic.buffer;
				}
			}
			else
			{
				tp2.lcd_111.offset = 0;
			}
			actual_offset = tp2.lcd_111.offset + tp.lcd_111.state;
			if (actual_offset >= tp2.lcd_111.length)
			{
				actual_offset -= tp2.lcd_111.length;
			}
			actual_offset += tp.generic.buffer;
			pin_high(tp.lcd_111.RSpin) ;
			if (tp.lcd_111.state < tp2.lcd_111.length)
			{
			clock_data(get_user_buffer(actual_offset));
			}
			else
			{
				clock_data(' ');
			}
		}
		else if (tp.lcd_111.mode == LCD111_MODE_GRAPH)
		{
			pin_high(tp.lcd_111.RSpin) ;
                     if ( ( 2730 * ((uint16)tp.lcd_111.state + 1) ) < tp2.lcd_111.delay )
		     {
			    clock_data(3);
		     }
		     else if ( ( (2730 * ((uint16)tp.lcd_111.state + 1)) - 682 ) < tp2.lcd_111.delay )
		     {
			     clock_data(2);
		     }
		     else if ( ( (2730 * ((uint16)tp.lcd_111.state + 1)) - 1365 ) < tp2.lcd_111.delay )
		     {
			     clock_data(1);
		     }
		     else if ( ( (2730 * ((uint16)tp.lcd_111.state + 1)) - 2048 ) < tp2.lcd_111.delay )
		     {
			     clock_data(0);
		     }
		     else
		     {
			     clock_data(' ');
		     }
		}
		++tp.lcd_111.state;
		put_tp2(tp.lcd_111.RSpin);
     }
     else if (tp.lcd_111.state == 24)
     {
	     // Reset to first character
    		pin_low(tp.lcd_111.RSpin) ;
	        clock_data(0xE0 );
		if (tp.lcd_111.mode == LCD111_MODE_GRAPH)
		{
			tp2.lcd_111.delay = get_buffer(tp.generic.buffer);
		        put_tp2(tp.lcd_111.RSpin);
		}
		tp.lcd_111.state = 0;
     }
     else if (tp.lcd_111.state < 170) // 25 to 169
     {
	     // invalid states
	     tp.lcd_111.state = 254;
     }
     else if (tp.lcd_111.state  < 185)  // 170 to 184
     {
	              //delay 
		      ++tp.lcd_111.state;
     }
     else if (tp.lcd_111.state == 185)
     {
         set_pin(tp.lcd_111.resetpin, HIGH);
		      ++tp.lcd_111.state;
     }
     else if (tp.lcd_111.state < 200)
     {
	     //delay
	     ++tp.lcd_111.state;
     }
     else if (tp.lcd_111.state == 200)
     {
	     pin_low(tp.lcd_111.RSpin);
	     clock_data(0x1C);
	      ++tp.lcd_111.state;
     }
     else if (tp.lcd_111.state == 201)
     {
	     pin_low(tp.lcd_111.RSpin);
	     clock_data(0x14);
		      ++tp.lcd_111.state;
     }
     else if (tp.lcd_111.state == 202)
     {
	     pin_low(tp.lcd_111.RSpin);
	     clock_data(0x28);
		      ++tp.lcd_111.state;
     }
     else if (tp.lcd_111.state == 203)
     {
	     pin_low(tp.lcd_111.RSpin);
	     clock_data(0x4F);
	      tp.lcd_111.state = 24; // Ready to display.
	                             // Go to home command state
     }
     else if (tp.lcd_111.state == 253)
     {
     // Initialization for LCD Graph Segments
    		pin_low(tp.lcd_111.RSpin) ;
	        clock_data(0x1C);
	        clock_data(0x14);
	        clock_data(0x28);
	        clock_data(0x4F);
		if (tp.lcd_111.mode == LCD111_MODE_GRAPH)
		{
    		      pin_low(tp.lcd_111.RSpin) ;
		      DELAY_1MS();
	              clock_data(0xA0 );
    		      DELAY_1MS();
    		      pin_high(tp.lcd_111.RSpin) ;
		      DELAY_1MS();
	              for (i = 0; i < 8; ++i)
		      {
			 clock_data(0x10);
    		         DELAY_1MS();
		      }
	              for (i = 0; i < 8; ++i)
		      {
			 clock_data(0x18);
    		         DELAY_1MS();
		      }
	              for (i = 0; i < 8; ++i)
		      {
			 clock_data(0x1E);
    		         DELAY_1MS();
		      }
	              for (i = 0; i < 8; ++i)
		      {
			 clock_data(0x1F);
    		         DELAY_1MS();
		      }
		 }
                 tp.lcd_111.state = 0;
     }
     else if (tp.lcd_111.state == 254)
     {
	     // idle pause
     }
     else
     {
	     tp.lcd_111.state = 254;  //Default go to idle
     }

}

void clock_data(uint8 data)
{
	        vpin_high();
		setdata(data);
                vpin_low(); 
}
