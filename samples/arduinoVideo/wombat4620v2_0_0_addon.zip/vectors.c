#include "types.h"
#include "utilities.h"


#pragma code OUTVECTORS

typedef void (*voidoutuint8in)(uint8 p1);
uint8 read_pin (uint8 pin)
{
     _asm
         CALL 0x0834, 0
     _endasm
}


void set_pin (uint8 pin, uint8 mode)
{
     _asm
         CALL 0x0838, 0
     _endasm
}


void vpin_high (void)
{
     _asm
         GOTO 0x083C
     _endasm
}


void vpin_low (void)
{
     _asm
         GOTO 0x0840
     _endasm
}


void vpin_input (void)
{
     _asm
         GOTO 0x0844
     _endasm
}


void vpin_set (uint8 mode)
{
     _asm
         CALL 0x0848, 0
     _endasm
}


uint16 vread_ad (void)
{
     _asm
         GOTO 0x084C
     _endasm
}


uint8 vpin_read (void)
{
     _asm
         GOTO 0x0850
     _endasm
}


uint8 push_byte (uint8 data)
{
     _asm
         CALL 0x0854, 0
     _endasm
}


uint8 push_word (uint16 data)
{
     _asm
         CALL 0x0858, 0
     _endasm
}


uint8 get_queue_status (void)
{
     _asm
         GOTO 0x085C
     _endasm
}


uint16 get_queue_size (void)
{
     _asm
         GOTO 0x0860
     _endasm
}


uint16 get_queue_length (void)
{
     _asm
         GOTO 0x0864
     _endasm
}


uint16 get_queue_freespace (void)
{
     _asm
         GOTO 0x0868
     _endasm
}


uint8 get_queue_flags (void)
{
     _asm
         GOTO 0x086C
     _endasm
}


uint8 shift_byte (uint8 *data_byte)
{
     _asm
         CALL 0x0870, 0
     _endasm
}


uint8 shift_word (uint16 *data_word)
{
     _asm
         CALL 0x0874, 0
     _endasm
}


uint8 read_byte (uint8 *data_byte)
{
     _asm
         CALL 0x0878, 0
     _endasm
}


uint8 read_word (uint16 *data_word)
{
     _asm
         CALL 0x087C, 0
     _endasm
}


uint8 initialize_queue (uint16 queue_length)
{
     _asm
         CALL 0x0898, 0
     _endasm
}


uint8 initialize_string_queue (uint16 queue_length, uint8 mode, uint8 initial_val, uint8 direction)
{
     _asm
         CALL 0x089C, 0
     _endasm
}


uint8 get_user_buffer (uint16 offset)
{
     _asm
         CALL 0x08A0, 0
     _endasm
}


void put_user_buffer (uint16 offset, uint8 data)
{
     _asm
         CALL 0x08A4, 0
     _endasm
}


void get_user_buffer_block (uint16 offset, uint16 length, uint8* dest)
{
     _asm
         CALL 0x08A8, 0
     _endasm
}


void put_user_buffer_block (uint16 offset, uint16 length, uint8* source)
{
     _asm
         CALL 0x08AC, 0
     _endasm
}


void set_pwm (uint8 pin, uint16 width)
{
     _asm
         CALL 0x08B0, 0
     _endasm
}


void vset_pwm (uint16 width)
{
     _asm
         CALL 0x08B4, 0
     _endasm
}


void update_pwm (void)
{
     _asm
         GOTO 0x08B8
     _endasm
}


uint16 get_buffer (uint8 pin)
{
     _asm
         CALL 0x08BC, 0
     _endasm
}


void put_buffer (uint8 pin, uint16 value)
{
     _asm
         CALL 0x08C0, 0
     _endasm
}


void get_pin_registers (void)
{
     _asm
         GOTO 0x08C4
     _endasm
}


void put_pin_registers (void)
{
     _asm
         GOTO 0x08C8
     _endasm
}

void delay_cycles16(uint16 cycles)
{
	_asm
		CALL 0x8D0, 0
	_endasm
}



void error_handler (uint16 error)
{
     _asm
         CALL 0x08D4, 0
     _endasm
}


void pin_low (uint8 pin)
{
     _asm
         CALL 0x08D8, 0
     _endasm
}

void pin_high (uint8 pin)
{
     _asm
         CALL 0x08DC, 0
     _endasm
}

void pin_input (uint8 pin)
{
     _asm
         CALL 0x08E0, 0
     _endasm
}

void put_tp2 (uint8 pin)
{
    
      ((voidoutuint8in)0x08E4)(pin);
}
void get_tp2 (uint8 pin)
{
     _asm
         CALL 0x08E8, 0
     _endasm
}
	

