#!perl -w

use strict;
my $count =  0;
my $limit = shift;

binmode STDOUT;

while ($count < $limit)
{
     print chr($count % 256);
     ++$count;
}
