#include "types.h"
#include "utilities.h"
#include "global_data.h"
#pragma code USERCODE
#pragma romdata USERDATA


void init_user_code (void)
{
        if (rxbuffer[0] == CONFIGURE_CHANNEL_MODE_0)
        {
		//Do something here in response to a 200 command

	}
	else if (rxbuffer[0] == CONFIGURE_CHANNEL_MODE_1)
        {
		//Do something else here in response to a 201 command
        }        
}

void update_user_code()
{ 
	//This function is called periodically, after the first time
	//an init function for the pin is called

	if (vpin_read())
	{
		vpin_low();
	}
	else
	{
		vpin_high();
	}
}

