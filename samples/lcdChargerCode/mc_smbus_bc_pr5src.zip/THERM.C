
///////////////////////////////////////////////////////////////////////////////////
// 	Measures cell temperature of the battery connected to the charger.
//  Operation:
//  	Turns-on pull-up to the termistor
//		mesaures thermistor value times times
//		averages measured values, processed A/D value appers in "val"   
//		sets thermistor flags in ChargerStatus_H byte.
//
//		By Laszlo Kiraly @ Kad Electronics, Sunnyvale CA, Email:KiralyL@aol.com  
//  	330 Ohms-> 	22, 	470 Ohms->31, 	3.3k ->128, 	10.5k->193, 
//		33k		->	232,	50.5k	->240  	97.4k->247 		open-> 255
// ------------------------------------------------------------------------------
void ad_th( void)
{
	ADCON1 = 0x04;
	//
	if(CHARGE_B) 						// if charger is connected to battery B bias (3.32k) th2 line
	{
		TH2_PU = 1;						// turn-on pullup for thermistor 2, use AN1 analog input:
		ADCON0 =  0x41;					// ADCS1 ADCS0 CHS2 CHS1  CHS0 GO U ADON  --> OSC/8 CH1, ADON 
	}
	else
 	{
		TH1_PU = 1;						// turn-on pullup for thermistor 1, use AN0 analog input:
		ADCON0 = 0x49;					// ADCS1 ADCS0 CHS2 CHS1  CHS0 GO U ADON, -->  OSC/8 CH0, ADON
 	}
	//
	delay_us(10);						// wait for settling
  	ad_val = 0x0;						// it will hold sum of a/d values for averaging			
	//
    INTCON.GIE = 0;						// disable interrupts
    ADCON0.GO = 1;						// first sample
    while(ADCON0.GO);					// wait until conversion complete
    INTCON.GIE = 1;						// enable interrupts
    ad_val = ad_val + ADRES;	
	//
    INTCON.GIE = 0;						// disable interrupts
    ADCON0.GO = 1;						// second sample
    while(ADCON0.GO);					// wait until conversion complete
    INTCON.GIE = 1;						// enable interrupts
    ad_val = ad_val + ADRES;		
	//
    INTCON.GIE = 0;						// disable interrupts
    ADCON0.GO = 1;						// third sample
    while(ADCON0.GO);					// wait until conversion complete
    INTCON.GIE = 1;						// enable interrupts
    ad_val = ad_val + ADRES;
	//
    INTCON.GIE = 0;						// disable interrupts
	ADCON0.GO = 1;						// forth sample
    while(ADCON0.GO);					// wait until conversion complete
    INTCON.GIE = 1;						// enable interrupts
    ad_val = ad_val + ADRES;
	//
	ADCON0.ADON = 0;					// A/D converter off
	//
  	TH1_PU = 0;                        	// turn 3.32k pull-up (B1) off 
  	TH2_PU = 0;                        	// turn 3.32k pull-up (B2) off
	PORTA = 0; 

  	val = ad_val/4;   					// calculate average
	delay_cycles(1);
	//
	//----------------------------------------------------------------
  	
  	if( val > 240)                        			//  (> 100k)		open
  	{
  		write_nibble(&ChargerStatus_H,0x03,0); 		     
		write_nibble(&flag2,0x00,0);				// flag2 bits:		b3=th_wt_enable,	-> enable wake up timer 
													//					b2=th_wc_enabled, 	-> enable wake-up charging 
													//					b1=th_liion, 		-> LiIn battery
													//					b0=th_contr_charge 	-> enable controlled charge
  	}else 
  	if (val > 220)									// 	(100k...30k)	cold
  	{
  		write_nibble(&ChargerStatus_H,0x02,0);		
     	write_nibble(&flag2,0x0d,0);
  	}else
  	if( (val < 221) && (val > 121) )      			//	(3k...30k) 		NiMh 	
  	{
		write_nibble(&ChargerStatus_H,0x00,0); 	     
		write_nibble(&flag2,0x05,0);
  	}else
  	if(( val < 122) && (val > 34) )       			// 	(500...3k)		HOT 	
  	{
  		write_nibble(&ChargerStatus_H,0x04,0); 	
 		write_nibble(&flag2,0x00,0);
  	}else  
  	if( (val<35) && (val > 4) )                  	// 	(50O..50 Ohms)	LiIon 				    			
  	{
  		write_nibble(&ChargerStatus_H,0x00,0); 	
		write_nibble(&flag2,0x0f,0);
   	}
  	if( val<5 )                  					//  <5...50 Ohms)   short
  	{
  		write_nibble(&ChargerStatus_H,0x0c,0); 	
		write_nibble(&flag2,0x00,0);
   	}
}


