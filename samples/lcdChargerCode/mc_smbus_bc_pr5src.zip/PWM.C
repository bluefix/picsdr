/////////////////////////////////////////////////////////////////////////////
// Double buffering:
// 	CC_COMM_L and CC_COMM_H are used for SMBus communications (double buffering)
// 	the internal CC_X and CV_X registers are updated when both ChargingVoltage and
// 	Charging Current are received.
// Pulsing at low current:
// 	ChargingCurrent variable is used to set PWM value (after limiting and scaling)
//  When the cherging current is less then 200mA, ChargingCurrent variable is
//	set to 4* of required value and pulsed with 1/4 duty cycle. 
//////////////////////////////////////////////////////////////////////////////
// 
// 
// for 3.5A output current: SEI input		= 0.746V 
//							divider's gain 	= 0.249249 	(3.3k/(10k+3.32k) 
//							PWM output 		= 2.99298V 	-> 3V
//							Npwm 			= 640 		Npwm = Voutpwm*1024/Vcc (3V*1024/4.8V) 													
//							scaling factor	= 0.182857	640/3500
//							Npwm			= 0.182857*ChargingCurrent
//----------------------------------------------------------------------------
void load_ipwm(void)
{
	long int  tmp1;
	// long int idata;
//	float fidata;
	//
	// ChargingCurrent=2000;		// for acuracy testing  of ChargingCurrent
	//
	idata = ChargingCurrent;
 	if(idata>3800) idata = 3800;	// limit ChargingCurrent to 3.8A
	// 
	idata = idata/16;				// 3800/16 = 237  -> 16 mA resolution
	idata = idata * 106;			//	scaling constant, for 1% accuracy 237 * 139 = 33172
	idata = idata/32;
/*
	fidata = (long)idata;
	fidata = fidata * 0.2728+0.5;
//	fidata = fidata * 0.1828+0.5;
	idata = (unsigned long)fidata;
*/
	set_pwm2_duty(idata);			// load PWM
}
////////////////////////////////////////////////////////////////////
// Scaling: Vpwmout 	= 2.5V -> Vchgout = 10V
//			SMBus data 	= 10000					(set 10V)
//			Vpwmout 	= 2.5V
// 			Npwm 		= 533.3 		2.5V * 1024/4.8V 	Npwm = Vpwmout*1024/Vcc
//			scaling 	= 0.05333		533.3/10000		
//----------------------------------------------------------------
void load_vpwm(void)
{
	//long vdata;
	//float fvdata;
	//
	vdata = ChargingVoltage;
	//
	// vdata = 18000;						// for testing voltage accuracy	
	//
	if(vdata>18000) vdata = 18000;			// limit the output voltage to 18V
	//
	vdata = vdata/32;						// 18,000mV -> 562,  32mV resolution (we need +-50mV for lIIon)
	vdata = 109 *vdata;						// scaling factor 0.0533* 2048 (at 18V : 562*109 = 61436
	vdata = vdata/64;						// 61436/64 = 960
/*
	fvdata = (float)vdata;
	fvdata = fvdata * 0.05333;				// 18000*0.05333 = 959.94
	vdata = (long)fvdata;
*/
	set_pwm1_duty(vdata);
}
/////////////////////////////////////////////////////////////////////////////
//  loads PWMs
//--------------------------------------------------------------------------
void load_pwms(void)
{
	*(&CC) = CC_L;						// build 16 bit number from 8 bit H and L
	*(&CC+1) = CC_H;
//	ChargingCurrent = CC;
	//--------------------------------------------------------------------------
	*(&CV) = CV_L;						// build 16 bit number from 8 bit H and L
	*(&CV+1) = CV_H;
//	ChargingVoltage = CV;
	load_ipwm();
	load_vpwm();
}

