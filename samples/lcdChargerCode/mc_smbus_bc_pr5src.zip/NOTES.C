
error_b1
error_b2
new_b1
new_b2
charging_b1
charging_b2





read_battery

check for communication error
		if bad: if new battery  
					apply wake-up charge for 3 min or util starts responding -> if no response: set error_bx
				if old battery ->  set error_bx		

charging
		
