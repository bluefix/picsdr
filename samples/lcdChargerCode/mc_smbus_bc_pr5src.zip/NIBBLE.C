////////////////////////////////////////////////////////////////////////
// File: nibble.c								KAD Electronics 01/27/98
// writes upper or lower nibble of a byte
//  	data 	-> address of the byte to change
//		nibble 	-> nibble to write (use lower 4 bit XXXX nnnn)
//		hi		-> 0 write to lower nibble 1 write to high nibble
// Example:		write_nibble(&a, 0x03,1)  writes 0x03 to H nibble of 'a'				
//------------------------------------------------------------------------
void write_nibble(char *data, char nibble, short hi)
{
	char temp;
	temp = *data;
	if(hi==0)
	{
		temp = temp & 0xf0;
		nibble = nibble & 0x0f;
		temp = nibble | temp;
	}else
	{
		temp = temp & 0x0f;
		nibble = swap(nibble);
		nibble = nibble & 0xf0;
		temp = nibble | temp;
	}
	*data = temp;
}
///////////////////////////////////////////////////////////////////
// File: nibble.c					KAD Electronics 	01/28/1998
// Invers low nibble in "a",if n=0. Inverts High nibble when n=1
//-----------------------------------------------------------------
void invert_nibble(char *a, short n )
{
	char tmp1, tmp2;
	tmp1 = *a;
	tmp2 = tmp1;
	//
	tmp2 = 0xff - tmp2;				// invert bits in this byte
	if(n) 
	{
		tmp1 = tmp1 & 0x0f;			//  clear upper nibble in result to zero				
		tmp2 = tmp2 & 0xf0;			//	clear bottom bits in inverted
	}
	else
	{
		tmp1 = tmp1 & 0xf0;			// clear bottom nibble in result to zero	
		tmp2 = tmp2 & 0x0f;			// clear upper nibble in inverted
	}
	tmp2 = tmp2 | tmp1;				// marry the two bytes
	*a = tmp2;
}
/////////////////////////////////////////////////////////////////
// FILE: NIBBLE.C					KAD Electronics  01/28/1998
// returns H ( when n = 1) or L nibble (when n=0)  of "a"
// example:	n=0		a=0xab;		returns: 0x0b
//			n=1					returns: 0x0a
//	Speed: 21us @ 4MHz
//---------------------------------------------------------------
char read_nibble( char a, short n)
{
	char tmp1;
	tmp1 = a;
	if(n) swap(tmp1);
	tmp1 = tmp1 & 0x0f;
	return(tmp1);
}
