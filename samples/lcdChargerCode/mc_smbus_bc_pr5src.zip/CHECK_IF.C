/*

// ---------------------------------------------------------------------------
// if no broadcast to the charger for 180second after the last broadcast   
// means: communication has been lost, charger needs to be shut-down to 
// avoid possible overcharge of battery 
    //-----------------------------------------------------------------------------
void cif_comm(void)
{
	if(!prescaler_carry) return;
	//
	if(UP_I || UP_V)
	{ 
		comm_timeout_cntr = 0;
		UP_I = 0;
		UP_V = 0;
	}
	if(!power_on)
	{
		if(comm_timeout_cntr<7200) comm_timeout_cntr++;    // 400/sec * 180sec = 7200
		else 
		{
			comm_timeout = 1;
			cv_received = 0;
			ci_received = 0;

			CC_L = 0;
			CC_H = 0;
			CV_L = 0;
			CV_H = 0;

			CC_COMM_H = CC_H;
			CC_COMM_L = CC_L;
			CV_COMM_H = CV_H;
			CV_COMM_L = CV_L;
			load_pwms();

			fast_blinking = 1;
			power_on = 1;			
			comm_timeout_cntr = 0x0000;
		}
	}     
}
*/
/*
//
////////////////////////////////////////////////////////////////////////////////////////    
// if there is no broadcast to the charger after a battery is connected to the system
// might SMBus needs to be cleared. an "SMBus reset" sequence is being sent (start-stop) 
// in every 30 seconds until the charger receives a broadcast (from the battery). 
//---------------------------------------------------------------------------------------
void cif_smbus(void)
{
	if(!prescaler_carry) return;
	
	if( power_on)     										// clear SMBus    
	{
		if(clear_smbus_cntr < 1200) clear_smbus_cntr++;  	// 30sec * 40/sec = 1200
		else
		{
			clear_smbus_cntr = 0;
			clear_smbus();
		}
	}
}
*/
///////////////////////////////////////////////////////////////////////////
// sets blinking speed and duty cycle)
/////////////////////////////////////////////////////////////////////////
void cif_led(void)
{
	

//	UCLED_=1;
//	delay_us(100);
//    UCLED_=0;

	char nmax, onmax;

	if(fast_blinking) 						// if fast blinking
	{
		nmax = 100;
		if(high_duty) onmax =80;			//		if H duty	-> set on time
		else onmax = 20;					//		if low duty	-> set on time
	}
	else 									// if slow blinking
	{
		nmax = 250;
		if(high_duty) onmax = 200;			//		H duty -> set on time
		else onmax = 25;					//  	L duty -> set on time
	}
	
	LED_counter++;							// increment LED counter (in every 25ms)
	//
	//--------------------------------------------------------------------
	//
	if(LED_counter > nmax)					// if end of periode
	{
		LED_counter = 0;					//		reset counter
		UCLED_=0;							//		turn LED on
	}
	if(LED_counter > onmax) UCLED_=1;		// if specified ob time expired: turn UC activity LED off
}
/////////////////////////////////////////////////////////////////////////////
// measure battery temperatures 
//
// --------------------------------------------------------------------------
void cif_therm(void)
{
	ad_counter++;
	if(ad_counter == 100)       	// is it time to measure thermistor ?
   	{                               // checks UV (DCOK input) also
     	ad_th();                  	// if ad_counter starts at 5, td=140ms
		ad_counter=0;
 	}   
}
/////////////////////////////////////////////////////////////////////////////////////////////
// check if data has been received in selstate_io (UP_SEL_STATE is set)
//		if yes 	
//		1. copy data from selstate_io to SelectorState 	->			(host writes 'stright data')
//		2. copy data from SelectorState to selstate_io 
//			A:  with POWER _BY nibble inverted if charging battery
//			B:  CHARGE nibble inverted if AC present
// 														->			(host reads 'inverted data) 			
//----------------------------------------------------------------------------------------------
void cif_selstate(void)
{
	if(UP_SEL_STATE)							// if sel state register has been updated
	{
		
		copy_to_ss();							// copy ss_i (SelectorState receiving) to
												// selector state. Copy nibble if not 0xf only		
		copy_to_ss_o();							// copy SlectorState to ss_o (SlectorState output)												 

//	 	connect_system();
		UP_REQ = 0;
		UP_SEL_STATE = 0;
	}											
}
///////////////////////////////////////////////////////////////////////////////////
//
//---------------------------------------------------------------------------------
void cif_alarm(void)
{
	if(UP_ALARM)								// if alarm was received
	{
		if( OVER_CHARGED_ALARM ||TERMINATE_CHARGE_ALARM || OVER_TEMP_ALARM || SPARE_BIT_H5)
		{		
			ALARM_INHIBITED = 1;
		}
		UP_ALARM = 0;
	}
}
/////////////////////////////////////////////////////////////////////////////////
//
//-------------------------------------------------------------------------------
void inc_prescaler(void)
{
	if(prescaler<10)
	{
		prescaler++;
		prescaler_carry=0;
	}
	else
	{
		prescaler = 0;
		prescaler_carry = 1;
	}
}
	
