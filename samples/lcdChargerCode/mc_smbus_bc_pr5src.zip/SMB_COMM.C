/////////////////////////////////
//    START
//------------------------------
void SMB_start(void)
{
	// if(SDA_in & SCL_in) 
	{
		scl_cntr = 0;

		SDA_dir = 1;						// SDA->H
		delay_us(10);
		SCL_dir = 1;						// SCL->H
		delay_us(10);		
		SDA_dir = 0;						// SDA -> L			-> START
		delay_us(10);
		SCL_dir = 0;						// SCL -> L
		//							
	}
}
////////////////////////////////
//   STOP
//------------------------------
void SMB_stop(void)
{		 	
	SCL_dir = 1;							// SCL -> H
	SDA_dir = 1;							// SDA -> H
	return;
}
//////////////////////////////////////////////////////////////////////////////////
//  							WRITE
//--------------------------------------------------------------------------------
char SMB_write(char a)
{
	char i, error, delay;
	error = 0;
	delay = 20;
	//
	delay_us(200);
	//
	//---------- send firdt bit of data and look for clock stretch -----------
	//
	if(bit_test(a,7)) SDA_dir = 1;			// data -> SDA
	else SDA_dir = 0;
	//
	SCL_dir = 1;							// SCL -> H

	while(!SCL_in)							// look out for clock stretching
	{										// total delay in loot 21us
		delay_us(1);

		if(scl_cntr<20000) scl_cntr++;		// time-out
		else 
		{
			smb_error =1;
			return 0;
		}
		delay_us(1);
	}

	rotate_left(&a,1);
	delay_us(10);
	SCL_dir = 0;
	//
	for(i= 0; i<7; i++)
	{
		SDA_dir = bit_test(a,7);			// data -> SDA
		delay_us(10);
		SCL_dir = 1;						// SCL -> H
		
/*		if(SDA_dir & (!SDA_in))	
		{
		 	smb_error = 1;	// SDA=H  but SDA=L ==> we lost arbitration
			return 0;
		}
*/
		rotate_left(&a,1);		
		delay_us(10);		
		SCL_dir = 0;						// SCL = L
	}
	//
	// ------------------------- look for ACK-------------------------
	//
	SDA_dir = 1;								// SDA = H	
	delay_us(10);
	SCL_dir = 1;								// SCL = H
	//
	while(!SCL_in)								// look out for clock stretching
	{
		if(scl_cntr<2000) scl_cntr++;			// time-out
		else 
		{
			
			// SMBLED_ = 0;
			// delay_ms(250);
			// delay_ms(250);
			// SMBLED_ = 0;			
			smb_error =1;
			return 0;
		}
	}
	//
	if(SDA_in) 									// check SDA line
	{
		SCL_dir = 0;
		SDA_dir = 0;
		delay_us(10);
		smb_error =1;
		return 1;
	}
	SCL_dir = 0;
	SDA_dir = 0;
	return 0;
}
/////////////////////////////////////////////////////////////////////////////////////
//							READ
//-------------------------------------------------------------------------------
char SMB_read(char ack)
{
	char i, a;
	//
	delay_us(100);
	SDA_dir = 1;
	delay_us(10);							// release data line
	SCL_dir = 1;							// SCL -> H
	while(!SCL_in)							// look out for clock stretching
	{
		if(scl_cntr<2000) scl_cntr++;		// time-out
		else 
		{
			smb_error =1;
			return 0;
		}
	}
	delay_us(20);
	shift_left(&a,1,SDA_in);
	SCL_dir = 0;
	//
	for(i= 0; i<7; i++)
	{
		SCL_dir = 1;						// SCL -> H
		delay_us(20);
		shift_left(&a,1,SDA_in);
		SCL_dir = 0;						// SCL -> L
		delay_us(20);
	}
	//
	//------------------ send ACK ----------------------
	//
	if(ack ==0)	SDA_dir = 1;				// SDA -> 1			send ACK
	else SDA_dir = 0;
	delay_us(20);
	SCL_dir = 1;							// SCL -> H			clock it in
	delay_us(20);	
	SCL_dir = 0;							// SCL -> 0
	delay_us(20);
	SDA_dir = 0;							// SDA = 0;			hold SDA low
   	return a;
}
///////////////////////////////////////////////////////////
//          read_smb_dev
//--------------------------------------------------------
long read_smb_device(char add, char func)
{
	long result = 0;
	char res_l, res_h, i;
	char read_smb_i;
	// 

	for(read_smb_i=0; read_smb_i<128; read_smb_i++)
	{

		smb_error = 0;
		//
		SMB_start();
 		SMB_write(add); 

 		if(!smb_error) SMB_write(func); 
		if(!smb_error) SMB_start();
		if(!smb_error) SMB_write(add +1);			
		if(!smb_error) res_l = SMB_read(1);		
		if(!smb_error) res_h = SMB_read(0);
		//
		SMB_stop();

		if(!smb_error)  break;

		delay_ms(10);

	}
	//
	*(&result) = res_l;
	*(&result+1) = res_h;
	if(smb_error) return 0x0000;
	else return result;
}

