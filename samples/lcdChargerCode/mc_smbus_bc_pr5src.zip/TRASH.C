
      //-------------------- selector status --------------------

      if(SMB_A) smbus1 = 1;             // Connect SMBus to.. 
      else smbus1 = 0;

      AC_PRESENT = acgood;              // set AC_PRESENT bit

      // -----------------------------------------------------      
      if( POWERED_BY_A)                 // power from batt1
      {
         prefb2 = 0;
         prefac = 0;
      } 
      //  -------------------------------------------------     
      //
      if(POWERED_BY_B)                      // power from batt2
      {
        if( !POWERED_BY_A)                  // if power not powered from A
        { 
          prefb2 = 0;
          prefac = 0;
        }
      }
      //--------------------------------------------------
      //      
      if( !POWERED_BY_A)                    // if not powwred from A                   
      {
         if( !POWERED_BY_B) prefac = 1;     // and it not powered from B            
      }                                     // power it from AC
      //
      PRESENT_A = b1good;
      PRESENT_B = b2good;

/*
      if( !(PRESENT_A = b1good) )
      {
        PRESENT_A = b1good;
        PORTB.3 = 0;                //int_ = 0;
        delay();
        PORTB.3 = 1;                //int_ = 1;
      } 
      if( !(PRESENT_B = b2good) )
      {
        PRESENT_B = b2good;
        PORTB.3 = 0;                //int_ = 0;
        delay();
        PORTB.3 = 1;                 //int_ =1;
      }   
*/
    }

    ad_counter--;
    // -------------------------------------------------------------------
    if(flag.0)                          // retun from I2C interrupt ?  		      
    {                               
        PORTB.3 = 0;                    // red LED on 
        delay();                        // 1 sec. delay
        PORTB.3 = 1;                    // red LED off
        flag.0 = 0;
//        i2c_counter = 0;                // reset I2C stack pointer
        // com_timeout_cntr = 0;
//        flag.1 = 0;                     // change to slow blinking
    }
    // ------------------ update request ----------------------------
    //
    if( UP_REQ )                            // if update request
    {  
        tst3 = flag1;

      // -------------------------------------------------------------------
      // 
      if(UP_CHARGER_MODE)                   // ChargerMode changed       
      {
        if( INHIBIT_CHARGE ) PORTC.0 = 1;
        else PORTC.0 = 0;
        
        if( POR_RESET ) initiv( 1 );
        UP_CHARGER_MODE = 0;
      }
      //                          
      if( UP_ALARM)                         //if AlarmWarning changed
      {
         if(AlarmWarning_H > 0x0f)         // if d15 | d14 | d13 | d12 = 1 
         {         
           PORTC.0 = 1;                   // sutdown charger  
           UP_ALARM = 0;                  // erase flag  
           ALARM_INHIBITED = 1; 
           //
           com_timeout_cntr = 0;          // reset
           flag.1 = 1;                    // set fast blinking
           flag.3 = 0;                    // enable com_timeout_cntr            
         }
         else
         { 
           UP_ALARM = 0;
           ALARM_INHIBITED = 0;
         }
      }  
    // -----------------------------------------------------------------
      if(UP_I)                            // ChargingCurrent() on stack ?
      {
        load_ipwm();                      // set PWM
        UP_I = 0;                         // erase update req. flag
        ALARM_INHIBITED = 0;
        //
        //
        com_timeout_cntr = 0; 
        flag.3 = 0;                       // enable com_timeout_cntr 
        flag.1 = 0;

        if ( !ALARM_INHIBITED)
        if ( !INHIBIT_CHARGE) 
        {
          flag.1 = 0;
          PORTC.0 = 0;        
        } 
     }
      //-----------------------------------------------------------
      if(UP_V)             // ChargingVoltage() on stack ?
      {
        load_vpwm();                      // set output voltage
        UP_V = 0;                         // erase command
        ALARM_INHIBITED = 0;
        // 
        com_timeout_cntr = 0;
        flag.3 = 0;                      // enable com_timeout_cntr 
        flag.1 = 0;
        if ( !ALARM_INHIBITED)
        if ( !INHIBIT_CHARGE) 
        {
           flag.1 = 0;
           PORTC.0 = 0;        
        } 
      }
      // ----------------------------------------------------------
      if( UP_SEL_STATE)
      {
         if( CHARGE_A ) if( !CHARGE_B) chargeb2 = 0;
         if( CHARGE_B ) if( !CHARGE_A) chargeb2 = 1;
      }
      // -----------------------------------------------------------
      if (UP_TH)                        //process thermistor info
      {
        if( THERMISTOR_OR)              // thermistor open
        {
          flag.1 = 1;                   // fast blinking
          initiv(1);                    // trickle charge 
        }
        else
        if(THERMISTOR_UR)               // thermistor shorted
        {
          flag.1 = 1;
          initiv(1);
        }
        else
        if( THERMISTOR_HOT)             // if thermistor hot
        {
          flag.1 = 1;
          initiv(1);
        }
        //
        if( UP_NIMH )
        {
          //flag.1 = 0;
          // initiv(1);
        }
        if( UP_LIION )
        {
          //flag.1 = 0;
          //initiv(0);
        }
        UP_TH = 0;                     // reset thermistor update req.  
      }  
    //----------------------------------------------------------
      // 
      if( flag1 == 1 ) flag1 = 0;       // erase  update flag
/*
      if ( !ALARM_INHIBITED)
      if ( !INHIBIT_CHARGE) 
      {
       flag.1 = 0;
       PORTC.0 = 0;        
      } 
*/
    } // end if(UP_REQ)
    //  



   tst1 = 0;						// the following registers are for test purpose only
   tst2 = 0;
   tst3 = 0;
   tst4 = 0;
   tst5 = 0;
   tst_cntr = 0;


///////////////////////////////////////////////////////////////////////////////////
// 	Measures cell temperature of the battery connected to the charger.
//  Operation:
//  	Turns-on puul-up to the termistor
//		mesaures thermistor value times times
//		averages measured values, processed A/D value appers in "val"   
//		sets thermistor flags in ChargerStatus_H byte.
//
//		By Laszlo Kiraly @ Kad Electronics, Sunnyvale CA, Email:KiralyL@aol.com  
// ------------------------------------------------------------------------------
void ad_th( void)
{
	ADCON1 = 0x06;
	if(CHARGE_A)						// if charger is connected to battery A bias (3.32k) th1 line
 	{
		TH1_PU = 1;						// turn-on pullup for thermistor 1, use AN0 analog input:
		ADCON0 = 41;					// ADCS1 ADCS0 CHS2 CHS1  CHS0 GO U ADON, -->  OSC/8 CH0, ADON
 	}

	if(CHARGE_B) 						// if charger is connected to battery B bias (3.32k) th2 line
	{
		TH2_PU = 1;						// turn-on pullup for thermistor 2, use AN1 analog input:
		ADCON0 = 49;					// ADCS1 ADCS0 CHS2 CHS1  CHS0 GO U ADON  --> OSC/8 CH1, ADON 
	}

	PORTA = 0xff;
	TH1_PU = 1;
	TH2_PU = 1;

  	ad_val = 0x0;						// it will hold sum of a/d values for averaging			
	//
    INTCON.GIE = 0;						// disable interrupts
    ADCON0.GO = 1;						// first sample
    while(ADCON0.GO);					// wait until conversion complete
    INTCON.GIE = 1;						// enable interrupts
    ad_val = ad_val + ADRES;	
	//
    INTCON.GIE = 0;						// disable interrupts
    ADCON0.GO = 1;						// second sample
    while(ADCON0.GO);					// wait until conversion complete
    INTCON.GIE = 1;						// enable interrupts
    ad_val = ad_val + ADRES;		
	//
    INTCON.GIE = 0;						// disable interrupts
    ADCON0.GO = 1;						// third sample
    while(ADCON0.GO);					// wait until conversion complete
    INTCON.GIE = 1;						// enable interrupts
    ad_val = ad_val + ADRES;
	//
    INTCON.GIE = 0;						// disable interrupts
	ADCON0.GO = 1;						// forth sample
    while(ADCON0.GO);					// wait until conversion complete
    INTCON.GIE = 1;						// enable interrupts
    ad_val = ad_val + ADRES;
	//
	ADCON0.ADON = 0;					// A/D converter off
	//
  	TH1_PU = 0;                        	// turn 3.32k pull-up (B1) off 
  	TH2_PU = 0;                        	// turn 3.32k pull-up (B2) off
	PORTA = 0; 

  	ad_val = ad_val/4;   				// calculate average
	//
	//----------------------------------------------------------------
  	
  	if( val > 240)                        				//  thermistor overrange --> 	open
  	{
     	ChargerStatus_H = ChargerStatus_H & 0xf0;   	// clear th bits
     	THERMISTOR_OR = 1;
		THERMISTOR_COLD = 1;
		th_nimh  = 0;
		th_liion = 0;
  	}else 
  	if (val > 220)
  	{
     	ChargerStatus_H = ChargerStatus_H & 0xf0;   	// clear th bits
     	THERMISTOR_COLD = 1;		
		th_nimh  = 0;
		th_liion = 0;
  	}else
  	if( (val < 221) && (val > 121) )      				// thermistor in-range 	--> 	NiMh
  	{
    	ChargerStatus_H = ChargerStatus_H & 0xf0;   	// clear th bits        
		th_nimh  = 1;
		th_liion = 0;
  	}else
  	if( (val < 122) && (val > 34) )       				// thermistor too hot  	--> 	HOT
  	{
   		ChargerStatus_H = ChargerStatus_H & 0xf0;  		// clear th bits        
    	THERMISTOR_HOT = 1;
		th_nimh  = 0;
		th_liion = 0;
  	}else  
  	if( (val<35) && (val > 10) )                  		// Li ION  				--> 	LiIon
  	{
       ChargerStatus_H = ChargerStatus_H & 0xf0;   		// clear th bits        
		th_nimh  = 0;
		th_liion = 1;
  	}else
  	if( val< 11)                          				// underrange UR 		--> 	shorted
  	{ 
     	ChargerStatus_H = ChargerStatus_H & 0xf0;   	// clear th bits        
     	THERMISTOR_UR = 1;
		th_nimh  = 0;
		th_liion = 0;
  	}
}

/* *******************************************************************

/////////////////////////////////////////////////////////////////
// Measures cell temperature.
// ------------------------------------------------------------
void ad_th( void)
{
  char *ptr;
  char i,j; 

  PORTA.5 = 1;                              // use 3.32k pull-up B1 
  PORTA.4 = 1;                              // 3.32k pull-up for B2

  ad_val = 0x0;

  for( j=0; j<4; j++)                       // measure thermistor 4 times
  {  
    PIR1.ADIF = 0;
    ADCON0.GO = 1;
    while(ADCON0.GO);
    ad_val = ad_val + ADRES;
  }

  PORTA.5 = 0;                          // turn 3.32k pull-up (B1) off 
  PORTA.4 = 0;                          // turn 3.32k pull-up (B2) off

  ad_val = ad_val / 4;   
  //
  ptr = &ad_val;                    
  val = *ptr;

   tst1 = *ptr;
   tst2 = *(ptr+1);
  //
  if( val > 240)                        // -- thermistor OR---------
  {
     ChargerStatus_H = ChargerStatus_H & 0xf0;   // clear th bits
     flag.1 = 1;
     initiv(1);
     THERMISTOR_OR = 1;
     UP_TH = 1;
     UP_REQ = 1;
     UP_LIION = 0;
     UP_NIMH = 0;
  }

  if( (val > 220) && (val < 240) )    // -- thermistor too cold---------
  {
     ChargerStatus_H = ChargerStatus_H & 0xf0;   // clear th bits
     THERMISTOR_COLD = 1;
     UP_TH = 1;
     UP_REQ = 1;
     UP_LIION = 0;
     UP_NIMH = 0;
  }
  //
  if( (val < 221) && (val > 121) )      // thermistor in-range -----------
  {
    flag.2 = 0;                     // clear thermistor error flag        
    ChargerStatus_H = ChargerStatus_H & 0xf0;   // clear th bits        
    UP_REQ = 1;
    UP_TH = 1;
    UP_LIION = 0;
    UP_NIMH = 1;
    UP_REQ = 1;
  }
  //
  if( (val < 122) && (val > 34) )       // thermistor too hot -----------
  {
     flag.2 = 1;		                // set thermistor  flag
     
     ChargerStatus_H = ChargerStatus_H & 0xf0;  // clear th bits        
     THERMISTOR_HOT = 1;
     UP_REQ = 1;
     UP_TH  = 1;
     UP_LIION = 0;
     UP_NIMH = 0;
  }
  //  
  if( (val<35) && (val > 10) )                  // Li ION  
  {
    //if(flag.2)
   // {
       flag.2 = 0;                      // clear error flag

       ChargerStatus_H = ChargerStatus_H & 0xf0;   // clear th bits        
       UP_REQ = 1;
       UP_TH  = 1;
       UP_LIION = 1;
       UP_NIMH = 0;
//    }
  }
  if( val< 11)                          // Thermistor shoted 
  {
    //  flag.1 = 1;                        // grn LED fast blinking
     flag.2 = 1;		        // set thermistor  flag
 
     ChargerStatus_H = ChargerStatus_H & 0xf0;   // clear th bits        
     THERMISTOR_UR = 1;
     UP_REQ = 1;
     UP_TH  = 1;
     UP_LIION = 0;
     UP_NIMH = 0;
  }
}
*********************************************************************** */

/////////////////////////////////////////////////////////////////////////////
//  selstate_io  -> selectorState
// we do not ned this routine, host writes
//---------------------------------------------------------------------------
void copy_to_ss( void)
{
	SelectorState_L.0 = selstate_io_l.0;		// this nibble is unchanged
	SelectorState_L.1 = selstate_io_l.1;
	SelectorState_L.2 = selstate_io_l.2;
	SelectorState_L.3 = selstate_io_l.3;

	//											// if AC present invert this nibble
	if(AC_PRESENT)							 
	{
		SelectorState_L.4 = !selstate_io_l.4;
		SelectorState_L.5 = !selstate_io_l.5;
		SelectorState_L.6 = !selstate_io_l.6;
		SelectorState_L.7 = !selstate_io_l.7;
	}
	else
	{
		SelectorState_L.4 = selstate_io_l.4;
		SelectorState_L.5 = selstate_io_l.5;
		SelectorState_L.6 = selstate_io_l.6;
		SelectorState_L.7 = selstate_io_l.7;
	}
	//
	// --------------------- H byte -----------------------------------
	//	

	if(CHARGING_INDICATOR)					// POWER_BY nibble inverted if battery being charged							 
	{										

		SelectorState_H.0 = !selstate_io_h.0;
		SelectorState_H.1 = !selstate_io_h.1;
		SelectorState_H.2 = !selstate_io_h.2;
		SelectorState_H.3 = !selstate_io_h.3;
	}
	else
	{
		SelectorState_H.0 = selstate_io_h.0;
		SelectorState_H.1 = selstate_io_h.1;
		SelectorState_H.2 = selstate_io_h.2;
		SelectorState_H.3 = selstate_io_h.3;
	}

	SelectorState_H.4 = selstate_io_h.4;			// this nibble is unchanged
	SelectorState_H.5 = selstate_io_h.5;
	SelectorState_H.6 = selstate_io_h.6;
	SelectorState_H.7 = selstate_io_h.7;


}

/* ****************************************************************
//               using CCS set_pwm functions, instead these


//----------------------------------------------------------------
// reads current values from ChargingCurrent_L and ChargingCurrent_H 
// locations, (L and H bytes) scales and limits current word, and
// loads it in PWM register (10 bit mode)
//-----------------------------------------------------------------
void load_ipwm( void )
{
  long idata;
  char *ptr;
  struct	ilowbits_map
  {
  	int	b0 : 1;
  	int	b1 : 1;
  	int	b2 : 1;
  	int	b3 : 1;
  	int	b4 : 1;
  	int	b5 : 1;
  	int	b6 : 1;
  	int	b7 : 1;
  }ilowbits;
  // bits ilowbits;
  //
  ptr = &idata;                             // get address of idata
  //
  *ptr = ChargingCurrent_L;                 // load L byte of idata
  *(ptr+1) = ChargingCurrent_H;             // load H byte of idata
  //
  if(idata > 2600) idata = 2600;
  //
  idata >>=2;                       // scale idata 4096mA / 1024 = 4
  ilowbits = *ptr;                  // save L byte 
  //
  idata >>=2;                       // upper 8 bit of data
  //
  CCP2CON.CCP2X = ilowbits.b1;       // load lower two LSBits of 10 bit word to PWM
  CCP2CON.CCP2Y = ilowbits.b0;
  CCPR2L = *ptr;                    // load upper 8 bit of 10 bit PWM word
} 
//
///////////////////////////////////////////////////////////////////////////
// Reads voltage data from ChargingVoltage_L ChargingCurrent_H locations,
// assembles a 16 bit word. Limits the voltage at max 20V, scales vdata
// voltage data word and loads PWM with 10 bit data.
//------------------------------------------------------------------------
void load_vpwm( void )
{
  long vdata;
  char *ptr;
  struct	vlowbits_map
  {
  	int	b0 : 1;
  	int	b1 : 1;
  	int	b2 : 1;
  	int	b3 : 1;
  	int	b4 : 1;
  	int	b5 : 1;
  	int	b6 : 1;
  	int	b7 : 1;
  }vlowbits;

  // bits vlowbits;
  //
  ptr = &vdata;                         // get address of idata
  *ptr = ChargingVoltage_L;             // load L byte of idata
  *(ptr+1) = ChargingVoltage_H;         // load H byte of idata
  //
  if(vdata < 8000) vdata = 8000;        // PWM1 0x000 =8V,  0x3FF = 20V
  if(vdata > 18000) vdata=18000;        // limit incoming voltage to 20V
  //
  vdata = vdata-6000;                   // 
  //
  vdata >>= 4;                          // scale vdata 22-6=16V,  16V/1024=16
  vlowbits = *ptr;                      // save L byte 
  vdata >>=2;                           // upper 8 bit of data
  //
  CCP1CON.CCP1X = vlowbits.b1;       	// load lower two LSBits of 10 bit word
  CCP1CON.CCP1Y = vlowbits.b0;       	// to PWM 9-th and 10-th bits.
  CCPR1L = *ptr;                    	// load upper 8 bit of 10 bit PWM word
} 

**************************************************************************** */


/*
void state_machine(void)
{

	if(INHIBIT_CHARGE)
	{
//??		CHGEN = 0;
		fast_blinking = 1;
	}

	if(power_on && AC_PRESENT && (!INHIBIT_CHARGE) )
	{
		//---------------------------------------------------------------------------------------
		// at power on, if the  thermistor not hot, apply wake-up charge to battery indefinitely
		//
		if( (!THERMISTOR_COLD) && (!THERMISTOR_HOT) )	
		{
			pulse_output = 1;
			CHGEN = 1;									// enable charger
		}
		//---------------------------------------------------------------------------------------
		//	at power on, if thermistor hot, apply wake-up charge for 180 seconc.
		//
		if( (THERMISTOR_HOT && THERMISTOR_UR) || (THERMISTOR_COLD && !THERMISTOR_OR) )	
		{
			if(!pwr_on_timeout)
			{
				pulse_output = 1;
				wake_up_timer++;
				if(wake_up_timer > 1800) pwr_on_timeout =1;
			}else
			{
				pulse_output = 0; 
				CHGEN = 0;								// battery hot, wake_up timeout -> shut-down charger
			}		
		}
	}
	// ------------------------------------------------------------------------------------------------
	//	TH RANGE:	(0 to 500) 		(500 to 3k)		(3k to 30k)		(30k to 100k)		( >100k)
	//			 
	//  TH. FLAG1:	THERMISTOR_UR		-				-				-				THERMISTOR_OR
	//	TH. FLAG2:	THERMISTOR_HOT	THERMISTOR_HOT		-			THERMISTOR_COLD		THERMISTOR_COLD
	//	
	//	RESPONSE:	ALLOWED			NOT ALLOWED		ALLOWED			ALLOWED				NOT  ALLOWED
	// -------------------------------------------------------------------------------------------------
	//										f = UR + HOT\ * OR\ = UR + (HOT + OR)\
	//


	//
	if(btmp1 == 0b0111100)


	if(cv_received && ci_received && (!INHIBIT_CHARGE) )
	{
		if((THERMISTOR_OR ) || !( THERMISTOR_OR || THERMISTOR_OR) )
		{
			pulse_output = 0;
			load_ipwm();							// load new current value to IPWM
			load_vpwm();							// load new voltage value to VPWM
			CHGEN = 1;								//	enable charger
			CHARGING_INDICATOR = 1;					// set chaging indicator in SlactorInfo		
		}
	}
}



*/
////////////////////////////////////////////////////////////////////////////////////
//  12/26/97
//  from if(RESET_TO_ZERO) function. This piece of code is replaced by set_iv(0, 0); function
//------------------------------------------------------------------------------------
/*
		CC_L = 0;
		CC_H = 0;
		CV_L = 0;
		CC_H = 0;
		//
		CC_COMM_H = CC_H;
		CC_COMM_L = CC_L;
		CV_COMM_H = CV_H;
		CV_COMM_L = CV_L;
*/
//////////////////////////////////////////////////////////////////////////////////////
// 12/26/97
// 	from state machine under if(ALARM_INHIBITED). this piece of code is replaced by	
//  set_iv(0, 0) function
/*
		CC_L = 0;
		CC_H = 0;
		//
		CV_L = 0;
		CC_H = 0;
		//
		CC_COMM_H = CC_H;
		CC_COMM_L = CC_L;
		CV_COMM_H = CV_H;
		CV_COMM_L = CV_L;
*/
//////////////////////////////////////////////////////////////////////////////////////////
// 12/26/97
// from state machine. under: 	
// if(btmp1 != 0) 						//  #15 if( (!BATTERY_PRESENT) || POR_RESET || (!AC_PRESENT))
// replaced by set_iv(100, 18000);
//----------------------------------------------------------------------------------------
/*
		CC_L = 100;						// set charging current to 100mA
		CC_H = 0;
		CV_L = 0x50;					// set charging voltage  to 18V
		CV_H = 0x46;
		CC_COMM_H = CC_H;				// make ChargingCurrent available for host
		CC_COMM_L = CC_L;				//		write it in comm register (R/W)
		CV_COMM_H = CV_H;
		CV_COMM_L = CV_L;
*/
///////////////////////////////////////////////////////////////////////////////////////////
// 12/26/97
// from state machine, under if(POR_RESET)...
// this piece of code is replaced by goto por_add;
//-----------------------------------------------------------------------------------------
 		SMBLED_=0;
 		Delay_Ms_4MHz(250);          	// wait 1sec until voltages settle
  		Delay_Ms_4MHz(250);
  		Delay_Ms_4MHz(250);
  		Delay_Ms_4MHz(250);
  		SMBLED_=1;

  		disable_interrupts(GLOBAL);		// disable interrupts
  		enable_interrupts(INT_SSP);		// enable i2c interrupt
  		enable_interrupts(RTCC_ZERO);	// enable tmr0 interrupt
  		enable_interrupts(EXT_INT);		// enable external interrupt
  		enable_interrupts(GLOBAL);		// enable interrupts

  		setup_counters(RTCC_EXT_H_TO_L, WDT_2304MS);
  		set_rtcc(0xff);
  		setup_timer_1(0x01);
  		setup_adc(ADC_CLOCK_DIV_2);

  		stm_tst = 0;
  		cmd =  0;						// clear command code register
  		data_cntr = 0;					// clear datat counter
  		i2c_temp = 0;					// clear i2c_temp register
  		//
  		initiv(1);                     	// call pwm initialization routine
  		//
  		set_present();					// sets PRESENT_X nibble
  		set_ok_to_use();				// set OK_TO_USE_X nibble (assume: present=O.K.)
  		set_power_by();					// set POWER_BY_X nibble  (AC-> batt1->batt2)

  		set_smbus();					// check POWER_BY_X and connect set SMB_X nibble the same
  		set_charge();
  		Delay_Ms_4MHz(250);  
  		Delay_Ms_4MHz(250);  
  		DM3_ = 1;
  		//
  		dm3_ac = 0;
  		dm3_dc = 0;
  		//
  		UP_SEL_STATE = 0;
		POR_RESET = 0;
		power_on = 1;
		fast_blinking = 1;
		set_auto_flag();
		
