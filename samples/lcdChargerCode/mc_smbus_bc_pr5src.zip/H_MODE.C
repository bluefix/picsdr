/* ------------------------------------------------------------------------------
							HOST MODE ROUTINES
cif_led()
cif_red_light()
cif_comm()
cif_smbus()	
cif_therm()
---------------------------------------------------------------------------------- */
//
//
/////////////////////////////////////////////////////////////////////////////////////
// cif_led()												file: h_mode.c
//				toggles uC activity LED
//
// sets blinking speed and duty cycle)
/////////////////////////////////////////////////////////////////////////////////////
void cif_led(void)
{
//	UCLED_=1;
//	delay_us(100);
//    UCLED_=0;

	char nmax, onmax;

	if(fast_blinking) 						// if fast blinking
	{
		nmax = 100;
		if(high_duty) onmax =90;			//		if H duty	-> set on time
		else onmax = 10;					//		if low duty	-> set on time
	}
	else 									// if slow blinking
	{
		nmax = 250;
		if(high_duty) onmax = 240;			//		H duty -> set on time
		else onmax = 10;					//  	L duty -> set on time
	}
	
	LED_counter++;							// increment LED counter (in every 25ms)
	//
	//--------------------------------------------------------------------
	//
	if(LED_counter > nmax)					// if end of periode
	{
		LED_counter = 0;					//		reset counter
		UCLED_=0;							//		turn LED on
	}
	if(LED_counter > onmax) UCLED_=1;		// if specified ob time expired: turn UC activity LED off
}
//
///////////////////////////////////////////////////////////////////////////////////
//	cif_red_light()												file: h_mode.c
//
// it lights RED (SMBus LED) ater smbus communication for 20*0.1sec
//--------------------------------------------------------------------------------
void cif_red_light()
{
	if(ret_from_int	)
	{
		if(smbled_counter < 20)			// if count < limit 
		{
			smbled_counter++;			//		increment counter
			SMBLED_ = 0;				//		turn SMB LED n
		}
		else							// if count > limit
		{
			smbled_counter=0;			// 		reset RED LED timer
			SMBLED_ = 1;				// 		turn SMB LED off
			ret_from_int = 0;			// 		reset interrupt flag
		}
	}
}
//////////////////////////////////////////////////////////////////////////////////
//	cif_comm()													file: h_mode.c
//
// if no broadcast to the charger for 180second after the last broadcast   
// means: communication has been lost, charger needs to be shut-down to 
// avoid possible overcharge of battery 
//////////////////////////////////////////////////////////////////////////////////
void cif_comm(void)
{
	if(!prescaler_carry) return;
	//
	if(UP_I || UP_V)
	{ 
		comm_timeout_cntr = 0;
		UP_I = 0;
		UP_V = 0;
	}
	if(!power_on)
	{
		if(comm_timeout_cntr<7200) comm_timeout_cntr++;    // 400/sec * 180sec = 7200
		else 
		{
			comm_timeout = 1;
			cv_received = 0;
			ci_received = 0;

			CC_L = 0;
			CC_H = 0;
			CV_L = 0;
			CV_H = 0;

			CC_COMM_H = CC_H;
			CC_COMM_L = CC_L;
			CV_COMM_H = CV_H;
			CV_COMM_L = CV_L;
			load_pwms();

			fast_blinking = 1;
			power_on = 1;			
			comm_timeout_cntr = 0x0000;
		}
	}     
}
//////////////////////////////////////////////////////////////////////////////////////// 
//	cif_smbus()														file: h_mode.c
//
// if there is no broadcast to the charger after a battery is connected to the system
// might SMBus needs to be cleared. an "SMBus reset" sequence is being sent (start-stop) 
// in every 30 seconds until the charger receives a broadcast (from the battery). 
//---------------------------------------------------------------------------------------
void cif_smbus(void)
{
	if(!prescaler_carry) return;
	
	if( power_on)     										// clear SMBus    
	{
		if(clear_smbus_cntr < 1200) clear_smbus_cntr++;  	// 30sec * 40/sec = 1200
		else
		{
			clear_smbus_cntr = 0;
			clear_smbus();
		}
	}
}
///////////////////////////////////////////////////////////////////////////////////////
// cif_therm()														file: h_mode.c
//
// measure battery temperatures 
// -------------------------------------------------------------------------------------
void cif_therm(void)
{
	ad_counter++;
	if(ad_counter == 100)       	// is it time to measure thermistor ?
   	{                               // checks UV (DCOK input) also
     	ad_th();                  	// if ad_counter starts at 5, td=140ms
		ad_counter=0;
 	}   
 
}


