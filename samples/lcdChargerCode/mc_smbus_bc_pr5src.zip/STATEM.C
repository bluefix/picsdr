//////////////////////////////////////////////////////////////////////////////////
// stm_tst = 	1 battery not present | AC not present | POR reset
//				2 inhibit charge
//				3 reset to zero
//				4. alarm inhibited
//				6. controlled charge
//-------------------------------------------------------------------------------

void state_machine( void)
{
	// --------------------------------------------------------------------------
	if(THERMISTOR_OR) 					// no battery connected or thermistor shorted
	{
		BATTERY_PRESENT = 0;
	}else BATTERY_PRESENT = 1;

	///////////////////////////////////////////////////////////////////////////////
	//	 if !BATTERY_PRESENT 	OR 	!AC_PRESENT OR chgsel_change,;
	//---------------------------------------------------------------------------
	btmp1 = 0;						
	btmp1b0 = !BATTERY_PRESENT;			// if any of these H, wake-up charge
	btmp1b1 = chgsel_change;			// switched to other battery
	btmp1b2 = !AC_PRESENT;
	//
	if(btmp1 != 0) 						//  #15 if( (!BATTERY_PRESENT) || POR_RESET || (!AC_PRESENT)) 
	{
		chgsel_change = 0;
		fast_blinking = 1;				// set fast blinking speed
		// BATTERY_PRESENT = 0;			// reset battery present flag
		CHARGING_INDICATOR = 0;
		//
		set_iv(100, 18000);				// set 100 mA and 18V
		load_pwms();					// load PWMs
		//
		cv_received = 0;				// wait for ChargingVoltage
		ci_received = 0;				//      and chargingCurrent from the battery
		power_on = 1;					// set power_on flag
		stm_tst = 1;					// for testing
	}
	//--------------------------------------------------------------------------------
	if(INHIBIT_CHARGE)   				// INHIBIT_CHARGE bit is set
	{
		CHGEN = 0;						// inhibit charger
		fast_blinking = 1;				// fast blinking
		CHARGING_INDICATOR = 0;			// reset CHARGING_INDICATOR
		CHARGE_INHIBITED = 1;			// set CHARGE_INHIBITED flag
		stm_tst = 2;
	}
	else
	{ 

		CHGEN = 1;						// enable charger
		CHARGE_INHIBITED = 0;
	}
	//----------------------------------------------------------------------------------
	if(RESET_TO_ZERO)					// RESET_TO_ZERO bit is set  
	{
		set_iv(0, 0);

		//
		load_pwms();
		fast_blinking = 1;
		CHARGING_INDICATOR = 0;
		RESET_TO_ZERO = 0;
		stm_tst = 3;
	}
	//---------------------------------------------------------------------------------
	if(POR_RESET)
	{
		chgsel_change = 0;
		fast_blinking = 1;				// set fast blinking speed
		// BATTERY_PRESENT = 0;			// reset battery present flag
		CHARGING_INDICATOR = 0;
		//
		set_iv(100, 18000);				// set 100 mA and 18V
		load_pwms();					// load PWMs
		//
		cv_received = 0;				// wait for ChargingVoltage
		ci_received = 0;				//      and chargingCurrent from the battery
		power_on = 1;					// set power_on flag		
	}
	//---------------------------------------------------------------------------------
	if(cv_received && ci_received) 		// if CV and CI received
	{
		ALARM_INHIBITED = 0;
		AlarmWarning_H = 0;
		AlarmWarning_L = 0;
	}
	//-----------------------------------------------------------------------------------
	if(ALARM_INHIBITED)					// alarm inhibited
	{
		fast_blinking = 1;							
		CHARGING_INDICATOR = 0;
		set_iv(0,0);
		load_pwms();
	}

	//------------------------------------------------------------------------------

	btmp1b0 = cv_received;					// wake-up -> controlled charge
	btmp1b1 = ci_received;									
	btmp1b2 = AC_PRESENT;
	btmp1b3 = INHIBIT_CHARGE;
	btmp1b4 = THERMISTOR_HOT;
	btmp1b5 = 0;
	btmp1b6 = 0;
	btmp1b7 = 0;
	//
	btmp2 = 0;
	//           76543210
	if(btmp1 == 0b00000111) power_on = 0;		// state diagram #8	
    //
	btmp1b5 = THERMISTOR_UR;
	if(btmp1 == 0b00110111) power_on = 0;		// state diagram #9	
	//-----------------------------------------------------------------------------

	btmp1b0 = 1;								// cv_received;
	btmp1b1 = 1; // ci_received; //|| cv_received;
	btmp1b2 = BATTERY_PRESENT;
	btmp1b3 = AC_PRESENT;
	btmp1b4 = power_on;
	btmp1b5 = RESET_TO_ZERO;
	btmp1b6 = ALARM_INHIBITED;
	btmp1b7 = INHIBIT_CHARGE;
	//
	btmp2 = 0;
	btmp2b0 = THERMISTOR_OR;
	btmp2b2 = THERMISTOR_COLD;
	btmp2b3 = THERMISTOR_HOT;
	btmp2b4 = THERMISTOR_UR;

	//--------------------------------------------------------------------------------
	if(btmp1 == 0b00001111)				// controlled charge 
	{
		if(btmp2 == 0x00) goto sadd1;	// normal range  	3k...30k
		if(btmp2 == 0x0C) goto sadd1;	// 					0...500
		if(btmp2 == 0x02) goto sadd1;	//                  30k...100k
		else goto sadd2;
sadd1:
			fast_blinking = 0;			// slow down UP activity LED
			//
			CC_L = CC_COMM_L;
			CC_H = CC_COMM_H;
			CV_L = CV_COMM_L;
			CV_H = CV_COMM_H;	
			load_pwms();
			//
			stm_tst = 6;
			cv_received = 0;
			ci_received = 0;
sadd2:									// exit if thermistor is not in valid range
 		delay_cycles(1);	
	}
}
// -------------------------------------------------------------------------------

