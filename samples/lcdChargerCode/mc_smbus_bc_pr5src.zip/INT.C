///////////////////////////////////////////////////////////////////////////////////////////
/* 						SMbus interrupt service rutin

	When SSPBUF (SMBus buuffer) is full (receiving) or empty (transmission) the processor 
    generates an interrupt.

	If The byte is an address (SSPSTAT.5 = 0)
		program checks if master wants to read or write (SSPSTAT.2)
    	If master wants to write, the program initializes data_counter to 0x00
		If master wants to read the program initializes  data_counter to 0x10
		(exit from ISR)

	If SSPBUFF holds a command (receiving second byte = data_counter=0x00 or 0x1o):
		cmd=SSPBUF
		increment data_counter
		(exit from ISR)

	if data_counter=0x02
		receives and stores first byte of data at appropriate (CMD shown) location
		increment data counter
		(exit from ISR)

	if data_counter=0x03
		receives and stores first byte of data at appropriate (CMD shown) location
		increment data counter
		(exit from ISR)


	if data_counter=0x012
		loads SSPBUFF with first byte (CMD shown) data;
		increment data counter

	if data_counter=0x013
		loads SSPBUFF with second byte (CMD shown) data;
		increment data counter

	if data_counter == 0x04 Last byte of data wes previously received
		set update request flags (UP_REQ general update request flag + specific flag)

	exit from ISR

 ********************************************************************************* */
//------------------------------------------------------------------------------------
#int_ssp
void smbus_int(void)
{
  SSPCON.CKP = 0;                           		// hold SCK low
  SSPCON.SSPOV = 0;

  enable_comm_cntr = 1;                           	// enable comm timeout cntr
  i2c_temp = SSPBUF;								// read SSPBUFF
  //
  if( !SSPSTAT.DA)                           		// if address was received-----
  {
    if( SSPSTAT.RW ) data_cntr = 0x10;       		// if host wants to read    
    else data_cntr = 0x00;                  		// if host wants to write               
  }

  if( data_cntr == 0x01) cmd = i2c_temp;     		// if first data byte = CMD                                          		// cntr=0 write to charger:

  // =================================================================

  if( data_cntr == 0x02 )                   		// receiving first byte of data 
  { 
  	switch(cmd)
  	{
		case 0x12	:	ChargerMode_L = i2c_temp; 
						break;
		case 0x13	: 	ChargerStatus_L = i2c_temp;
						break;
		case 0x14	:	CC_COMM_L = i2c_temp;
						break;
		case 0x15	:	CV_COMM_L = i2c_temp;
						break;
		case 0x16	:	AlarmWarning_L = i2c_temp;
						break;
		case 0x21	:	selstate_il = i2c_temp;
						break;
		case 0x22	:	SelectorPresets_L = i2c_temp;
						break;
		case 0x24	:	SelectorInfo_L = i2c_temp; 
						break;
		case 0x3c	:	OptMfgFunction1_L = i2c_temp;
						break;
		case 0x3d	:	OptMfgFunction2_L = i2c_temp;
						break;
		case 0x3e	:	OptMfgFunction3_L = i2c_temp;
						break;
		case 0x3f	:	OptMfgFunction4_L = i2c_temp;
						break;
		case 0x2f	:	OMF5_L = i2c_temp;
						AUTO_ENABLE = OMF5_LB0;
	}
  }
  //
  // --------------------------------------------------------------
  if( data_cntr == 0x03 )           	// receiving second byte of data 
  {
	switch(cmd)
	{
		case 0x12	:	ChargerMode_H = i2c_temp;
						break;
		case 0x13	:	ChargerStatus_H = i2c_temp;
						break;
		case 0x14	:	{
						CC_COMM_H = i2c_temp;						
							if(CC_COMM_H > 0x0e)
							{
								if(CC_COMM_L > 0xd8) CURRENT_OR = 1;
								else CURRENT_OR  = 0;
							}else CURRENT_OR  = 0;
						}
						break;
		case 0x15	:	{
							CV_COMM_H = i2c_temp;	
							if(CV_COMM_H> 0x55)					// CV>22V set VOLTAGE_OR
							{
								if(CV_COMM_L > 0xf0) VOLTAGE_OR = 1;
								else VOLTAGE_OR = 0;
							}else VOLTAGE_OR = 0;
							//
							if(CV_COMM_H == 0x00)				//  CV=0V set VOLTAGE_OR
							{
								if(CV_COMM_L == 0) VOLTAGE_OR = 1;
								else  VOLTAGE_OR = 0;
							} 
						}
						break;
		case 0x16	:	AlarmWarning_H = i2c_temp;
						break;
		case 0x21	:	selstate_ih = i2c_temp;
						UP_SEL_STATE1 = 1;				// terminate automatic mode
						UP_SEL_STATE = 1;				// copy data from selstate_i to SelectorState reg with with masking
						break;
		case 0x22	:	SelectorPresets_H = i2c_temp;
						break;
		case 0x24	:	SelectorInfo_H = i2c_temp;
						break;
		case 0x3c	:	OptMfgFunction1_H = i2c_temp;
						break;
		case 0x3d	:	OptMfgFunction2_H = i2c_temp;
						break;
		case 0x3e	:	OptMfgFunction3_H = i2c_temp;
						break;
		case 0x3f	:	OptMfgFunction4_H = i2c_temp;
						break;
		case 0x2f	:	OptMfgFunction5_H = i2c_temp;
	}

  }
  //---------------------------------------------------------------------------
  if( data_cntr == 0x10)                // sending L byte of requested data 
  {
	switch(cmd)
	{
		case 0x11	:	SSPBUF = ChargerSpecInfo_L; 	
						break;		
		case 0x12	:	SSPBUF = ChargerMode_L; 	
						break;
		case 0x13	:	SSPBUF = ChargerStatus_L; 
						break;
		case 0x14	:	SSPBUF = CC_COMM_L;
						break;
		case 0x15	:	SSPBUF = CV_COMM_L; 
						break;
		case 0x16	:	SSPBUF = AlarmWarning_L; 
						break;
		case 0x21	:	SSPBUF = selstate_ol;
						break;
		case 0x22	:	SSPBUF = SelectorPresets_L;
						break;
		case 0x24	:	SSPBUF = SelectorInfo_L;
						break;
		case 0x3c	:	SSPBUF = flag1;					// OptMfgFunction1_L;
						break;
		case 0x3d	:	SSPBUF = flag3;					// OptMfgFunction2_L;
						break;
		case 0x3e	:	SSPBUF = OptMfgFunction3_L;
						break;
		case 0x3f	:	SSPBUF = OptMfgFunction4_L;
						break;
		case 0x2f	:	SSPBUF = OptMfgFunction5_L;
		default		:	SSPBUF = 0;

	}
 }
  //----------------------------------------------------------------------------
  if( data_cntr == 0x11)                // sending H byte of requested data 
  {
	switch(cmd)
	{
		case 0x11	:	SSPBUF = ChargerSpecInfo_H; 	
						break;		
		case 0x12	:	SSPBUF = ChargerMode_H; 	
						break;
		case 0x13	:	SSPBUF = ChargerStatus_H; 
						break;
		case 0x14	:	SSPBUF = CC_COMM_H;
						break;
		case 0x15	:	SSPBUF = CV_COMM_H; 
						break;
		case 0x16	:	SSPBUF = AlarmWarning_H; 
						break;
		case 0x21	:	SSPBUF = selstate_oh;
						break;
		case 0x22	:	SSPBUF = SelectorPresets_H;
						break;
		case 0x24	:	SSPBUF = SelectorInfo_H;
						break;
		case 0x3c	:	SSPBUF = flag2;					// OptMfgFunction1_H;
						break;
		case 0x3d	:	SSPBUF = btmp1;					// OptMfgFunction2_H;
						break;
		case 0x3e	:	SSPBUF = OptMfgFunction3_H;
						break;
		case 0x3f	:	SSPBUF = OptMfgFunction4_H;
						break;
		case 0x2f	:	SSPBUF = OptMfgFunction5_H;
		default		:	SSPBUF = 0;

	}
  }  
  data_cntr++;
  //
  // -- set flags to indicate which register needs to be updated----
  //
  if(data_cntr == 4)
  {
	switch(cmd)
	{
		case 0x12	:	UP_REQ = 1;				// Charger mode
						UP_CHARGER_MODE= 1;
						break;
		case 0x14	:	UP_REQ = 1;				// charging current
      					UP_I = 1;     
      					ci_received = 1;
						break;
		case 0x15	:	UP_REQ = 1;				// charging voltage
      					UP_V = 1;     
	  					cv_received = 1;
						break;
		case 0x16	:	UP_REQ = 1;	
      					UP_ALARM = 1;  
						break;
		case 0x21	:	UP_REQ = 1;				// selector state
      					//UP_SEL_STATE;     
	}
  }
  //
  ret_from_int = 1;     
  PIR1.SSPIF = 0;                    			// 
  SSPCON.CKP = 1;                     			// release clk
  UCLED_ = 0;
  // INTCON.T0IF = 0;							// reset interrupt flag
}
////////////////////////////////////////////////////////////////////////////
// interrupt generated by H-to-L transient of LOWBAT_ signal
//--------------------------------------------------------------------------
#int_ext
int_external()
{												// external interrupt 
	DM3_ = 0;									// set 3 diode mode
	delay_us(50);


	if(lobat_ && !dm3_ac) DM3_ = 0;
	else
	{ 
		generate_int();							// pull host's int line low for 20ms
		dm3_dc = 1;
	}
	INTCON.INTF = 0;							// reset interrupt flag
}
/////////////////////////////////////////////////////////////////////////////
//	Generates interrupt at H-to-L edge if DCINGOOD signal
//--------------------------------------------------------------------------
#int_rtcc										// TMR0 overflow interrupt
int_TMR0()
{							
	if(!( POWER_BY_A || POWER_BY_B || POWER_BY_C || POWER_BY_D) )	// if power by AC
	{
		
		DM3_ = 0;								// set 3 diode mode
		dm3_ac = 1;
		
	}
	TMR0 = 0xff;								// set TMR0 to overflow-1
	generate_int();								// pull host's int line low for 20ms
	INTCON.T0IF = 0;							// reset interrupt flag
}
