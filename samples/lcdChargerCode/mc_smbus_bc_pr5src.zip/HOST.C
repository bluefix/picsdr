////////////////////////////////////////////////////////////////////////
// copies received word in selstate_i to SelectorState register.
// if the received nibble is 0xf, the appropriate nibble in SelectorState
// register will be unchanged.
//------------------------------------------------------------------------ 
void copy_to_ss(void)
{
	//----------------- L byte ------------------------------------------
	//

// --READ ONLY,  do not overwrite SelectorSate,PRESENT nibble at any condition------
//	
//	btmp1 = selstate_il;						// check if bottom nibbel = 0xf
//	btmp1 = 0x0f &btmp1;
//	if(btmp1 != 0x0f)							// if no, copy received bits 
//	{
//		SelectorState_Lb0 = selstate_ilb0;
//		SelectorState_Lb1 = selstate_ilb1;
//		SelectorState_Lb2 = selstate_ilb2;
//		SelectorState_Lb3 = selstate_ilb3;
//	}
//----------------------------------------------------------------------------------
	btmp1 = selstate_il;					// check if upper nibble = 0xf
	btmp1 = btmp1 & 0xf0;	
	if(btmp1 != 0xf0)						// if no, copy received bits
	{
		SelectorState_Lb4 = selstate_ilb4;
		SelectorState_Lb5 = selstate_ilb5;
		SelectorState_Lb6 = selstate_ilb6;
		SelectorState_Lb7 = selstate_ilb7;
	}
	//---------------------- H- byte ------------------------------
	btmp1 = selstate_ih;					// check if bottom nibbel = 0xf
	btmp1 = btmp1 & 0x0f;
	if(btmp1 != 0x0f)						// if no, copy received bits 
	{
		SelectorState_Hb0 = selstate_ihb0;
		SelectorState_Hb1 = selstate_ihb1;
		SelectorState_Hb2 = selstate_ihb2;
		SelectorState_Hb3 = selstate_ihb3;
	}
	//
	btmp1 = selstate_ih;					// check if upper nibble = 0xf
	btmp1 = btmp1 & 0xf0;	
	if(btmp1 != 0xf0)						// if no, copy received bits
	{
		SelectorState_Hb4 = selstate_ihb4;
		SelectorState_Hb5 = selstate_ihb5;
		SelectorState_Hb6 = selstate_ihb6;
		SelectorState_Hb7 = selstate_ihb7;
	}
}
//////////////////////////////////////////////////////////////////////////////////
// 	SelectorState holds data in 'straight' format
//	in selector_io (aaaa bbbb cccc dddd) bbbb (POWER_BY) is inverted when charging battery
//										 cccc (CHARGE)   is inverted when AC present
//	Host will read 'inverted' data, and it writes 'straight data.
//
//=============================== WRITING TO SelectorState ===============================
//
//                 		selector		copy_to_ss()							holds straight
//                   	input reg.		routine									data ( no nibble)
//                             			checks for 0xf							inversion during
//                         				nibble masking							AC or charging)
//
//  host ---> 	SMBus -> selstate_i  	--------------------------------> 		SelecrorState
//
//    
// ================================READING FROM SelectorState ==============================
//												
//												copy_to_ss_o()
//                                             	invert CHARGE when AC present
//												invert POWER_BY when battery
//												being charged
//	host <---------  	SMBus <- selstate_o 	<----------------------------	SelectorState 
//
//
//
//--------------------------------------------------------------------------------------
void copy_to_ss_o( void)
{
	// -------------------- L byte ----------------------------------
	//
	selstate_olb0 = SelectorState_Lb0;			// this nibble is unchanged
	selstate_olb1 = SelectorState_Lb1;		 	// PRESENT nibble
	selstate_olb2 = SelectorState_Lb2;		 
	selstate_olb3 = SelectorState_Lb3;
	//											// if AC present invert this nibble
	if(AC_PRESENT)							 	// CHARGE nibble
	{
		selstate_olb4 = !SelectorState_Lb4;		
		selstate_olb5 = !SelectorState_Lb5;		 
		selstate_olb6 = !SelectorState_Lb6;		 
		selstate_olb7 = !SelectorState_Lb7;			
	}
	else
	{
		selstate_olb4 = SelectorState_Lb4;	
		selstate_olb5 = SelectorState_Lb5;		 
		selstate_olb6 = SelectorState_Lb6;		 
		selstate_olb7 = SelectorState_Lb7;	
	}
	//
	// --------------------- H byte -----------------------------------------------------------------
	//	

	if(CHARGING_INDICATOR)						// POWER_BY nibble is inverted if battery being charged							 
	{											// POWER_BY
		selstate_ohb0 = !SelectorState_Hb0;		
		selstate_ohb1 = !SelectorState_Hb1;		 
		selstate_ohb2 = !SelectorState_Hb2;		 
		selstate_ohb3 = !SelectorState_Hb3;			
	}
	else
	{
		selstate_ohb0 = SelectorState_Hb0;	
		selstate_ohb1 = SelectorState_Hb1;		 
		selstate_ohb2 = SelectorState_Hb2;		 
		selstate_ohb3 = SelectorState_Hb3;	
	}

	selstate_ohb4 = SelectorState_Hb4;			// copy this nibble unchanged
	selstate_ohb5 = SelectorState_Hb5;		 	// SMB nibble
	selstate_ohb6 = SelectorState_Hb6;		 
	selstate_ohb7 = SelectorState_Hb7;
	//
}
//////////////////////////////////////////////////////////////////////////////
// this functions is for autonomous operation
//---------------------------------------------------------------------------
void conn_system( void)
{
	if(DCINGOOD) DCIN_BAT_ = 1;				// 	if incoming DC ok
	else DCIN_BAT_=0;						//	connect system to AC
	//	
	if(OK_TO_USE_B)	BATSEL = 0;				//	if OK_TO_USE_B
	else
	if(OK_TO_USE_A) BATSEL = 1;		 	
	DM3_ = 1;
}
//////////////////////////////////////////////////////////////////////////////////////
// It connects sytem yo the power source shown in POWER_BY_X nibble.
// If the power source is not O.K. to use (OK_TO_USE_X nibble) it will not switch
// to the requested power source and generates an interrupt.
//------------------------------------------------------------------------------------
void connect_system( void)
{
	delay_cycles(1);

	if( !(POWER_BY_A || POWER_BY_B || POWER_BY_C || POWER_BY_D )) 
	{
		if(DCINGOOD)
		{
			DCIN_BAT_ = 1;
			BATSEL = 1;
			if(auto_mode_flag) DM3_=1;
		}else generate_int();
	}else
	if(POWER_BY_A)							// if power use of battery1 is requested
	{
		if(!OK_TO_USE_A)					//		but battery1 is not ready
		{
			generate_int();					//		interrupt host
			//DM3_ = 0;
		}else
		{
			BATDIS_=1;
			BATSEL = 1;						//		select battery1
			DCIN_BAT_= 0;					//		select battery operation							// 		cancel 3DM operation
			if(auto_mode_flag) DM3_=1;
		}
	}else
	if(POWER_BY_B)							// if power by battery2 is requested
	{
		if(!OK_TO_USE_B)					//		but battery2 is not ready
		{
			generate_int();					//		interrupt host
		}
		else
		{
			BATDIS_ = 1;
			BATSEL =  0;					//		select battery2
			DCIN_BAT_=0;					//		select battery operation
		 	if(auto_mode_flag) DM3_=1;		// 		cancel 3DM operation
		}
	}
}
///////////////////////////////////////////////////////////////////////////////
//  sets INT_ interrupt line to host low for 10msec 
// ----------------------------------------------------------------------------
void generate_int(void)
{
	INT_= 0;								// activate int_ line
	Delay_Ms_4MHz(10);						// wait 10ms
	INT_= 1;								// release int_ line
}

