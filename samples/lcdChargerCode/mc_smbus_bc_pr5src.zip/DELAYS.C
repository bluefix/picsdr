void delay(void)
{
  char i, j, k;                     // software delay, about 1 sec
  for(k=0; k<2; k++)                // measured: 840 msec.
  {
    for(j=0; j<25; j++)             // 255 -> 25
    {
      for(i=0; i<255; i++);         // inner loop delay: 1.647ms
    }
  }
}
// ---------------------------------------------------------------------- 
void delay1( void )
{
  char i,j;
  for(j=0; j<20; j++)
  {
    for(i=0; i<155; i++);           // delay 1ms
  }
}
// --------------------------------------------------------------------
void delay_5us( void )          // 5us delay
{
#asm
  nop
  nop
  nop
  nop
#endasm  
}
//---------------------------------------------------------------------------
void timer0( char a )           // td=(256-a)*256us @ 4MHz (prescaler /256)
{ 
  TMR0 = a;                     // reload load timer
  INTCON.T0IF = 0;              // reset TMR0 interrupt flag
}
///////////////////////////////////////////////////////////////////////////////
// 25 ms hardware delay
//----------------------------------------------------------------------------
void hw_delay(void)
{

		while(!PIR1.TMR1IF);			// wait in loop until timer overflows,
		TMR1L = 0x3b;					// this sets the looperiode to  exactly 25ms
		TMR1H = 0xf6; 
		PIR1.TMR1IF = 0;				
}
/////////////////////////////////////////////////////////////////////////
void Delay_Ms_4MHz(char a)
{
	delay_ms(a);
}
void Delay_10xUs_4MHz( char a)
{
	delay_us(10*a);
}

