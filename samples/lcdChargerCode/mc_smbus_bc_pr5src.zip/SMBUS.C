void clear_smbus( void )
{
  TRISCSDA = 1;                    // set as input
  TRISCSCL = 1;                    // set as input
  //
  PORTCSDA = 0;                    // to pull down SDA line when TRIDCSDA=L  

  SSPCON.SSPEN = 0;                 // configure SDA and SCL pins as i/o pins
  //
  if( !PORTCSCL) goto clsm1;       // SMBus traffic ? jump if yes
  delay_us(5);
  if( !PORTCSCL) goto clsm1;       // SMBus traffic ? jump if yes
  delay_us(5);
  if( !PORTCSCL) goto clsm1;       // SMBus traffic ? jump if yes
  //
  TRISCSDA = 0;                    // SDA ->   ~~~\___    start
  delay_us(20);  
  TRISCSDA = 1;                    // SDA ->   ___/~~~    stop
  //
  clsm1:

  PORTCSDA = 1;
  TRISCSDA = 1;                    // set as input

  TRISCSCL = 1;                    // set as input
  //
  SSPCON.SSPEN = 1;                 // cofigure SDA and SCL as serial port pins 
}

