/////////////////////////////////////////////////////////////////////////
// 	Initialization routine for demo board, Smart Battery Switch
//					
//------------------------------------------------------------------------
void init_var( void )
{
int i;
//
//------INIT TMR0--------------  
//           76543210
  OPTION = 0b00111111;		// init timer 1, pull-up 
                                // bit7 Port B pull-up enable (1=disable)
                                //    6 INTEDG 1=INT on rising of RBO/INT
                                //    5 TOCS TMR0 ck source 0 = internal
                                //    4 TOSE TMRO source edge 1=H->L on RA4
                                // bit3 PSA prescaler assign. 1=WDT, 0=TMR0
                                //  2:1 PS2:PS0 prescaler div. rate 2,4,8,16..
TMR0 = 0xff; 

//--- TMR2 and PWMs ----------
//
  T2CON = 0x04;					// init timer, bit2 turns it on
                                // bit7 unimplemented
                                // bit6:bit3 postscalaer select 1,2,3..16
                                // bit2 TMR2ON 1=TMR2 on 0=TMR2 off
                                // bit1:bit0 prescaler div. 1, 4 or 16
//      
  CCP1CON = 0b00001100;			// init PWM1 
                                // bit7 uninplemented
                                //      unimplemented
                                //      bit1 for 10 bit mode (0 for 8bit)
                                //      bit0 for 10 bit mode (0 for 8bit)
                                // bit3:0 mode select 11xx= PWM mode 
//
  CCP2CON = 0b00001100;			// init PWM2
  
// --- init port A --
  PORTA = 0;					
								// PIN	NAME				DIRECTION	VALUE			
  //        76543210			//---------------------------------------------
  TRISA = 0b00011011;           // RA5  3.32k pull-up for TH1	OUTPUT 		0
 								// RA4	DCINGOOD				INPUT		1
                                // RA3  ANALOG INPUT, used in digital mode	
								// to set SSPADD 				INPUT		1
                                // RA2  TH2 pull-up (3.32k)		OUTPUT		0
                                // RA1  TH1 analog input      	INPUT  		1
                                // RA0  TH2 analog input   		INPUT		1		
// ----init A/D------
  //         76543210
  ADCON0 = 0b01000001;          // Analog digital converter module
                                // bit7 ADCS1   A/D clock select 
                                //      ADCS0   01= fosc/8 -> tconv=16us
                                //      CHS2    channel selection
                                //      CHS1    
                                // bit3 CHS0    000 -> RA0
                                //      GO/DONE_ start conv/finished
                                //      unimplemented
                                //      ADON 1= a/d on 0=a/d off
  //         76543210
  ADCON1 = 0b00000100;          // b7:b3 not implemented
                                // b2:b0 analog port pin config.
                                // 100   RA0=analog  RA1=analog
                                //       RA2=digital RA3=analog, Vref=VDD

// ----init port B---
//
  PORTB  = 12;					
								// PIN	NAME	DIRECTION	VALUE
  //        76543210			//-------------------------------------
  TRISB = 0b00000001;           // RB7  BATDIS_ 		OUTPUT 		0
                                // RB6  DCIN/BAT_ 		OUTPUT		0
                                // RB5 	auto_mode_led   output		0
                                // RB4  INT_       		OUTPUT		0
                                // RB3 	SMBLED_    		OUTPUT		0
                                // RB2 	UCLED_     		OUTPUT		0
                                // RB1 	3DM_			OUTPUT		0
                                // RBO 	INT	(LOBAT_)	INPUT		1
// ----init.port C---

  PORTC = 1;    
  //        76543210 			// PIN	NAME	DIRECTION	VALUE
  TRISC = 0b00011000;			// -------------------------------------
                                // RC7 	CHGSEL 		OUTPUT		0
                                // RC6 	BATSEL 		OUTPUT		0
                                // RC5 	BUSSEL		OUTPUT		0
                                // RC4  SDA 		INPUT		1
                                // RC3 	SCL 		INPUT		1
                                // RC2  VPWM (CCP1) OUTPUT		0
                                // RC1 	IPWM (CCP2) OUTPUT		0
                                // RC0 	CHGEN		OUTPUT   	0

  // -------------------------
  CCPR1L = 10;                  // pulse width1
  CCPR2L = 10;                  // pulse width2
  PR2 = 255;                    // period time 200-> 200us

  //---setting-up I2C communication ----------
  //         76543210
  SSPCON = 0b00110110;      	// sync serial port control register
                            	// B7 WCOL=0    Wirite collision det. (SW reset)                            
                            	//    SSPOV=0   receive collision det (SW reset)
                            	//    SSPEN=1   enable ser port ( SCK SDO open D)
                            	//    CKP = 1   0=enable clock 
                            	// B3:B0 SSPM2:SSPM0=0110 slave mode.
// --- timer interrupts--- 
  
  INTCON = 0;
  INTCON.T0IF = 1;          	// reset TMR0 int flag
  INTCON.T0IE = 0;          	// 1=enable TMR0 interrupt	

  PIE1.SSPIE = 1;           	// enable i2c interrupt
  PIR1.SSPIF = 0;           	// reset i2c interrupt flag
 
  T1CON = 0x01;           		// init TMR1, internal ck, prescaler div=1 

//  for(i = 0; i<16; i++) i2c_data[i] = 0; 	// CLEAR
      
  	ChargerSpecInfo_L = 0x11;		// bit 4-> SELECTOR_SUPPORT  bit3...bit0 -> CHARGER_SPEC  
  	ChargerSpecInfo_H = 0x00;		// reserved

  	ChargerMode_L = 0;
  	ChargerMode_H = 0;

  	ChargerStatus_L = 0x10;       // level 3 charger
  	ChargerStatus_H = 0x00;

  	SelectorState_L = 0x00;
  	SelectorState_H = 0x00;

  	SelectorPresets_L = 0x00;
  	SelectorPresets_H = 0x00; 

  	SelectorInfo_L = 0x13;
  	SelectorInfo_H = 0x0;
	
  	AlarmWarning_L = 0;
  	AlarmWarning_H = 0;

  	OptMfgFunction1_L = 0;
  	OptMfgFunction2_L = 0;
  	OptMfgFunction3_L = 0;
  	OptMfgFunction4_L = 0;
  	OptMfgFunction5_L = 1;				//	OptMfgFunction5_L.0 = AUTO_ENABLE = 1

  	OptMfgFunction1_H = 0;
  	OptMfgFunction2_H = 0;
  	OptMfgFunction3_H = 0;
  	OptMfgFunction4_H = 0;
  	OptMfgFunction5_H = 0;


  	flag1 = 0;
  	flag2 = 0;
  	flag3 = 0;
 	flag3 = 0;
 	flag4 = 0;
 	flag5 = 0;
  	power_on = 1;

  	fast_blinking = 1;
  	i2c_counter =0;                  	// clear i2c data pointer
  	ad_counter = 0;                  	// clear 
	LED_counter = 0;					// UC activity LED
	smbled_counter=0;
  	//
  	//
  	SSPADD = 0x12;                  	// define slave address
  	//
  	CC = 100;
  	CV = 18000;
	//
  	stm_tst = 0;
  	cmd =  0;						// clear command code register
  	data_cntr = 0;					// clear datat counter
  	i2c_temp = 0;					// clear i2c_temp register
  	DM3_ = 1;
   	dm3_ac = 0;
  	dm3_dc = 0; 	
  	UP_SEL_STATE = 0;
  	UP_SEL_STATE1 = 0;
  	BATDIS_=1;

}
////////////////////////////////////////////////////////////////
// initialize voltage and current PWMs.
//--------------------------------------------------------------
void initiv( char a )
{
   if( a==1)
  {
    CC_L = 0x64;           // charging current L byte
    CC_H = 0x00;           //                  H byte
    CV_L = 0xFF;           // charging voltage L byte
    CV_H = 0xFF;           //                  H byte
	CC_COMM_H = CC_H;
	CC_COMM_L = CC_L;
	CV_COMM_H = CV_H;
	CV_COMM_L = CV_L;
  } 
  if( a==0)
  {
    CC_L = 0x32;           // charging current L byte
    CC_H = 0x00;           //                  H byte
    CV_L = 0xFF;           // charging voltage L byte
    CV_H = 0x8F;           //                  H byte
	CC_COMM_H = CC_H;
	CC_COMM_L = CC_L;
	CV_COMM_H = CV_H;
	CV_COMM_L = CV_L;
  } 
  CHGEN = 1;  
  load_pwms();
  // 

}

