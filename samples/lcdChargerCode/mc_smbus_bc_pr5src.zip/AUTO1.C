//////////////////////////////////////////////////////////////////////////
// file:auto1.c
//	set AUTO_ENABLE flag (OptMfgFunction5.0)	
//--------------------------------------------------------------------------
void set_auto_flag(void)
{
	if(AUTO_ENABLE)                 	// OptMfgFunction5_L.0
	{
		auto_mode_flag = 1;
		auto_mode_led = 1;
  		AUTO_MODE 	 = 1;				// OptMfgFunction5_L.1
	}else
	{
		auto_mode_flag = 0;
		auto_mode_led = 0;
  		AUTO_MODE 	 = 10;	
	}
}
////////////////////////////////////////////////////////////////////////////////////
// file:auto1.c
//									set_present	
//-----------------------------------------------------------------------------------
void set_present(void)
{
	// RA1 TH1 amalog input, RA0 TH2 analog input, 	
	ADCON1 = 0x04;						
	//
	// -------------------- measure thermistor 2 -----------------
	//
	ADCON0 = 0x41;							// osc/8 	CH0		ADON=1
	TH2_PU = 1;
	tmp1 = 0;
	//
	Delay_10xUs_4MHz(2);					// wait for settling
	//
	INTCON.GIE = 0;							// sample #1
	ADCON0.GO = 1;
	while(ADCON0.GO);
	INTCON.GIE = 1;
	ADRES>>1;
	tmp1= ADRES;
	//
	INTCON.GIE = 0;							// sample #2
	ADCON0.GO = 1;
	while(ADCON0.GO);
	INTCON.GIE = 1;
	ADRES>>1;
	tmp1= tmp1 + ADRES;
	TH2_PU = 0;
	//
	if(tmp1<220) PRESENT_B = 1;				// if thermistor present set flag 
	else PRESENT_B = 0;
	//
	// -------------------- measure thermistor 1 -----------------
	//
	ADCON0 = 0x49;							// osc/8 	CH1		ADON=1
	TH1_PU = 1;
	tmp1 = 0;
	//
	Delay_10xUs_4MHz(2);					// wait for settling
	INTCON.GIE = 0;							// sample #1
	ADCON0.GO = 1;
	while(ADCON0.GO);
	INTCON.GIE = 1;
	ADRES>>1;
	tmp1= ADRES;
	//
	INTCON.GIE = 0;							// sample #2
	ADCON0.GO = 1;
	while(ADCON0.GO);
	INTCON.GIE = 1;
	ADRES>>1;
	tmp1= tmp1 + ADRES;
	//
	TH1_PU = 0;
	if(tmp1<220) PRESENT_A = 1;				// if thermistor present set flag 
	else PRESENT_A = 0;
}
/////////////////////////////////////////////////////////////////////////
// file:auto1.c
//						read_battery data	
//----------------------------------------------------------------------
void read_battery(void)
{
	short bussel_old;
	char comm_error_cntr = 0;
	long RelativeStateOfCharge_tmp;
	long ChargingVoltage_tmp;
	long ChargingCurrent_tmp;
	long AlarmWarning_tmp;
	//
	if(read_cntr<810)
	{
		read_cntr++;
		return;
	}
	
	// SMBLED_	 = 0;
	delay_ms(5);
	// SMBLED_	 = 1;
	
	read_cntr = 0;
	//
	bussel_old = BUSSEL;
	//
	if(PRESENT_A)
	{
		BUSSEL = 0;													// SMBus to SMBus A
		//
		RelativeStateOfCharge_B1= 	read_smb_device(0x16, 0x0d);
		ChargingVoltage_B1 		= 	read_smb_device(0x16, 0x15);	
		ChargingCurrent_B1 		= 	read_smb_device(0x16, 0x14);	
		AlarmWarning_B1 		= 	read_smb_device(0x16, 0x16);
		//
		if(smb_error) comm_timeout_cntr_B1++;
		else comm_timeout_cntr_B1 = 0;

		//
		if(comm_timeout_cntr_B1 > 8)								
		{
			RelativeStateOfCharge_B1=	0;
			ChargingVoltage_B1 		=	0;
			ChargingCurrent_B1 		=	0;
			AlarmWarning_B1 		=	0;
			comm_timeout_cntr_B1	=   0;
			batt_comm_error			= 	1;
		}
	}else
	{
		RelativeStateOfCharge_B1=	0;
		ChargingVoltage_B1 		=	0;
		ChargingCurrent_B1 		=	0;
		AlarmWarning_B1 		=	0;
	}
	//
	if(PRESENT_B)
	{
		comm_error_cntr = 0;
		BUSSEL = 1;												// SMBus to SMBus B
		//
		RelativeStateOfCharge_B2= 	read_smb_device(0x16, 0x0d);
		ChargingVoltage_B2 		= 	read_smb_device(0x16, 0x15);
		ChargingCurrent_B2 		= 	read_smb_device(0x16, 0x14);
		AlarmWarning_B2 		= 	read_smb_device(0x16, 0x16);
		//
		if(smb_error) comm_timeout_cntr_B2++;
		else comm_timeout_cntr_B2 = 0;
		//
		if(comm_timeout_cntr_B2 > 8)
		{
			//SMBLED_ = 0;
			delay_ms(200);
			//SMBLED_ = 0;
			RelativeStateOfCharge_B2=	0;
			ChargingVoltage_B2 		=	0;
			ChargingCurrent_B2 		=	0;
			AlarmWarning_B2			=	0;
			batt_comm_error			= 	1;
		}
	}else
	{
		RelativeStateOfCharge_B2=	0;
		ChargingVoltage_B2 		=	0;
		ChargingCurrent_B2 		=	0;
		AlarmWarning_B2			=	0;
	}
	//
#ifdef RS232MODE
	printf(" \n\r");
	//
	printf(" cntr: %u\n\r",rs232_cntr);
	rs232_cntr++;
	//
	printf(" Charge B1: %lu",RelativeStateOfCharge_B1);
	printf(" B2: %lu  %%\r\n",RelativeStateOfCharge_B2);
	//
	printf(" Current B1: %lu",ChargingCurrent_B1);
	printf(" B2: %lu  mA\r\n",ChargingCurrent_B2);
	//
	printf(" Voltage B1: %lu",ChargingVoltage_B1);
	printf(" B2: %lu mV\n\r",ChargingVoltage_B2);
	//
	printf(" Charger Io: %lumA ",ChargingCurrent);
	printf(" Vo: %lumV ",ChargingVoltage);
	printf(" I_PWM: %lu\n\r",vdata); 
	//
	
	printf(" AlarmVarning_H= %u ",AlarmWarning_H);
	//
	printf(" DCINGOOD: ");									
	if(DCINGOOD) printf("Y");								// DCINGOOD
	else printf("N");
	printf("\n\r");
	//
	printf(" [SMB][POWER_BY] = %x ",SelectorState_H);
	printf(" [CHARGE][PERSENT] = %x ",SelectorState_L);
	printf("\n\r");
	//
#endif
	//
	BUSSEL = bussel_old; 
}
///////////////////////////////////////////////////////////////////
// file:auto1.c
//						set OK_TO_USE_X nibble
//	RelativeStateOfCharge_B1	RelativeStateOfCharge_B2
//----------------------------------------------------------------
void set_ok_to_use1(void) 
{	
	char tmp1;
	
	tmp1 = read_nibble(SelectorState_L,0);
	switch(tmp1)
	{
		case 0x00 : write_nibble(&SelectorPresets_L,0x00,0);
					break;
		case 0x01 :	write_nibble(&SelectorPresets_L,0x01,0);
					break;
		case 0x02 :	write_nibble(&SelectorPresets_L,0x02,0);
					break;					
		case 0x03 :	{
						if( RelativeStateOfCharge_B1 > 5) OK_TO_USE_A = 1;
						else OK_TO_USE_A = 0;
						if(RelativeStateOfCharge_B2 > 5) OK_TO_USE_B = 1;
						else OK_TO_USE_B = 0;
					}
	}
											
}
/////////////////////////////////////////////////////////////////////////////////
// file:auto1.c
//						set_use_next(void)
//------------------------------------------------------------------------------
void set_use_next(void)
{
	if( !( POWER_BY_A || POWER_BY_B) )									// AC power
	{
		if(OK_TO_USE_A) write_nibble(&SelectorPresets_L, 0x01,1);
		if(OK_TO_USE_B) write_nibble(&SelectorPresets_L, 0x02,1);
	}
	//
	if(POWER_BY_A)
	{
		if(DCINGOOD) write_nibble(&SelectorPresets_L, 0x000,1);
		else if(OK_TO_USE_B) write_nibble(&SelectorPresets_L, 0x02,1);
		
	}
	if(POWER_BY_B)
	{
		if(DCINGOOD) write_nibble(&SelectorPresets_L, 0x000,1);
		else if(OK_TO_USE_A) write_nibble(&SelectorPresets_L, 0x001,1);
	}
	delay_cycles(1);
}
///////////////////////////////////////////////////////////////
// file:auto1.c
//			Set Power_by_X at start-up
//-----------------------------------------------------------
void set_power_by1(void)
{
	char tmp1;
	//
	tmp1 = read_nibble(SelectorPresets_L,0);
	//
	if(DCINGOOD) write_nibble(&SelectorState_H, 0,0);
	else
	if( tmp1 == 0x01) write_nibble(&SelectorState_H, 1,0);
	else	
	if( tmp1 == 0x02) write_nibble(&SelectorState_H, 2,0);
	
	if( tmp1 == 3) write_nibble(&SelectorState_H, 1,0);
	DM3_ = 1;
}
/////////////////////////////////////////////////////////////////////////////
// file:auto1.c
//							set_charge2
//---------------------------------------------------------------------------
void set_charge2(void)
{
	if(!DCINGOOD)
	{
		CHARGE_A = 0;
		CHARGE_B = 0;
		return;
	}
	//
	if( (CHARGE_A && !PRESENT_A) || (CHARGE_B && !PRESENT_B) )  // if attempt to charge non-existent battery
	{															// reset CHARGE_X nibble
		CHARGE_A = 0;
		CHARGE_B = 0;		
		ALARM_INHIBITED = 0;
		batt_comm_error = 0;
	}	
	
	if(!CHARGE_A && !CHARGE_B)									// if no battery is set for charging
	{
		if(PRESENT_A) CHARGE_A = 1;								//  	if present BATT A select BATT A
		else
		if(PRESENT_B) CHARGE_B = 1;								// else if present BATT B select BATT AB
		ALARM_INHIBITED = 0;
		batt_comm_error = 0;
	} else 
	if(CHARGE_A && ( ALARM_INHIBITED ||batt_comm_error ))		// charging A but alarm or comm error
	{
		if(PRESENT_B)
		{
			CHARGE_A = 0;
			CHARGE_B = 1;
			ALARM_INHIBITED = 0;
			batt_comm_error = 0;
		}
	}
	else
	if(CHARGE_B && ( ALARM_INHIBITED || batt_comm_error))
	{
		if(PRESENT_A)
		{
			CHARGE_A = 1;
			CHARGE_B = 0;
			ALARM_INHIBITED = 0;
			batt_comm_error = 0;
		}
	}
}
////////////////////////////////////////////////////////////////////////
// file:auto1.c
//						set_smb1
//----------------------------------------------------------------------
void set_smb1(void)
{
	if(DCINGOOD)
	{
		if(CHARGE_A) write_nibble(&SelectorState_H,0x01,1);
		else write_nibble(&SelectorState_H,0x02,1);
	}else
	{
		if(POWER_BY_A) write_nibble(&SelectorState_H,0x01,1);
		else write_nibble(&SelectorState_H,0x02,1);
	}
}
//////////////////////////////////////////////////////////////////////////
// file:auto1.c
//							set_charging
//-------------------------------------------------------------------------
void set_charging(void)
{
	if(	    AC_PRESENT 
		&	!INHIBIT_CHARGE					// inhibit charge bit is not set
//		&	!ALARM_INHIBITED				// ALARM_INHIBITED is not set
		&	th_contr_charge					// thermistor range allows controlled charge
	  )
	  {
	     if(CHARGE_A)
	  	 {
	  		ChargingCurrent = ChargingCurrent_B1;
	  		ChargingVoltage = ChargingVoltage_B1;
			fast_blinking = 1;
	  	 }else
	  	 if(CHARGE_B)
	  	 {
	  		ChargingCurrent = ChargingCurrent_B2;
	  		ChargingVoltage = ChargingVoltage_B2;
			fast_blinking = 1;
		 }
	  }else
	  {
	  	 ChargingCurrent = 200;
	  	 ChargingVoltage = 18000;
	  }
}
////////////////////////////////////////////////////////////
// file:auto1.c
//					set_hw
//-----------------------------------------------------------
void set_hw(void)
{
	char tmp1;
	//
	if(SMB_A) BUSSEL = 0;
	else BUSSEL = 1;
	
	if(CHARGE_A) CHGSEL =1;
	else CHGSEL = 0;
	
	tmp1 = read_nibble(SelectorState_H,0);
	//
	switch(tmp1)
	{
		case 0x00 :	DCIN_BAT_=1;
					DM3_ = 1;
					break;
		case 0x01 : DCIN_BAT_=0;
					BATSEL = 1;
					DM3_ = 1;
					break;
		case 0x02 : DCIN_BAT_=0;
					BATSEL = 0;
					DM3_ = 1;
					break;	
	}
}
//////////////////////////////////////////////////////////////
// file:auto1.c
//						set_charge_inhibit
//-----------------------------------------------------------
void set_alarm_inhibited(void)
{
	char tmp1;
	char *add_l, *add_h;
	//
	
	if(CHARGE_A)
	{
		tmp1 = read_nibble(*(&AlarmWarning_B1+1),1);
		//
		if(tmp1 !=0) ALARM_INHIBITED = 1;
		else ALARM_INHIBITED = 0;
		AlarmWarning_L = *(&AlarmWarning_B1);
		AlarmWarning_H = *(&AlarmWarning_B1+1);		
		return;		
	}
	if(CHARGE_B)
	{
		tmp1 = read_nibble(*(&AlarmWarning_B2+1),1);
		if(tmp1 !=0) 
		{
			ALARM_INHIBITED = 1;
			CHARGE_A = 0;
			CHARGE_B = 0;
		}
		else 
		{
			ALARM_INHIBITED = 0;
			AlarmWarning_L = *(&AlarmWarning_B2);
			AlarmWarning_H = *(&AlarmWarning_B2+1);
		}
	}
}
//////////////////////////////////////////////////////
// file:auto1.c
//					set_batery_present
//----------------------------------------------------
void set_batery_present(void)
{
	if(CHARGE_A && PRESENT_A) BATTERY_PRESENT = 1;
	else
	if(CHARGE_B && PRESENT_B) BATTERY_PRESENT = 1;
	else BATTERY_PRESENT = 0;
}
