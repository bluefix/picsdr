///////////////////////////////////////////////////////////////////////////////////
// it lights RED (SMBus LED) ater smbus communication for 20 * 25 ms = 500ms
//--------------------------------------------------------------------------------
void red_light(void)
{
	if(ret_from_int	)
	{
		if(smbled_counter < 200)		// if count < limit 
		{
			smbled_counter++;			//		increment counter
			SMBLED_ = 0;				//		turn SMB LED n
		}
		else							// if count > limit
		{
			smbled_counter=0;			// 		reset RED LED timer
			SMBLED_ = 1;				// 		turn SMB LED off
			ret_from_int = 0;			// 		reset interrupt flag
		}
	}
}
//////////////////////////////////////////////////////////
// check DCINGOOD and sets POWER_FAIL and AC_PRESENT bits
//------------------------------------------------------------------------------
//
void set_ac_power_bits(void)
{
	if(DCINGOOD)
	{ 
		POWER_FAIL = 0;
		AC_PRESENT = 1;
	}else
	{
		POWER_FAIL=1;
		AC_PRESENT = 0;
	}	
}

