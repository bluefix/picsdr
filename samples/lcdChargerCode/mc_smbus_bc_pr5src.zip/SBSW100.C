//---------------------------------------------------------------------------
//                             SBSW100.C               Version: 1.00 	01/23/98
//                        By: Laszlo Kiraly
//                        KAD Electronics
//           663 S, Bernardo Ave. Sunnyvale CA 94087
//          Phone: (408) 432-1900,  Fax: (408) 434-0507 
//		Email:kadelectro@aol.com, homepage: members.aol.com/kadelectro
/* ------------------------------------------------------------------------------------
		Description:	"C" source code for Smart Battery Selector.
		COMmpiler :		Custom Computer Services CPM Compiler
						Custom computer Sevices: 	
						P.O. Box 2452, Brookfield, WI 53008
						Tel: (414) 781-2794 x30, Fax:(414) 781-2708
		Emulator head: 	PROBE-16T	(for PIC16C76)
------------------------------------------------------------------------------------- */
//
//
/* --------------------------------------NOTES----------------------------------------
	1.	USE PROBE-16T	(for PIC16C76)
	2.	04/01/98	Charging Current is limited to 1A for the testing 	PWM.C line 29
	3. 	04/22/98 	Floating point scaling had been replacec by integer scaling.
					No floating point routines are used in the program anymore.
					
-------------------------------------------------------------------------------------*/
#case
//#define RS232MODE				// mark this line out if no RS232 communication is required
#include "16c76.h"

//#FUSES HS, NOWDT, PROTECT

#include "16c73p.h"
#include "sbsw.h"
#include "smb_comm.h"		
#include "nibble.h"
char stm_tst;
//
long smb_in;
long int idata;
long vdata;
char  rs232_cntr = 0;
#use delay(clock=4000000)
#use i2c(SLAVE, SDA=PIN_C4, SCL=PIN_C3, ADDRESS=0x12, SLOW)

#ifdef RS232MODE
#use rs232(baud=4800,xmit=PIN_b3,rcv=PIN_b2)				//	<- for RS232 operation
#endif
//
#include "int.c"											// interrupt routines
//
// ----------------------------------------------------------- 
void main()
{
  	init_var();                      	// initializes variables (hardware setup)

#ifndef RS232MODE
  	SMBLED_=0;
	delay_ms(250);
	delay_ms(250);
	delay_ms(250);
	delay_ms(250);	
  	SMBLED_=1;
#endif

  	//
  	//====================================================================
  	disable_interrupts(GLOBAL);			// disable interrupts
  	enable_interrupts(INT_SSP);			// enable i2c interrupt
  	enable_interrupts(RTCC_ZERO);		// enable tmr0 interrupt           
  	//enable_interrupts(EXT_INT);		// enable external interrupt -> LOBAT_ signal	
  	enable_interrupts(GLOBAL);			// enable interrupts

  	setup_counters(RTCC_EXT_H_TO_L, WDT_2304MS);
  	set_rtcc(0xff);
  	setup_timer_1(0x01);
  	setup_adc(ADC_CLOCK_DIV_2);
 	//===========================================================================
  	initiv(1);                      // call pwm initialization routine
   	//
	set_auto_flag();
	//
  	////////////////////////////////////////////////////////////////////////////////
  	while(1)                        // infinite loop in MAIN
  	{ 
		hw_delay();					// loop delay: 25 ms
		inc_prescaler();
		//
#ifndef RS232MODE
    	red_light();				// turn red LED on if ret_from_int flag is set
    	cif_led();					// check if LED needs to be toggled
#endif
		//
    	cif_therm();				// check if thermistor needs to be measured (ad_counter)
		//
		//
    	// -------------- if the selector is in automous mode ------------------------------
		//
		if(auto_mode_flag)			// if the flag is set
		{
			set_present();			// measure thermistors in B1 and B2, sts present flags			
			read_battery();
 			set_ok_to_use1();		// sets OK_TO_USE_X nibble using RelativeStateOfCharge
			set_use_next();			// ac->A->B depends on OK_TO_USE_x

			set_power_by1();		// set POWER_BY_X nibble  (AC-> batt1->batt2)
			set_charge2();			// selects battery to charge (A->B->A.. if present)
 			set_smb1();				// check POWER_BY_X and connect set SMB_X nibble the same
			set_hw();				// sets hardware (io port bits)
			set_alarm_inhibited();	// sets alarm_inhibited bit
			set_charging();			// sets charging current (controlled charge, trickle charge)
			load_ipwm();			// loads charging current PWM
			load_vpwm();			// loads charging voltage PWM

		}
		set_ac_power_bits();		// check if AC presentset AC_PRESENT and POWER_FAIL
  	}
  
}  // ------------------------ end of main --------------------------------------
//
//////////////////////////////////////////////////////////////////////////////
#include "check_if.c"
#include "smbus.c"						// clear_smbus() 
#include "therm.c"						// th_ad rouine
#include "pwm.c"						// load_vpwm()  load_ipwm()
#include "delays.c"						// checks system while provides delay
#include "init.c"						// initializes registers, ports, counters etc.			
#include "smb_comm.c"					// SMBus communication routines
//
#include "auto1.c"
#include "host.c"
#include "common.c"

