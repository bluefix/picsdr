

                                    AVR-CDC


    This is the Readme file to firmware-only CDC driver for Atmel AVR
    microcontrollers. For more information please visit
    http://www.recursion.jp/avrcdc/


SUMMARY
=======
    The AVR-CDC performs the CDC (Communication Device Class) connection over
    low-speed USB. It provides the virtual RS-232C interface without installing
    dedicated driver. The AVR-CDC is originally developed by Osamu Tamura.
    Akira Kitazawa has significantly contributed to improve this software. 


SPECIFICATION
=============
    AVR-CDC with USART (ATmega8/48/88/168)
        speed:    1200 - 19200bps
        datasize: 5-8
        parity:   none/even/odd
        stopbit:  1/2

    AVR-CDC without USART (ATtiny45/85)
        speed:    1200 - 4800bps
        datasize: 8
        parity:   none
        stopbit:  1
        supply current: 8-12mA

    Without USART, some characters will be corrupted if full-duplex transaction
    continues long in high baud rate. Slower speed is recommended.

    Internal RC Oscillator is calibrated at startup time. It may be unstable 
    after a long time operation (ATtiny45rc).

    The actual transfer rate depends upon the terminal software strongly.
    On Windows, HyperTerminal sends one character at a time for every packet.
    Therefore, the transmission speed is one character/mSec at the maximum.

    Although the CDC is supported by Windows 2000/XP/Vista, Mac OS 9.1/X,
    and Linux 2.4, CDC on low-speed USB is not allowed by the USB standard.
    Use AVR-CDC at your own risk.


USAGE
=====
    [Windows XP/2000]
    When you connect with a USB port first, a "Driver Setup Dialog" appears.
    Specify the folder in which "avrcdc.inf" exists, without searching
    automatically. Although it is warned that the driver is not certified,
    confirm it. It only loads Windows' built-in "usbser.sys". Then, the
    virtual COM port appears.
 
    [Windows Vista]
    Specify the folder in which "lowbulk.inf" exists. It loads both
    "usbser.sys" and "lowbulk.sys".

    [Mac OS X]
    You'll see the device /dev/cu.usbmodem***.

    [Linux]
    The device will be /dev/ttyACM*.
    Linux 2.6 does not accept low-speed CDC without patching the kernel.


DEVELOPMENT
===========
    Build your circuit and write firmware (cdcmega*.hex/cdctiny*.hex) into it.
    C1:104 means 0.1uF, R3:1K5 means 1.5K ohms. Modify CLK in Makefile to use
    other clocks.

    Fuse bits
                          ext  H-L
        ATtiny45/85        FF 6E-FF     (HVSP)
        ATtiny45rc/85rc    FF CE-F1
        ATmega8               9F-FF
        ATmega48/88/168    FF CE-FF

    You can use ISP programmer, except for ATtiny X'tal version. It requires
    the High Voltage Serial Programming (HVSP).
    The code size of AVR-CDC is about 3KB, and 128B RAM is required at least.

    This driver has been developed on AVR Studio 4.14 and WinAVR 20080610.
    If you couldn't invoke the project from cdc**.aps, create new GCC project
    named "cdctiny" or "cdcmega" under "avrcdc/" without creating initial
    file. Select each Makefile at "Configuration Options".

    There are several options you can select in Makefile.
    MCU         Select MCU type.   
    CLK         Select clock. 16.5MHz is the internal RC oscillator. (ATtiny)
                3.3V Vcc may not be enough for the higher clock operation.
                Consider 5.0V version instead.
                See http://avrusb.wikidot.com/hardware for details.
    INVERT      Reverse the polarity of TXD and RXD to connect to RS-232C
                directly (ATtiny).
    INTERRUPT   Using RxD interrupt achieves the higher transfer rate, but
                it causes obstacle in USB communication.
                Try this if the USB connection is stable. (ATmega)


    Rebuild all the codes after modifying Makefile.

    If the connection is unstable, try other USB-Hub or PC, or make the maximum
    packet size smaller in main.c,
    line 27.    
	#define HW_CDC_BULK_OUT_SIZE     7 or less


USING AVR-CDC FOR FREE
======================
    The AVR-CDC is published under an Open Source compliant license.
    See the file "License.txt" for details.

    You may use this driver in a form as it is. However, if you want to
    distribute a system with your vendor name, modify these files and recompile
    them;
        1. Vendor String in usbconfig.h
        2. COMPANY and MFGNAME strings in avrcdc.inf/lowbulk.inf 



    Osamu Tamura @ Recursion Co., Ltd.
    http://www.recursion.jp/avrcdc/
    26 June 2006
    7 April 2007
    7 July 2007
    27 January 2008
    25 August 2008

