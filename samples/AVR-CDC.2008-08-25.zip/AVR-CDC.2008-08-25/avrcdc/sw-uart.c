/* Name: sw-uart.c
 * Project: AVR USB driver for CDC interface on Low-Speed USB
 * Author: Osamu Tamura
 * Creation Date: 2006-06-22
 * Tabsize: 4
 * Copyright: (c) 2006 by Recursion Co., Ltd.
 * License: Proprietary, free under certain conditions. See Documentation.
 *
 *  2006-07-10 software-UART interrupt handling time reduced.
 */

/*
    General Description:
*/

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>   /* needed by usbdrv.h */
#include "oddebug.h"
#include "uart.h"
#include "usbdrv.h"

#if !UART_CFG_HAVE_USART

extern uchar    bit_reverse( uchar x );

/* UART buffer */
uchar    urptr, uwptr, irptr, iwptr;
uchar    rx_buf[RX_SIZE], tx_buf[TX_SIZE];


void uartInit(ulong baudrate, uchar parity, uchar stopbits, uchar databits)
{

    PRR     = (1<<PRADC);
    ACSR    = (1<<ACD);


    UART_DDR    |= (1<<UART_CFG_TXD);
    UART_DDR    &= ~(1<<UART_CFG_RXD);

    GIMSK    &= ~(1<<PCIE);
    TCCR0A   = 0;
    TCCR0B   = 0;
    TCCR1    = 0;

	USISR   = 0xe0;		          /* clear all interrupt flags */
	USICR   = (1<<USIOIE)|(1<<USIWM0)|(1<<USICS0);	/* 3 wire mode       */

#if INVERT
	USIDR   = 0;
#else
	USIDR   = 0xff;
#endif

    OCR0A    =
    OCR1A    = (F_CPU>>6) / (unsigned int)baudrate - 1;
    OCR1C    = 0;
    RX_DELAY = -(OCR1A>>1);       /* 1.5 sample bit */

    TCCR0A   = 2;                 /* CTC */
    RX_READY = 1;
    TIMSK    = (1<<OCIE1A);

    PCMSK    = 1<<UART_CFG_RXD;   /*  PCINTn  */
    GIMSK    |= (1<<PCIE);
}

void uartPoll(void)
{

    /* receive data     */
    if( RX_READY==0 ) {
        RX_READY     = 1;
        uartRxBufAppend( EEDR );
    }

    /*  transmit data   */
    if( irptr!=uwptr && TCCR0B==0 ) {
        uchar       data;

        data    = bit_reverse( tx_buf[irptr] );
        irptr   = (irptr+1) & TX_MASK;

        TCNT0   = 0;
		USISR   = 0x4b;						/* interrupt at D4  */
        EEARL   = 0;  	    				/* usi_phase  */

#if INVERT
		OCR0B   = ~((data<<4) | 0x0f);
#else
		OCR0B   = ((data<<4) | 0x0f);	    /* D4-7, stop bit   */
#endif
        cli();
#if INVERT
		USIDR   = ~(data>>1);
#else
		USIDR   = (data>>1);				/* startbit, D0-3   */
#endif
        TCCR0B  = 3;                        /* start timer0: 1/64 clk */
        sei();

        /*    usb -> rs232c:  ready to receive?    */
        if( usbAllRequestsAreDisabled() && uartTxBytesFree()>8 ) {
            usbEnableAllRequests();
        }
    }
}

uchar uartRxIsBusy(void)
{
    return OCR1C;
}

#endif      /* UART_CFG_HAVE_USART */


