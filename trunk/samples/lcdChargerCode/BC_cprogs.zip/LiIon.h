/****************************************************************************
	
    Device      : AT90S4433

    File name   : LiIon.h

    Ver nr.     : 1.1

    Description : Header file for LiIon.c containing the battery specific 
                  definitions
                 
   Compiler    : GCC 3
   
   Author      : Asmund Saetre / Terje Frostad / Dietmar Koenig
                 Modified for GCC by Don Carveth 
 
    Change log  : 02.02.2000 Changed to fit Battery Charger refrence 
                  design board   AS  
                  16.05.2000 Final test and review AS
 
****************************************************************************/

// Include Files
//***************************************************************************
#include <io.h>
#include <stdlib.h>
#include <sig-avr.h> 
#include <interrupt.h> 
#include <string-avr.h>
#include <ctype.h>

// Function prototypes 
//***************************************************************************
void FAST_charge(void);
void TRICKLE_charge(void);
void GetBatteryData(void);
void printout(int x);
unsigned char GetSmartBattery(void);
void PrintSmartBattery(void);
void PrintSBEveryX(int X);

// NOTE:  Battery specifics (CELLS, CAPACITY, LiIon_CELL_VOLT) are
//        defined in routine GetBatteryData() in LiIon.c

#define	LiIon				  // Lithium-Ion	battery	

// ADC step
//***************************************************************************
// ADC voltage step	according to resistors at ADC voltage measurement input
// mV x 100
#define	VOLTAGE_STEP	1724    
// ADC current step	according to resistors on ADC current measurment input
// mA x 100   
#define	CURRENT_STEP	226	

// Define Charger Max Current
//***************************************************************************
#define CHARGER_MAX_CURRENT   2000	

// Battery Characteristics: General charge TERMINATION
//***************************************************************************
// Absolute minimum TEMPERATURE = 5C  - Raw Analog value
#define  MIN_TEMP_ABS   711		
// Absolute maximum TEMPERATURE = 40C  - Raw Analog value
#define  MAX_TEMP_ABS   373         
// Absolute Maximum Charge VOLTAGE = CELLS * cell VOLTAGE * scale factor
//#define  MAX_VOLT_ABS    (unsigned int)((100*CELLS * LiIon_CELL_VOLT)/ VOLTAGE_STEP)  
     
// Battery Characteristics:FAST charge TERMINATION     
//***************************************************************************
// Minimum CURRENT threshold = 50mA per cell
//#define  MIN_I_FAST  (unsigned int)((CELLS * 5000)/ CURRENT_STEP)
// time DELAY after "MIN_I_FAST" is reached = 30min
#define  FAST_TIME_DELAY     0x1E

// Battery Characteristics:TRICKLE charge TERMINATION     
//***************************************************************************
// Maximum TRICKLE Charge Time = 1.5C = 90min    					
#define  MAX_TIME_TRICKLE  0x5A
  
// Battery Characteristics: FAST charge ERROR
//***************************************************************************
// Minimum FAST Charge TEMPERATURE 10C
#define  MIN_TEMP_FAST  0x0296          	
// Maximum FAST Charge Time = 1.5C = 180 min at .5C CURRENT  
#define  MAX_TIME_FAST  0xB4               
        
// Battery Characteristics: General Charge conditions
//***************************************************************************
// VOLTAGE tolerance = CELLS * 50mV * scale factor
//#define  VOLT_TOLERANCE (unsigned int)((CELLS * 5000)/ VOLTAGE_STEP)            
// FAST Charge CURRENT = 1C (in mA, with 1.966mA per bit)
//#define  I_FAST      (unsigned int)(100 * CAPACITY / CURRENT_STEP)               
// TRICKLE Charge CURRENT = 0.025C (in mA, with 1.966mA per bit)
//#define  I_TRICKLE   (unsigned int)((CAPACITY * 2)/ (CURRENT_STEP * 5))
//FAST Charge voltage is defined in bc_def.h
#define  VOLT_FAST LiIon_CELL_VOLT
/* TRICKLE Charge voltage is defined in bc_def.h 
CURRENT = 0.025C (in mA, with 1.966mA per bit)*/
#define  VOLT_TRICKLE  LiIon_CELL_VOLT

//flash char ntc_c[12]={5,4,6,4,5,5,5,5,5,6,4,5};
//char ntc_c[12]={5,4,6,4,5,5,5,5,5,6,4,5};

#define CUSTOM              bit_is_clear(PIND, 4)
#define CELL_VOLTS_SWITCH   bit_is_clear(PINC, 0)
