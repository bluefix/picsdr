/*
  SWSerialLCDPHA.cpp - Software serial to Peter Anderson controller chip based
  LCD display library Adapted from SoftwareSerial.cpp (c) 2006 David A. Mellis
  by Brian B. Riley, Underhill Center, Vermont, USA, July 2007

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/******************************************************************************
 * Includes
 ******************************************************************************/

#include "WConstants.h"
#include "SWSerialLCDPHA.h"

/******************************************************************************
 * Definitions
 ******************************************************************************/

/******************************************************************************
 * Constructors
 ******************************************************************************/

SWSerialLCDPHA::SWSerialLCDPHA(uint8_t transmitPin)
{
  _transmitPin = transmitPin;
  _baudRate = 0;
}

/******************************************************************************
 * User API
 ******************************************************************************/

void SWSerialLCDPHA::begin(long speed)
{
  _baudRate = speed;
  _bitPeriod = 1000000 / _baudRate;

  digitalWrite(_transmitPin, HIGH);
  delayMicroseconds( _bitPeriod); // if we were low this establishes the end
}

void SWSerialLCDPHA::print(uint8_t b)
{
  if (_baudRate == 0)
    return;
    
  int bitDelay = _bitPeriod - clockCyclesToMicroseconds(50); // a digitalWrite is about 50 cycles
  byte mask;

  digitalWrite(_transmitPin, LOW);
  delayMicroseconds(bitDelay);

  for (mask = 0x01; mask; mask <<= 1) {
    if (b & mask){ // choose bit
      digitalWrite(_transmitPin,HIGH); // send 1
    }
    else{
      digitalWrite(_transmitPin,LOW); // send 1
    }
    delayMicroseconds(bitDelay);
  }

  digitalWrite(_transmitPin, HIGH);
  delayMicroseconds(bitDelay);
}

void SWSerialLCDPHA::print(const char *s)
{
  while (*s) {
    print(*s++);
    delay(1);
  }
}

void SWSerialLCDPHA::print(char c)
{
  print((uint8_t) c);
}

void SWSerialLCDPHA::print(int n)
{
  print((long) n);
}

void SWSerialLCDPHA::print(unsigned int n)
{
  print((unsigned long) n);
}

void SWSerialLCDPHA::print(long n)
{
  if (n < 0) {
    print('-');
    n = -n;
  }
  printNumber(n, 10);
}

void SWSerialLCDPHA::print(unsigned long n)
{
  printNumber(n, 10);
}

void SWSerialLCDPHA::print(long n, int base)
{
  if (base == 0)
    print((char) n);
  else if (base == 10)
    print(n);
  else
    printNumber(n, base);
}

// -------- PHA unique codes -------------------------
void SWSerialLCDPHA::println(void)
{
  print("?n");
  delay(10);
}

void SWSerialLCDPHA::clearscr(void)
{
  print("?f");
  delay(100);
}

void SWSerialLCDPHA::setgeo(int geometry)
{
  print("?G");
  print(geometry);
  delay(200);
}

void SWSerialLCDPHA::setintensity(int intensity)
{
  print("?B");
  if (intensity < 16)
  	print('0');
  print(intensity, 16);
  delay(200);
}

void SWSerialLCDPHA::intoBignum(void)
{
  print("?>3");
}

void SWSerialLCDPHA::outofBignum(void)
{
  print("?<");
}


void SWSerialLCDPHA::setxy(int x, int y)
{
  print("?y");
  print(y);	
  print("?x");
  if (x < 10)
    print('0');
  print(x);
  delay(10);
}


void SWSerialLCDPHA::println(char c)
{
  print(c);
  println();  
}

void SWSerialLCDPHA::println(const char c[])
{
  print(c);
  println();
}

void SWSerialLCDPHA::println(uint8_t b)
{
  print(b);
  println();
}

void SWSerialLCDPHA::println(int n)
{
  print(n);
  println();
}

void SWSerialLCDPHA::println(long n)
{
  print(n);
  println();  
}

void SWSerialLCDPHA::println(unsigned long n)
{
  print(n);
  println();  
}

void SWSerialLCDPHA::println(long n, int base)
{
  print(n, base);
  println();
}

// Private Methods /////////////////////////////////////////////////////////////

void SWSerialLCDPHA::printNumber(unsigned long n, uint8_t base)
{
  unsigned char buf[8 * sizeof(long)]; // Assumes 8-bit chars. 
  unsigned long i = 0;  	

  if (n == 0) {
    print('0');
    return;
  } 

  while (n > 0) {
    buf[i++] = n % base;
    n /= base;
  }

  for (; i > 0; i--)
    print((char) (buf[i - 1] < 10 ? '0' + buf[i - 1] : 'A' + buf[i - 1] - 10));
  
  delay(8);
  
}
