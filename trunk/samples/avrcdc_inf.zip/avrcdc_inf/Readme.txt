

                                lowbulk.sys


    This is the Readme file about a patch driver for using low-speed CDC
    protocol on Windows Vista. For more information please visit
    http://www.recursion.jp/avrcdc/lowbulk.html


SUMMARY
=======
    The lowbulk.sys performs the CDC (Communication Device Class) connection
    over low-speed USB on Windows Vista. It is a tiny filter driver to enable
    bulk transfer on low-speed devices. It resides between "usbser.sys" and the
    USB port driver, and it helps configuring bulk pipes for low-speed device
    when connected. It just passes through the packets between the layers at
    other times.
    
    The lowbulk.sys is developed by Osamu Tamura.


SPECIFICATION
=============
    Platform:	Windows Vista (32bit). It works with "usbser.sys".
    Function:	Enables configuring the bulk endpoints on low-speed devices.
    Structure:	Kernel mode driver
    Size:       5,632 bytes
    
    This patch works as follows:
      Step 1. Configures the interrupt pipes instead of bulk pipes.
      Step 2. Reforms the interrupt pipes to the bulk pipes after the endpoints
              were generated.

    This driver is designed for AVR-CDC, and may not work properly on other
    "low-speed bulk" devices.

    CDC on low-speed USB is not allowed by the USB standard. Use lowbulk.sys at
    your own risk. 


USAGE
=====
    Install the virtual COM/CDC protocol interface driver.
        Connect AVR-CDC device and follow the dialog instructions.
        Indicate "inf/vista/" folder to install "usbser.sys" and "lowbulk.sys".

        /inf -- /vista  -- lowbulk.inf
                        -- lowbulk.sys
             -- /xp2k   -- avrcdc.inf    <-- setup file for Windows XP/2000 


DEVELOPMENT
===========
    This driver has been developed on WinDDK 6001.18001 and was based on the
    sample (src/general/toaster/filter/devlower).
    Copy the source code into /src and build it under the WinDDK environment.


USING lowbulk.sys FOR FREE
======================
    The lowbulk.sys is published under an Open Source compliant license.
    See the file "License.txt" for details.


    Osamu Tamura @ Recursion Co., Ltd.
    http://www.recursion.jp/avrcdc/lowbulk.html
    15 July 2008

