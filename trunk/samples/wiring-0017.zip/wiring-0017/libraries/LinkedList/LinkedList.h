#ifndef LinkedList_h 
#define LinkedList_h 
 
#include "WConstants.h" 
 
class LinkedList 
{ 
  public: 
    struct NODE { 
       NODE* pNext; 
       NODE* pPrev; 
       int address; 
       int color; 
       int size; 
     int x; 
     int y; 
       int rotation; 
       long timestamp; 
    }; 
    struct LIST { 
       NODE* pHead; 
       NODE* pTail; 
    }; 
    struct LIST* pList; 
    LinkedList(); 
    void TestList(); 
    struct NODE* NewNode(); 
    void AppendNode(NODE* pNode); 
    void RemoveNode(NODE* pNode); 
    bool RemoveNode(int address); 
    void DeleteAllNodes(); 
    void DisplayAllNodes(); 
    struct NODE* GetHead(); 
    struct NODE* GetTail(); 
    struct NODE* FindNode(int address); 
   
  private: 
    void CreateList(); 
 
}; 
 
#endif 

