#include "WProgram.h"
//   This is the Arduino code for the ArduPilot open source autopilot. See DIYdrones.com for more information.
//   Written by Chris Anderson, 2008
//   Released under a Creative Commons "Attribution" license. 
//   This program is Open Source and can be modified and distributed freely. However the original credits and diydrones.com link must be retained. 
//   Some code taken from Arduino libraries. Thanks also to Jordi Munoz for the NMEA parser and Steer subroutine.

 #include <Servo.h>
 #include <math.h>
 #include <string.h>
 #include <ctype.h>
// #include <SoftwareSerial.h>
//  Waypoints, in Lat (dd.mmmmmm), Lon (ddd.mmmmmm) format. Put in as many or as few as you want, memory allowing. Set
//  the size of the array to the number of waypoints . Set TotalWaypoints to the number of waypoint you've entered. Maybe someday we'll have some cool way to load waypoints from a file on a SD card. Who knows...


void setup();
void loop();
void altitudeHold();
void GPS(int NMEAtype);
void convertNMEA(int NMEAtype);
void Navigation();
void GetProximity();
void Steer();
float Waypoint [10][2]  = {
        {0,0},     // Always leave this one blank, since it will be set to our home position when we turn on the autopilot
        {37.243528, 122.325361},
        {37.2455720, 122.324309},
        {37.252553, 122.317207},
        {37.240995, 122.317936},
        {0,0},
        {0,0},
        {0,0},
        {0,0},
        {0,0},
    };

const int TotalWaypoints = 5;  // adjust this according to how many waypoints you've got

//  Definitions:
#define Switchpin PD3 // pin that the Channel 5/6 autopilot control switch is connected to
#define Servo1pin 5 // output pin for the rudder
#define Servo2pin 6 // output pin for the throttle
#define Channel2pin PD4 // input pin for the throttle channel

Servo RudderServo;
Servo ThrottleServo;

byte pinState = 0;


unsigned long  InitialThrottle;
unsigned long Throttle;
unsigned long LastThrottle;
unsigned long time1;
unsigned long time2;
float InitialAltitude;
float LastAltitude;
float Altitude;
float HomeLat;
float HomeLon;
float WayLat;
float WayLon;
long DeltaLat = 0;
long DeltaLon = 0;
float Heading;
float TargetAngle;
int Rudder;
int CurrentRudder = 0;
int CurrentWaypoint = 1;
boolean correctNMEA = false;
boolean timer;
boolean stop;
boolean stop2;

//////////
char byteGPS=0;
char line[300] = "";
char commandGPRMC[6] = "GPRMC"; // To id the NMEA sentence GPRMC
char commandGPGGA[6] = "GPGGA"; // To id the NMEA sentence GPGGA
int counter=0;
int counter2 = 0;
int cont=0;
int good=0;
int indices[13];
long Latitude=0; // Latitude read by GPS device
long Longitude=0; // Longitude read by GPS device
unsigned int DestinationDir =0; // Course of target destination
unsigned int Distance =0; //  Distance in meter to our objective
unsigned int Temp = 0;
int Velocity = 0; //  Speed in nautical miles (knots)
int RealCourse = 0; //   Real course of the "airplane", read by GPS


/////////////////////////////////////////

void setup() {

// Set pinouts to outputs

pinMode (Switchpin, INPUT);
pinMode (Servo1pin, OUTPUT);
pinMode (Servo2pin, OUTPUT);

Serial.begin(4800);  // open up the serial ports for debugging text
RudderServo.attach(PD3); // Rudder servo is connected to PD3
RudderServo.setMaximumPulse(2000);
RudderServo.setMinimumPulse(700);
ThrottleServo.attach(PD4); // Throttle ESC is connected to PD4
ThrottleServo.setMaximumPulse(2000);
ThrottleServo.setMinimumPulse(700);
for (int i=0;i<300;i++){       // Initialize a buffer for received GPS data
     line[i]=' ';}
}
void loop() {
// Watch channel 5/6 (switchpin) to see if the autopilot's been turned on
//   If autopilot has been turned on, grab the current throttle and current altitude, and do the following loop
//      Go to Nav subroutine
//      Go to Altitude subroutine
//      Repeat...
Serial.println("Main loop");  // for debugging
if (digitalRead (Switchpin) == HIGH) // Autopilot turned on. Grab some initial readings and start flying autonomously...
  {    
    InitialThrottle = pulseIn (Channel2pin, HIGH); //grab the current throttle setting
    LastThrottle = InitialThrottle;
    GPS (2);  //grab the current altitude
    InitialAltitude = Altitude;
    GPS (1); // grab the current lat and lon ("home")
    HomeLat = Latitude;
    HomeLon = Longitude;
    Waypoint [0][0] = HomeLat; // set the first waypoint to the home position
    Waypoint [0][1] = HomeLon;  
    Serial.println("Second loop");  // for debugging
    while (digitalRead (Switchpin) == HIGH) // just keep looping here, maintaining altitude and hitting waypoints, until we turn the autopilot off
      {    
        Navigation();   // Steer to the next waypoint
        altitudeHold();  // Maintain altitude
        Serial.println("Third loop");  // for debugging
      }
  }
} 


void altitudeHold()
{
 // Compare running average with initial altitude
 // If low, bump up the throttle by ~10%
 // If high, bump down the throttle by ~10%
 Serial.println("Altitude loop"); 
 GPS(2);
 if (Altitude > LastAltitude + 20) {GPS(2);} // probably bad data--try again
 if (Altitude < LastAltitude - 20) {GPS(2);} // probably bad data--try again
 if (Altitude < InitialAltitude - 3) // the plane is sinking -- bump up the throttle 
   {
     Throttle = LastThrottle + 100;
     ThrottleServo.write(Throttle); 
     LastThrottle = Throttle; 
   } 
 if (Altitude > InitialAltitude + 3) // the plane is rising -- bump down the throttle 
   {
     Throttle = LastThrottle - 100;
     ThrottleServo.write(Throttle);
     LastThrottle = Throttle;
   } 
 Servo::refresh();
}  

// This subroutine reads GPS sentences, spots the one we're looking for [either GPRMC (case 1) or GPGGC (case 2)]and hands over to a NMEA parser

void GPS(int NMEAtype)
  {
  time1 = millis();
  time2 = time1;
  stop = false;
  good = 0;
  while (!stop && (time2-time1 < 1000)) // loop until you've found the string you're looking for or have run out of time
    {  
    time2 = millis();
    if (time2-time1 > 999) {Serial.println("Timed out!");}  
    if (Serial.available()>0) 
        {
          byteGPS = Serial.read();
        if (byteGPS == 13) {Serial.println("");}
        if (byteGPS > 32) // only print printable characters
          {
          Serial.print(byteGPS); // for debugging
          }
         } else {delay (5);}  
    if (byteGPS == 36)  // if you've reached a "$"
      {
      Serial.println(""); 
      good = 0;
      for (int i=1; i<6;i++)
        {
        if (Serial.available()>0) 
          {
            line[i] = Serial.read();
          } else {delay (5);}
         delay (5);  // here to get serial timings right, to compensate for the slow GPS baud rate
         if (NMEAtype == 1)
          {   
           if (line[i] == commandGPRMC[i-1])
              {
               good++;
              }
          }   
         if (NMEAtype == 2)
          {   
           if (line[i] == commandGPGGA[i-1])
              {
               good++;
              }
          }
        }   
      }
      if (good == 5)   // you've found the string you're looking for, now get the rest of it
        {
        counter = 5;
        if (NMEAtype == 1) {Serial.print("GPRMC");} // for debugging
        if (NMEAtype == 2) {Serial.print("GPGGA");} // for debugging
        stop2=false;
        while (!stop2)  // get the rest of the string until you hit a line feed or have gone too far
          {
            if (Serial.available()>0) 
              {
                line[counter] = Serial.read();
                if (line[counter] > 32) // only print printable characters
                  {
                    Serial.print(line[counter]);
                  }
                if (line[counter] == 13) {stop2=true;}   // hit a line feed
                if (line[counter] == 36) {stop2=true;}  // hit a $, the start of the next sentence               
                counter++;
                if (counter > 100) {stop2=true;}
              } else {delay (5);}
            delay(2); // to compensate for the slow GPS baud rate
          }
        Serial.println(""); // for debugging         
        Serial.println ("Found right NMEA"); // for debugging
        stop=true;
        convertNMEA(NMEAtype);
        }   
    }
  }

//This subroutine parses a NMEA sentence, converting the ASCII into numberic variables for all the fields
// Written by Jordi Munoz

void convertNMEA(int NMEAtype)
  {
   Latitude=0;
   Longitude=0;
   Velocity=0;
   RealCourse=0;
   Altitude=0;
   Serial.println("NMEA parser loop"); // for debugging
   counter2 = 0; 
   for (int i=0;i<counter;i++){  // this will loop through the whole string from the GPS subroutine, whose length is defined by the counter from that tab
     if (line[i]==','){    //  check for the position of the  "," separator
       indices[counter2]=i;  // this tells us where the data field dividers are in the NMEA string
       counter2++;
       }
     }
   for (int i=0;i<11;i++){  // There is a max of 11 fields in a NMEA sentence
     long conver = 100000000; //  This is just a constant that we'll be using to scale numbers
     for (int j=indices[i];j<(indices[i+1]-1);j++) // read values, hopping from one field to the next
       {
        if(line[j+1] != 46)// If it's not a "." dot, continue, otherwise ignore the dot
          {
          if (NMEAtype == 1) // we're looking for NMEA string with lat, lon and heading and speed info
            {
            switch(i)
              {
              case 2: // Converts the latitude string
              Latitude=Latitude+((line[j+1]-48)*(conver/10)); // convert to integer
              conver=conver/10; // divide by ten each time to move the position of the decimal: 100, 10, 1, .1, .01, .001, etc
              break;

              case 3: //  If north = Positive, if south = negative
              if(line[j+1] == 83)// Multiply latitude for -1
                {
                Latitude=(Latitude)*-1; 
                }
              break;

              case 4: // Converts the longitude string
              Longitude=Longitude+((line[j+1]-48)*conver); 
              conver=conver/10; // divide by ten each time to move the position of the decimal: 100, 10, 1, .1, .01, .001, etc. 
              break;
 
              case 5: // If east = stays Positive, if is west = negative
              if(line[j+1] == 87)
                {
                Longitude=(Longitude)*-1; //  change the value to negative (West)
                }
              break;

              case 6: // Convert Speed 
              Velocity=Velocity+((line[j+1]-48)*(conver/1000000));
              conver=conver/10; // divide by ten each time to move the position of the decimal: 100, 10, 1, .1, .01, .001, etc.
              break;

              case 7: //  Converts the real Course String in integer degrees
              RealCourse = RealCourse +((line[j+1]-48)*(conver/1000000));
              conver=conver/10; // divide by ten each time to move the position of the decimal: 100, 10, 1, .1, .01, .001, etc
              break;
              }
            }
            if (NMEAtype == 2) // we're looking for the NMEA string with altitude data
              {
              if (i == 8) // The altitude field is the ninth in the GPGGA string, so that's #8 in when you start at zero as i did
                {
                 Altitude = Altitude+((line[j+1]-48)*(conver/1000000)); 
                 conver=conver/10; // divide by ten each time to move the position of the decimal: 100, 10, 1, .1, .01, .001, etc
                }
              }
            }
          }         
        }
        Latitude = ((Latitude/1000000)*1000000)+((Latitude % 1000000) / .6); // Converts degrees,minutes to decimal degrees
        Longitude = ((Longitude/1000000)*1000000)+((Longitude % 1000000) / .6); // the same 
        if (NMEAtype == 1) // debugging section
          {
            Serial.print("Latitude = ");  // all of these are for debugging
            Serial.println(Latitude, DEC);
            Serial.print("Longitude = ");
            Serial.println(Longitude, DEC);
            Serial.print("Velocity = ");
            Serial.println(Velocity, DEC);
            Serial.print("Real Course = ");
            Serial.println(RealCourse, DEC);
          }  
        if (NMEAtype == 2) 
          {
            Serial.print("Altitude = ");  
            Serial.println(Altitude, DEC);
          }
} 

void Navigation()   /// These are the main functions of the navigation subroutine. It just calls some subroutines and returns...
{
 Serial.println("Navigation loop");  // for debugging
  GPS (1);
  GetProximity();
  Steer();
  Servo::refresh();
}  

/**************************************************************
 * Get Proximity subroutine
 ***************************************************************/
  void GetProximity()
  {
    DeltaLat = Waypoint[CurrentWaypoint][0] - Latitude; 
    DeltaLon = Waypoint[CurrentWaypoint][1] - Longitude; 
    if ((abs( DeltaLat) < 0.001) && (abs(DeltaLon) < 0.001)) {CurrentWaypoint = CurrentWaypoint + 1;} // Woohoo! We hit our waypoint...on to the next one.
    if ((DeltaLat > 1) && (DeltaLon > 1)) {CurrentWaypoint = 0;} // Yikes. Current waypoint was too far away (probably a data entry error). Go home....
   } 

// This is the navigation subroutine, based on code written by Jordi Munoz 
// Navigation logic derived from this paper: http://jordii07.googlepages.com/Waypoint-Math.pdf

void Steer()
{  
int Correction =0; // Recalls that the earth is round and not oval and this system corrects the error between the Lat. and Lon.
int Quadrant =0; // They are 4 quadrants in the compass, quadrant 1 from 0 to 90 degrees, 2 of 90 to 180 degrees, 3 of 180 to 270 degrees and 4 quadrant of 270 to 60.

  Serial.println("Steer loop");  // for debugging
  DeltaLat=abs(Latitude)-abs(Waypoint[CurrentWaypoint][0]); // Diference between latitude origin/destination
  DeltaLon=abs(Longitude)-abs(Waypoint[CurrentWaypoint][1]); // The same for longitude
  // Next part is to calculate the quadrant
  if((DeltaLat <= -1) & (DeltaLon >= 1)) //	If the latitude difference is negative and longitude difference is positive....
  {
    Quadrant = 1; 
  }
  if((DeltaLat >= 1) & (DeltaLon >= 1)) // 	If the latitude difference is positive and longitude difference is positive....
  {
    Quadrant = 2; 
  }      
  if((DeltaLat >= 1) & (DeltaLon <= -1)) //	If the latitude difference is positive and longitude difference is negative ....
  {
    Quadrant = 3; 
  }
  if((DeltaLat <= -1) & (DeltaLon <= -1)) // If the latitude difference is negative and longitude difference is negative ..../
  {
    Quadrant = 4; 
  }

  // Serial.println(Quadrant); //  Just for debugging

  Temp = Latitude/1000000; // Filter the decimal degrees to obtain only the intriger exp:(35.123456 = 35)
  

  if(abs(DeltaLat) > abs(DeltaLon)) //   if latitude > longitude and choose the proper equation to correct for the spherical distortions 
  // in the latitude due to the earth being round and not flat (they say) ;-) 
  {
    if((Temp >= 1)&(Temp <= 16)){ //if the airplane position is between degrees 1 and 16 then the correction factor is 12
      Correction=12;
    } // If not continue...
    if((Temp >= 17)&(Temp <= 27)){
      Correction=11;
    } 
    if((Temp >= 28)&(Temp <= 37)){
      Correction=10;
    } 
    if((Temp >= 38)&(Temp <= 42)){
      Correction=9;
    }  
    if((Temp >= 43)&(Temp <= 52)){
      Correction=8;
    }
    if((Temp >= 53)&(Temp <= 57)){
      Correction=7;
    }
    if((Temp >= 58)&(Temp <= 62)){
      Correction=6;
    }
    
    DestinationDir =abs(DeltaLon)/(abs(DeltaLat)/Correction);
    Distance = ((abs(DeltaLat)/Correction)* sqrt(sq(Correction) + sq(DestinationDir)))/10; // calculate the distance
    DestinationDir = (DestinationDir*45)/120; // Equation for obtaining degrees that will take us to our destination
    switch(Quadrant)
    {
    case 1: 
      DestinationDir = DestinationDir; // Then depending on the quadrant, select the correct equation, which will take us to our destination
      break;
    case 2: 
      DestinationDir = 180 - DestinationDir;
      break;
    case 3: 
      DestinationDir = 180 + DestinationDir;
      break;
    case 4: 
      DestinationDir = 360 - DestinationDir;
      break;
    }         
  }
  else //  if latitude < longitude
  {
     if((DestinationDir >= 1)&(DestinationDir <= 16)){
      Correction=12;
    }
    if((DestinationDir >= 17)&(DestinationDir <= 27)){
      Correction=13;
    }
    if((DestinationDir >= 28)&(DestinationDir <= 32)){ 
      Correction=14;
    }
    if((DestinationDir >= 33)&(DestinationDir <= 37)){
      Correction=150;
    }   
    if((DestinationDir >= 38)&(DestinationDir <= 42)){
      Correction=16;
    }
    if((DestinationDir >= 43)&(DestinationDir <= 47)){
      Correction=17;
    }
    if((DestinationDir >= 48)&(DestinationDir <= 52)){
      Correction=19;
    } 
    if((DestinationDir >= 53)&(DestinationDir <= 57)){
      Correction=21;
    }
    if((DestinationDir >= 58)&(DestinationDir <= 62)){
      Correction=24;
    }
    
    DestinationDir =abs(DeltaLat)/(abs(DeltaLon)/Correction);
    Distance = ((abs(DeltaLon)/Correction)* sqrt(sq(Correction) + sq(DestinationDir)))/10; // calculate the distance
    DestinationDir = (DestinationDir*45)/120; // Equation for obtaining degrees that will take us to our destination

    switch(Quadrant)
    {
    case 1: 
      DestinationDir = 90 - DestinationDir;
      break;
    case 2: 
      DestinationDir = 90 + DestinationDir;
      break;
    case 3: 
      DestinationDir = 270 - DestinationDir;
      break;
    case 4: 
      DestinationDir = 270 + DestinationDir;
      break;
    }  
  }
// this is the part where we turn the calculate angle to the next waypoint into a rudder command
  RudderServo.write(DestinationDir);  // [this is just a placeholder; will have to figure out servo orientation next]
  Servo::refresh();
}  



int main(void)
{
	init();

	setup();
    
	for (;;)
		loop();
        
	return 0;
}

