Release Information

Driver Version for Linux 2.4.x : V0213

Released date: 02/13/2002

Files Included in This Release:
	pl2303.c
	pl2303.h
	usbserial.c
	usb-serial.h
	readme.txt
	makefile
		
Changes in This Release:
	1. To fixed using cat command  problem in Linux
