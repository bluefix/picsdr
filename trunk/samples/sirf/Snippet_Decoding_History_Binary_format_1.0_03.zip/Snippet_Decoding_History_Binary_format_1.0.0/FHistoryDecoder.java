/*
 * Copyright (C) 2002-2006 by Falcom GmbH, GERMANY
 * All rights reserved.
 *
 * Redistribution and modification of this code is strictly prohibited.
 *
 * IN NO EVENT SHALL THE FALCOM GMBH BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
 * OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF THE
 * FALCOM GMBH HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * FALCOM GMBH SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE FALCOM GMBH HAS NO OBLIGATION TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS OR MODIFICATIONS.
 */

package de.falcom.plugins.history;

import java.io.Writer;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Calendar;
import java.util.TimeZone;

public class FHistoryDecoder {

	/* The fields present in a history record. */
	public static class HistoryRecord
	{
		public long satCount = 0;
		public boolean satFix = false;
		public double speed = 0.0;
		public long posX = 0;
		public long posY = 0;
		public long posZ = 0;
		public long time = 0;
	}

	/* Each binary record can have one of four possible formats. */
	private final static int FMT_FULLRECORD = 0;
	private final static int FMT_MOTORWAY   = 1;
	private final static int FMT_CITY       = 2;
	private final static int FMT_STANDING   = 3;

	/* The fields in a full binary record. */
	private final static int FIELD_FULL_FORMAT   = 0x0001;
	private final static int FIELD_FULL_SATCOUNT = 0x0002;
	private final static int FIELD_FULL_SATFIX   = 0x0004;
	private final static int FIELD_FULL_EXT      = 0x0008;
	private final static int FIELD_FULL_SPEED    = 0x0010;
	private final static int FIELD_FULL_SIGNX    = 0x0020;
	private final static int FIELD_FULL_SIGNY    = 0x0040;
	private final static int FIELD_FULL_SIGNZ    = 0x0080;
	private final static int FIELD_FULL_TIMEABS = 0x0100;
	private final static int FIELD_FULL_POSXABS = 0x0200;
	private final static int FIELD_FULL_POSYABS = 0x0400;
	private final static int FIELD_FULL_POSZABS = 0x0800;

	/* The fields in a full record and their length in bits. */
	private final static int[] FIELDS_FULL = {
		FIELD_FULL_FORMAT,   2,
		FIELD_FULL_SATCOUNT, 4,
		FIELD_FULL_SATFIX,   1,
		FIELD_FULL_EXT,      1,
		FIELD_FULL_SPEED,    7,
		FIELD_FULL_SIGNX,    1,
		FIELD_FULL_SIGNY,    1,
		FIELD_FULL_SIGNZ,    1,
		FIELD_FULL_TIMEABS, 30,
		FIELD_FULL_POSXABS, 24,
		FIELD_FULL_POSYABS, 24,
		FIELD_FULL_POSZABS, 24
	};

	/* The fields in a motorway binary record. */
	private final static int FIELD_MOTORWAY_FORMAT   = 0x1001;
	private final static int FIELD_MOTORWAY_SATCOUNT = 0x1002;
	private final static int FIELD_MOTORWAY_SATFIX   = 0x1004;
	private final static int FIELD_MOTORWAY_EXT      = 0x1008;
	private final static int FIELD_MOTORWAY_SPEED    = 0x1010;
	private final static int FIELD_MOTORWAY_TIMEDIF  = 0x1020;
	private final static int FIELD_MOTORWAY_POSXDIF  = 0x1040;
	private final static int FIELD_MOTORWAY_POSYDIF  = 0x1080;
	private final static int FIELD_MOTORWAY_POSZDIF  = 0x1100;

	/** The fields in a motorway record and their length in bits. */
	private final static int[] FIELDS_MOTORWAY = 
	{
		FIELD_MOTORWAY_FORMAT,   2,
		FIELD_MOTORWAY_SATCOUNT, 4,
		FIELD_MOTORWAY_SATFIX,   1,
		FIELD_MOTORWAY_EXT,      1,
		FIELD_MOTORWAY_SPEED,    7,
		FIELD_MOTORWAY_TIMEDIF, 12,
		FIELD_MOTORWAY_POSXDIF, 15,
		FIELD_MOTORWAY_POSYDIF, 15,
		FIELD_MOTORWAY_POSZDIF, 15
	};

	/* The fields in a city binary record. */
	private final static int FIELD_CITY_FORMAT   = 0x2001;
	private final static int FIELD_CITY_SATCOUNT = 0x2002;
	private final static int FIELD_CITY_SATFIX   = 0x2004;
	private final static int FIELD_CITY_EXT      = 0x2008;
	private final static int FIELD_CITY_SPEED    = 0x2010;
	private final static int FIELD_CITY_TIMEDIF  = 0x2020;
	private final static int FIELD_CITY_POSXDIF  = 0x2040;
	private final static int FIELD_CITY_POSYDIF  = 0x2080;
	private final static int FIELD_CITY_POSZDIF  = 0x2100;

	/* The fields in a city record and their length in bits. */
	private final static int[] FIELDS_CITY =
	{
		FIELD_CITY_FORMAT,   2,
		FIELD_CITY_SATCOUNT, 3,
		FIELD_CITY_SATFIX,   1,
		FIELD_CITY_EXT,      1,
		FIELD_CITY_SPEED,    5,
		FIELD_CITY_TIMEDIF,  9,
		FIELD_CITY_POSXDIF,  9,
		FIELD_CITY_POSYDIF,  9,
		FIELD_CITY_POSZDIF,  9
	};

	/* The fields in a standing binary record. */
	private final static int FIELD_STANDING_FORMAT   = 0x4001;
	private final static int FIELD_STANDING_SATCOUNT = 0x4002;
	private final static int FIELD_STANDING_SATFIX   = 0x4004;
	private final static int FIELD_STANDING_EXT      = 0x4008;
	private final static int FIELD_STANDING_SPEED    = 0x4010;
	private final static int FIELD_STANDING_TIMEDIF  = 0x4020;
	private final static int FIELD_STANDING_POSXDIF  = 0x4040;
	private final static int FIELD_STANDING_POSYDIF  = 0x4080;
	private final static int FIELD_STANDING_POSZDIF  = 0x4100;

	/* The fields in a standing record and their length in bits. */
	private final static int[] FIELDS_STANDING =
	{
		FIELD_STANDING_FORMAT,   2,
		FIELD_STANDING_SATCOUNT, 2,
		FIELD_STANDING_SATFIX,   0,
		FIELD_STANDING_EXT,      1,
		FIELD_STANDING_SPEED,    3,
		FIELD_STANDING_TIMEDIF, 12,
		FIELD_STANDING_POSXDIF,  4,
		FIELD_STANDING_POSYDIF,  4,
		FIELD_STANDING_POSZDIF,  4
	};

	/* The time offset for the GPS clock. */
	private static long timeMillisDiff;
	
	/* a globally history record for holding last converted record */
	private HistoryRecord mHistoryRecord;
	

	/**
	 * Converts earth-centered / earth-fixed data to 
	 * latitude, longitude and altitude.
	 *
	 * @param xyz
	 *            x, y and z in meters.
	 * @return latitude and longitude in degrees, altitude in meters.
	 */
	private static double[] ecefToLla( double[] xyz )
	{
		// equatorial earth radius
		final double eer = 6378137.0;
		
		// flattening parameter
		final double fp = 1.0 / 298.257223560;

		// earth eccentricity squared
		final double ees = fp * ( 2.0 - fp );

		double x = xyz[ 0 ];
		double y = xyz[ 1 ];
		double z = xyz[ 2 ];

		double lon = Math.atan2( y, x );

		double r = Math.sqrt( x * x + y * y );
		double lat = Math.atan2( z, ( r * ( 1.0 - ees ) ) );
		double c = 0.0;
		for ( int i = 0; i < 10; ++i )
		{
			double l = lat;
			double sl = Math.sin( lat );
			c = 1.0 / Math.sqrt( 1.0 - ees * sl * sl );
			lat = Math.atan2( ( z + eer * c * ees * sl ), r );
			if ( lat == l )
				break;
		}

		double alt = r / Math.cos( lat ) - eer * c;

		double lla[] = 
		{
			lat * 180.0 / Math.PI,
			lon * 180.0 / Math.PI,
			alt
		};
		
		return lla;
	}

	private static DecimalFormat DF_TWO = dotDecimalSeparator( "00" );
	private static DecimalFormat DF_TWO_DOT_FOUR = dotDecimalSeparator( "00.0000" );
	private static DecimalFormat DF_THREE = dotDecimalSeparator( "000" );

	private static DecimalFormat dotDecimalSeparator( String format )
	{
		DecimalFormat df = new DecimalFormat( format );
		DecimalFormatSymbols dfs = df.getDecimalFormatSymbols();
		dfs.setDecimalSeparator( '.' );
		df.setDecimalFormatSymbols( dfs );
		
		return df;
	}

	/**
	 * Formats a latitude or longitude value to the form used in NMEA sentences.
	 *
	 * @param deg
	 *            the latitude or longitude in degrees.
	 * @param isLongitude
	 *            <code>true</code> for longitude, 
	 *            <code>false</code> for latitude.
	 * @return the formatted latitude or longitude.
	 */
	private static String formatLatLon( double deg, boolean isLongitude )
	{
		StringBuilder sb = new StringBuilder();
		if ( deg < 0.0 )
		{
			sb.append( "-" );
			deg = -deg;
		}
		
		deg = Math.min( deg, isLongitude ? 180.0 : 90.0 );
		double d = Math.floor( deg );
		double m = ( deg - d ) * 60.0;
		sb.append( isLongitude ? DF_THREE.format( d ) : DF_TWO.format( d ) );
		sb.append( DF_TWO_DOT_FOUR.format( m ) );
		
		return sb.toString();
	}

	/**
	 * Creates a HistoryDecoder class.
	 */
	public FHistoryDecoder()
	{
		/*
		 * Calculate the time offset for the GPS clock.
		 * This correction value is required to convert
		 * GPS time (starts on 1980-01-06 00:00) into a valid
		 * Java / System time (starts on 1970-01-01 00:00).
		 */ 
		Calendar cal = Calendar.getInstance();
		cal.setFirstDayOfWeek( Calendar.MONDAY );
		cal.setMinimalDaysInFirstWeek(1);
		cal.setTimeZone( TimeZone.getTimeZone( "UTC" ) );
		cal.set( 1980, Calendar.JANUARY, 6, 0, 0, 0 );
		timeMillisDiff = cal.getTimeInMillis();
	}

	/**
	 * Decodes a binary stream and writes NMEA sentences to a
	 * <code>Writer</code> object.
	 *
	 * @param bytes
	 *            the bytes to read.
	 * @param off
	 *            the offset from which to start.
	 * @param len
	 *            the number of bytes to read.
	 * @param writer
	 *            where to write the decoded history as NMEA sentences.
	 * @return <code>false</code> if more bytes are required,
	 *         <code>true</code> otherwise.
	 * @throws Exception
	 *             if an error occurs.
	 */
	public boolean decode( byte[] bytes, int off, int len, Writer writer )
	throws Exception
	{
		/*
		 * Each data chunk from the device starts with 2 bytes containing
		 * the length of the following binary hiytory data. So we assume 
		 * in this method, that the first two bytes contain this length and
		 * try to calculate it.
		 */
		if (len < 2)
		{
			/*
			 * Seems that there is an error. We need a minimum of 2 bytes
			 * to calculate the length of following data.
			 */
			return false;
		}

		/*
		 * The first history data chunk (e.g. 512 bytes) starts everytime
		 * with a full record. Each other data chunk may start with a record 
		 * type other than full record.
		 * Because only full records contain all required informations to 
		 * calculate a nmea sentence from scratch (all other contain only 
		 * difference values against last calculated one), it is required
		 * to keep every last calculated nmea sentence (record) in memory 
		 * between two calls of this method (e.g. from chunk1 and later chunk2).
		 */
		if ( mHistoryRecord == null )
		{
			/*
			 * If and only if above described record cache isn't initialized,
			 * do it here!
			 */
			mHistoryRecord = new HistoryRecord();
		}

		/*
		 * Calculate raw data size from the first two bytes and skip them
		 * afterwards.
		 */
		int size = 
			( bytes[ off ] + 0x100 & 0xff ) << 8 |
			( bytes[ off + 1 ] + 0x100 & 0xff );
		
		off += 2;
		len -= 2;

		if ( size == 0 )
		{
			return true; // history size is 0.
		}
		else if ( size < 0 )
		{
			throw new Exception( "Data chunk size can't be less 0." );
		}
		else if ( len < size )
		{
			return false; // need more data.
		}

		/*
		 * Convert the incoming data
		 */
		int pos = 0;
		int heading = 0;

		while ( pos < size )
		{
			if ( pos >= size )
			{
				throw new Exception( "Parsing violated history buffer bounds." );
			}

			/*
			 * There are four different record types defined.
			 * Check and get actual record type.
			 */ 
			int[] fields = null;

			switch ( bytes[ off + pos ] >>> 6 & 3 )
			{
			case FMT_FULLRECORD:
				/*
				 * A new full record is available. So clear the old
				 * cached hisory record and create a new one. 
				 */
				mHistoryRecord = new HistoryRecord();
				fields = FIELDS_FULL;
				break;
			case FMT_MOTORWAY:
				fields = FIELDS_MOTORWAY;
				break;
			case FMT_CITY:
				fields = FIELDS_CITY;
				break;
			case FMT_STANDING:
				fields = FIELDS_STANDING;
				break;
			}

			int maskBit;
			boolean negative;
			long extension = 0;

			for ( int fieldI = 2, bitStart = 5; fieldI < fields.length; fieldI += 2 )
			{
				int fieldType = fields[ fieldI ];
				int bitLength = fields[ fieldI + 1 ];

				// bitwise read of actual field
				long bitData = 0;
				for ( int i = bitLength; i > 0 ; --i )
				{
					if (bitStart < 0) 
					{
						bitStart = 7;
						if ( ++pos >= size )
						{
							throw new Exception( "Parsing violated history buffer bounds." );
						}
					}

					bitData = ((bitData << 1) | ((bytes[off + pos] >>> bitStart--) & 1));
				}

				switch (fieldType)
				{
				case FIELD_FULL_SIGNX:
					// reserved
					break;
				case FIELD_FULL_SIGNY:
					// reserved
					break;
				case FIELD_FULL_SIGNZ:
					// reserved
					break;

				case FIELD_FULL_TIMEABS:
					// convert GPS time to Java system time
					mHistoryRecord.time = bitData * 1000 + timeMillisDiff;
					break;
				case FIELD_FULL_POSXABS:
					// Note: Negative indicator is MSB of number. Ignore sign field.
					maskBit = 1 << ( bitLength - 1 );
					negative = ( bitData & maskBit ) == maskBit;
					mHistoryRecord.posX = negative ? -( bitData & ~maskBit ) : bitData & ~maskBit;
					break;
				case FIELD_FULL_POSYABS:
					// Note: Negative indicator is MSB of number. Ignore sign field.
					maskBit = 1 << ( bitLength - 1 );
					negative = ( bitData & maskBit ) == maskBit;
					mHistoryRecord.posY = negative ? -( bitData & ~maskBit ) : bitData & ~maskBit;
					break;
				case FIELD_FULL_POSZABS:
					// Note: Negative indicator is MSB of number. Ignore sign field.
					maskBit = 1 << ( bitLength - 1 );
					negative = ( bitData & maskBit ) == maskBit;
					mHistoryRecord.posZ = negative ? -( bitData & ~maskBit ) : bitData & ~maskBit;
					break;

				case FIELD_FULL_SATCOUNT:
				case FIELD_MOTORWAY_SATCOUNT:
				case FIELD_CITY_SATCOUNT:
					mHistoryRecord.satCount = bitData;
					break;

				case FIELD_STANDING_SATCOUNT:
					mHistoryRecord.satCount = ( bitData << 1 ) + 1;
					mHistoryRecord.satFix = mHistoryRecord.satCount > 1;
					break;

				case FIELD_FULL_SATFIX:
				case FIELD_MOTORWAY_SATFIX:
				case FIELD_CITY_SATFIX:
					mHistoryRecord.satFix = bitData != 0;
					break;
				case FIELD_STANDING_SATFIX:
					// not implemented
					break;

				case FIELD_FULL_EXT:
				case FIELD_MOTORWAY_EXT:
				case FIELD_CITY_EXT:
				case FIELD_STANDING_EXT:
					extension = bitData;
					break;

				case FIELD_FULL_SPEED:
				case FIELD_MOTORWAY_SPEED:
				case FIELD_CITY_SPEED:
				case FIELD_STANDING_SPEED:
					// convert from m/s to knots
					mHistoryRecord.speed = bitData * 1.94384449;
					break;

				case FIELD_MOTORWAY_TIMEDIF:
				case FIELD_CITY_TIMEDIF:
				case FIELD_STANDING_TIMEDIF:
					mHistoryRecord.time += bitData * 1000;
					break;

				case FIELD_MOTORWAY_POSXDIF :
				case FIELD_CITY_POSXDIF :
				case FIELD_STANDING_POSXDIF :
					maskBit = 1 << ( bitLength - 1 );
					negative = ( bitData & maskBit ) == maskBit;
					mHistoryRecord.posX += negative ? -( bitData & ~maskBit ) : bitData & ~maskBit;
					break;

				case FIELD_MOTORWAY_POSYDIF :
				case FIELD_CITY_POSYDIF :
				case FIELD_STANDING_POSYDIF :
					maskBit = 1 << ( bitLength - 1 );
					negative = ( bitData & maskBit ) == maskBit;
					mHistoryRecord.posY += negative ? -( bitData & ~maskBit ) : bitData & ~maskBit;
					break;

				case FIELD_MOTORWAY_POSZDIF :
				case FIELD_CITY_POSZDIF :
				case FIELD_STANDING_POSZDIF :
					maskBit = 1 << ( bitLength - 1 );
					negative = ( bitData & maskBit ) == maskBit;
					mHistoryRecord.posZ += negative ? -( bitData & ~maskBit ) : bitData & ~maskBit;
					break;
				}
			}

			// Actual record end reached, continue with next byte.
			++pos;

			/*
			 * Parse extension data if available.
			 * ATTENTION: 
			 * Extension parsing isn't implemented in this code snippet,
			 * but follows the same principles like the rest of the code,
			 * so that it can be done easily by each programmer itself.   
			 */ 
			if (extension > 0)
			{
				int orgPointer = pos;

				if (orgPointer == size)
					break;
				int extLen = bytes[off + orgPointer++] * 2;

				if (orgPointer == size)
					break;
				int tExtIDs = bytes[off + orgPointer++];

				if (extLen <= 0 || tExtIDs <= 0)
					break;

				// process with next extension
				pos += extLen;
			}
			extension = 0;

			// Output NMEA sentence.
			double[] longLat = ecefToLla(new double[] {
					mHistoryRecord.posX * 2.0,
					mHistoryRecord.posY * 2.0,
					mHistoryRecord.posZ * 2.0});

			StringBuilder sentence = new StringBuilder();
			sentence.append("GPRMC message: time(").append(mHistoryRecord.time);
			sentence.append(") fix(").append(mHistoryRecord.satFix);
			sentence.append(") long(");
			sentence.append(formatLatLon(longLat[1], true));
			sentence.append(") lat(");
			sentence.append(formatLatLon(longLat[0], false));
			sentence.append(") speed(").append(mHistoryRecord.speed);
			sentence.append(") head(").append(heading); // XXX not evaluated yet
			sentence.append(")\n");
			System.out.println("sente "+sentence.toString());
			writer.write(sentence.toString());
		}

		return true;
	}
}

