// originally written by Lisa Corsetti 
// see: ftp://ftp.ssc.com/pub/lj/listings/issue117/README117
// and: ftp://ftp.ssc.com/pub/lj/listings/issue117/6908.tgz
// Updated by guido socher (guido at linuxfocus.org)
// Copyright: GPL
#define VERINFO "1.0"
//
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
/*
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;
typedef unsigned char u8;
instead use asm/types.h: */
#define __KERNEL__ 1
#include <asm/types.h>
#include <linux/ethtool.h>
#include <linux/sockios.h>

/* option parsing */
int opt_v=0;

void help()
{
        printf("ethwireck -- check if the wire in the ethernet port is live\n\
\n\
USAGE: ethwireck [-hv] [interface]\n\
\n\
If no interface name is given then eth0 is assumed.\n\
\n\
OPTIONS: -h this help\n\
         -v print verbous information on stderr\n\
\n\
ethwireck returns exit code 0 if the physical ethernet layer is up. That is:\n\
a connector is plugged in and the other end of the wire is connected to a hub\n\
or a second computer.\n\
\n\
EXITCODES: -1 = error\n\
            0 = link is up\n\
	    1 = link is down\n\
	    2 = the etnernet driver does not support checking of \n\
	        link status.\n\
\n\
The idea is that you use ethwireck in your init script to prevent \n\
a long timeout of a dhcp configured interface when your notebook\n\
is not connected to the network.\n\
\n\
You can use it like this:\n\
if ethwireck eth0; then\n\
    # run dhclient or pump\n\
else\n\
    echo \"eth0 is down\"\n\
fi\n\
\n\
ethwireck is pronounced: eth - wire - check\n\
            \n");
#ifdef VERINFO
        puts(VERINFO);
#endif
        exit(0);
}


//  remove detect_mii_old for 2.6 kernel, just for backward compatibility with old 2.4 drivers
int detect_mii_old(int skfd, char *ifname)
	{
	struct ifreq ifr;
	u16 *data, mii_val;
	unsigned phy_id;

	/* Get the vitals from the interface. */
	strncpy(ifr.ifr_name, ifname, IFNAMSIZ);
	if (ioctl(skfd, SIOCDEVPRIVATE, &ifr) < 0)
		{
		if (opt_v) fprintf(stderr, "SIOCDEVPRIVATE on %s failed: %s\n", ifname,
			strerror(errno));
		return 2;
		}

	data = (u16 *)(&ifr.ifr_data);
	phy_id = data[0];
	data[1] = 1;

	if (ioctl(skfd, SIOCDEVPRIVATE+1, &ifr) < 0)
		{
		if (opt_v) fprintf(stderr, "SIOCDEVPRIVATE+1 on %s failed: %s\n", ifr.ifr_name,
			strerror(errno));
		return 2;
		}

	mii_val = data[3];

	if (opt_v) fprintf(stderr, "SIOCDEVPRIVATE: OK\n");
	return(((mii_val & 0x0016) == 0x0004) ? 0 : 1);
	}

int detect_mii(int skfd, char *ifname)
	{
	struct ifreq ifr;
	u16 *data, mii_val;
	unsigned phy_id;

	/* Get the vitals from the interface. */
	strncpy(ifr.ifr_name, ifname, IFNAMSIZ);
	if (ioctl(skfd, SIOCGMIIPHY, &ifr) < 0)
		{
		if (opt_v) fprintf(stderr, "SIOCGMIIPHY on %s failed: %s\n", ifname,
			strerror(errno));
		return 2;
		}

	data = (u16 *)(&ifr.ifr_data);
	phy_id = data[0];
	data[1] = 1;

	if (ioctl(skfd, SIOCGMIIREG, &ifr) < 0)
		{
		if (opt_v) fprintf(stderr, "SIOCGMIIREG on %s failed: %s\n", ifr.ifr_name,
			strerror(errno));
		return 2;
		}

	mii_val = data[3];

	if (opt_v) fprintf(stderr, "SIOCGMII: OK\n");
	return(((mii_val & 0x0016) == 0x0004) ? 0 : 1);
	}

int detect_ethtool(int skfd, char *ifname)
	{
	struct ifreq ifr;
	struct ethtool_value edata;
                                                                                
	memset(&ifr, 0, sizeof(ifr));
	edata.cmd = ETHTOOL_GLINK;

	strncpy(ifr.ifr_name, ifname, sizeof(ifr.ifr_name)-1);
	ifr.ifr_data = (char *) &edata;
                                                                                
	if (ioctl(skfd, SIOCETHTOOL, &ifr) == -1)
		{
		if (opt_v) printf("ETHTOOL_GLINK failed: %s\n", strerror(errno));
		return 2;
		}
                                                                                
	if (opt_v) fprintf(stderr, "ETHTOOL: OK\n");
	return (edata.data ? 0 : 1);
	}

int main(int argc, char *argv[])
{
	int skfd = -1;
	char *ifname;
	int retval;
        /* The following things are used for getopt: */
        extern char *optarg;
        extern int optind;
        extern int opterr;
        int ch;

	opterr=0;
        while ((ch = getopt(argc, argv, "hv")) != -1) {
                switch (ch) {
                case 'v':
                        opt_v=1;
                break;
                case 'h':
                        help(); /*no break, help does not return */
                case '?':
                        fprintf(stderr, "ERROR: No such option. -h for help.\n");
                        exit(-1);
                /*no default action for case */
                }
        }

	if (optind +1 == argc){
		// one arg given
		ifname=argv[optind];
	}else if(optind==argc){
		// no arg given
		ifname = "eth0";
	}else{
		help();
	}
	

	/* Open a socket. */
	if (( skfd = socket( AF_INET, SOCK_DGRAM, 0 ) ) < 0 )
		{
		printf("socket error\n");
		exit(-1);
		}

	retval = detect_ethtool(skfd, ifname);

	if (retval == 2)
		retval = detect_mii(skfd, ifname);

	if (retval == 2)
		retval = detect_mii_old(skfd, ifname);

	close(skfd);

	if (retval == 2)
		printf("%s: could not determine status\n",ifname);

	if (retval == 1)
		printf("%s: link down\n",ifname);

	if (retval == 0)
		printf("%s: link up\n",ifname);

	return retval;
}

